// Reads a photographed sheet, then uses the machine's template to find which number belongs to which label.
// Text comes from free text recognition: Tesseract on your own server (reads Greek and English),
// or Google ML Kit on the phone when the server can't be reached (Latin letters only). No AI.
import { recognizeText } from '@infinitered/react-native-mlkit-text-recognition';
import { Template, detectMachine, machine as getMachine } from './machines';
import { PARTS, plausible } from './metrics';

export type OcrLine = {
  text: string;
  norm: string;
  left: number;
  top: number;
  right: number;
  bottom: number;
  page: number; // 1-based
};

export type ReadField = { value: number | null; lo: number | null; hi: number | null; page: number | null; unclear: boolean };
export type About = { height: number | null; age: number | null; sex: 'male' | 'female' | null; birth: Date | null };
export type PageInfo = { date: Date | null; machineId: string | null };

export type ReadResult = {
  machineId: string;
  detected: boolean;
  fields: Record<string, ReadField>;
  about: About;
  date: Date | null;
  pages: PageInfo[];
  textFound: boolean;
};

// ---------- Text clean-up ----------

const ACCENTS: Record<string, string> = {
  Ά: 'Α', Έ: 'Ε', Ή: 'Η', Ί: 'Ι', Ό: 'Ο', Ύ: 'Υ', Ώ: 'Ω', Ϊ: 'Ι', Ϋ: 'Υ',
  ά: 'α', έ: 'ε', ή: 'η', ί: 'ι', ό: 'ο', ύ: 'υ', ώ: 'ω', ϊ: 'ι', ϋ: 'υ', ΐ: 'ι', ΰ: 'υ', ς: 'σ',
};
// Greek capitals that look like Latin ones are treated as the same letter,
// so a reader that mixes the two alphabets still matches.
const LOOKALIKE: Record<string, string> = {
  Α: 'A', Β: 'B', Ε: 'E', Ζ: 'Z', Η: 'H', Ι: 'I', Κ: 'K', Μ: 'M', Ν: 'N', Ο: 'O', Ρ: 'P', Τ: 'T', Υ: 'Y', Χ: 'X',
};

export function normalize(s: string): string {
  let a = '';
  for (const ch of s) a += ACCENTS[ch] ?? ch;
  a = a.toUpperCase();
  let b = '';
  for (const ch of a) b += LOOKALIKE[ch] ?? ch;
  return b
    .replace(/[‐‑‒–—]/g, '-')
    .replace(/[～∼]/g, '~')
    .replace(/\s+/g, ' ')
    .trim();
}

// The text reader's box can come as left/top/right/bottom or origin/size, depending on the platform.
function box(f: any): { left: number; top: number; right: number; bottom: number } {
  if (f && typeof f.left === 'number') {
    const right = typeof f.right === 'number' ? f.right : f.left + (f.width ?? 0);
    const bottom = typeof f.bottom === 'number' ? f.bottom : f.top + (f.height ?? 0);
    return { left: f.left, top: f.top, right, bottom };
  }
  if (f && f.origin) {
    const x = f.origin.x ?? 0;
    const y = f.origin.y ?? 0;
    const w = f.size?.width ?? f.size?.x ?? 0;
    const h = f.size?.height ?? f.size?.y ?? 0;
    return { left: x, top: y, right: x + w, bottom: y + h };
  }
  if (f && typeof f.x === 'number') {
    return { left: f.x, top: f.y, right: f.x + (f.width ?? 0), bottom: f.y + (f.height ?? 0) };
  }
  return { left: 0, top: 0, right: 0, bottom: 0 };
}

export function makeLine(text: string, b: { left: number; top: number; right: number; bottom: number }, page: number): OcrLine {
  return { text, norm: normalize(text), left: b.left, top: b.top, right: b.right, bottom: b.bottom, page };
}

// Reading on the phone (Google ML Kit, offline, Latin letters only).
export async function readPageOnPhone(uri: string, page: number): Promise<OcrLine[]> {
  let res: any;
  try {
    res = await recognizeText(uri);
  } catch (e) {
    if (!uri.startsWith('file://')) throw e;
    res = await recognizeText(uri.replace('file://', ''));
  }
  const lines: OcrLine[] = [];
  for (const block of res?.blocks ?? []) {
    for (const line of block?.lines ?? []) {
      if (line?.text) lines.push(makeLine(line.text, box(line.frame), page));
    }
  }
  return lines;
}

// ---------- Numbers ----------

const NUM = /-?\d+(?:[.,]\d+)?/g;
const RANGE = /(\d+(?:[.,]\d+)?)\s*[~-]\s*(\d+(?:[.,]\d+)?)/g;
const RANGE_START = /^\W*(\d+(?:[.,]\d+)?)\s*[~-]\s*(\d+(?:[.,]\d+)?)/;
const toNum = (s: string) => parseFloat(s.replace(',', '.'));

// Removes units that contain digits (cm², kg/m², 50kHz) and joins "- 45,9" into "-45,9".
function clean(s: string): string {
  return s
    .replace(/(KG\/M|CM|M)\s*[2²]/g, ' ')
    .replace(/\d+\s*KHZ/g, ' ')
    .replace(/%/g, ' ')
    .replace(/(^|[\s(])-\s+(?=\d)/g, '$1-');
}

type Tok = { v: number; start: number; end: number };

function tokens(text: string) {
  const s = clean(text);
  const ranges: { lo: number; hi: number; start: number; end: number }[] = [];
  for (const m of s.matchAll(RANGE)) {
    const start = m.index ?? 0;
    // a minus right before a number is a sign, not a range ("0 -45,9" is not a range)
    if (/\s-\s?\d/.test(m[0]) && !/~/.test(m[0])) continue;
    ranges.push({ lo: toNum(m[1]), hi: toNum(m[2]), start, end: start + m[0].length });
  }
  const nums: Tok[] = [];
  for (const m of s.matchAll(NUM)) {
    const start = m.index ?? 0;
    if (ranges.some((r) => start >= r.start && start < r.end)) continue;
    const v = toNum(m[0]);
    if (!isNaN(v)) nums.push({ v, start, end: start + m[0].length });
  }
  return { nums, ranges };
}

// The value is the first number in the row. Its normal range is a "low~high" pair printed right after it.
// A bar chart row prints its scale first (40 60 80 100 …), so the value is the first number after the scale.
function pickValue(text: string, ok?: (v: number) => boolean): { v: number | null; lo: number | null; hi: number | null } {
  const { nums, ranges } = tokens(text);
  if (!nums.length) return { v: null, lo: null, hi: null };
  let i = 0;
  let run = 1;
  while (run < nums.length && nums[run].v > nums[run - 1].v) run++;
  if (run >= 4) i = run < nums.length ? run : nums.length - 1;
  if (ok && !ok(nums[i].v)) {
    const j = nums.findIndex((n, k) => k >= (run >= 4 ? run : 0) && ok(n.v));
    if (j >= 0) i = j;
  }
  const value = nums[i];
  const next = nums[i + 1];
  const range = ranges.find((r) => r.start >= value.end && (!next || r.start < next.start));
  return { v: value.v, lo: range ? range.lo : null, hi: range ? range.hi : null };
}

// ---------- Labels ----------

function lev(a: string, b: string, max: number): number {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i];
    let best = i;
    for (let j = 1; j <= b.length; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      best = Math.min(best, cur[j]);
    }
    if (best > max) return max + 1;
    prev = cur;
  }
  return prev[b.length];
}

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
const reCache: Record<string, RegExp> = {};
function labelRe(label: string): RegExp {
  if (!reCache[label]) reCache[label] = new RegExp('(^|[^A-Z0-9/Α-Ω])' + escapeRe(normalize(label)) + '(?=$|[^A-Z0-9/Α-Ω])');
  return reCache[label];
}

// Where a label sits in a line: returns the text after it, or null.
// Small reading mistakes are allowed in longer words (one wrong letter, two in very long words).
function matchLabel(line: OcrLine, label: string, fuzzy = false): string | null {
  const m = labelRe(label).exec(line.norm);
  if (m) return line.norm.slice(m.index + m[0].length);
  if (!fuzzy) return null;
  const want = normalize(label).split(' ');
  if (want.join('').length < 5) return null;
  const words: { w: string; end: number }[] = [];
  for (const m2 of line.norm.matchAll(/[^\s]+/g)) words.push({ w: m2[0].replace(/[.,:;()]+$/, ''), end: (m2.index ?? 0) + m2[0].length });
  for (let i = 0; i + want.length <= words.length; i++) {
    let ok = true;
    for (let k = 0; k < want.length && ok; k++) {
      const a = want[k].replace(/[.,:;()]+$/, '');
      const b = words[i + k].w;
      const allowed = a.length >= 9 ? 2 : a.length >= 4 ? 1 : 0;
      // signs like % and / must be there exactly ("ΛΙΠΟΣ%" is not "ΛΙΠΟΣ")
      const signs = (w: string) => w.replace(/[A-ZΑ-Ω0-9]/g, '');
      ok = a === b || (allowed > 0 && signs(a) === signs(b) && lev(a, b, allowed) <= allowed);
    }
    if (ok) return line.norm.slice(words[i + want.length - 1].end);
  }
  return null;
}

// A line just under another one, overlapping it left to right.
function lineBelow(line: OcrLine, lines: OcrLine[], reach = 2.5): OcrLine | null {
  const h = Math.max(1, line.bottom - line.top);
  const below = lines
    .filter((l) => l !== line && l.page === line.page && l.top >= line.bottom - h * 0.3 && l.top <= line.bottom + h * reach && l.left < line.right && l.right > line.left)
    .sort((a, b) => a.top - b.top);
  return below[0] ?? null;
}

// The first line under a title, in the same column, that has a number (Tanita boxes: title, then value further down).
function numberBelow(line: OcrLine, lines: OcrLine[], reach: number): OcrLine | null {
  const h = Math.max(1, line.bottom - line.top);
  const below = lines
    .filter((l) => l !== line && l.page === line.page && l.top >= line.bottom - h * 0.3 && l.top <= line.bottom + h * reach && l.left < line.right && l.right > line.left)
    .sort((a, b) => a.top - b.top);
  return below.find((l) => tokens(l.norm).nums.length > 0) ?? null;
}

// The whole row: what follows the label, plus the text boxes to its right on the same line.
function rowItems(label: OcrLine, after: string, lines: OcrLine[], reach = 0.6): { text: string; line: OcrLine }[] {
  const h = Math.max(1, label.bottom - label.top);
  const cy = (label.top + label.bottom) / 2;
  const right = lines
    .filter((l) => l !== label && l.page === label.page && l.left >= label.right - h * 0.5 && Math.abs((l.top + l.bottom) / 2 - cy) <= h * reach)
    .sort((a, b) => a.left - b.left);
  return [{ text: after, line: label }, ...right.map((l) => ({ text: l.norm, line: l }))];
}

function valueFromRow(items: { text: string; line: OcrLine }[], lines: OcrLine[]) {
  const res = pickValue(items.map((i) => i.text).join(' '));
  if (res.v !== null && res.lo === null) {
    // Some sheets print the range on the line under the value.
    const holder = items.find((i) => tokens(i.text).nums.some((n) => n.v === res.v));
    const under = holder ? lineBelow(holder.line, lines, 1.6) : null;
    const m = under ? RANGE_START.exec(clean(under.norm)) : null;
    if (m) return { v: res.v, lo: toNum(m[1]), hi: toNum(m[2]) };
  }
  return res;
}

type LabelOwner = { label: string; owner: string };

function allLabels(tpl: Template): LabelOwner[] {
  const out: LabelOwner[] = [];
  for (const [key, labels] of Object.entries(tpl.labels)) for (const l of labels) out.push({ label: normalize(l), owner: key });
  if (tpl.segments) {
    for (const [k, labels] of Object.entries(tpl.segments.sections)) for (const l of labels) out.push({ label: normalize(l), owner: 'section_' + k });
    for (const [k, labels] of Object.entries(tpl.segments.parts)) for (const l of labels) out.push({ label: normalize(l), owner: 'part_' + k });
  }
  for (const l of tpl.balance ?? []) out.push({ label: normalize(l), owner: 'balance' });
  for (const l of tpl.ignore ?? []) out.push({ label: normalize(l), owner: 'ignore' });
  return out;
}

// Every line where one of the metric's labels appears on its own
// (not inside a longer label of something else, like WEIGHT inside TARGET WEIGHT).
// Exact matches come first; near matches (small reading mistakes) only if nothing matched exactly.
function findLabels(lines: OcrLine[], key: string, labels: string[], every: LabelOwner[]) {
  for (const fuzzy of [false, true]) {
    const hits: { line: OcrLine; after: string }[] = [];
    for (const line of lines) {
      // Near matches skip lines with a known other word ("ΛΙΠΟΥΣ" is not "ΛΙΠΟΣ")
      if (fuzzy && every.some((o) => o.owner === 'ignore' && labelRe(o.label).test(line.norm))) continue;
      for (const label of labels) {
        const after = matchLabel(line, label, fuzzy);
        if (after === null) continue;
        const n = normalize(label);
        const blocked = every.some((o) => o.owner !== key && o.label.length > n.length && o.label.includes(n) && labelRe(o.label).test(line.norm));
        if (!blocked) {
          hits.push({ line, after });
          break;
        }
      }
    }
    if (hits.length) return hits;
  }
  return [];
}

// ---------- Arms, legs and trunk around a body figure (Tanita) ----------

type Panels = NonNullable<Template['panels']>;

// Short one-word titles ("Λίπος", "Μύες") count only when they are the whole line.
function titleMatch(line: OcrLine, label: string): boolean {
  const n = normalize(label);
  if (!n.includes(' ') && n.length <= 6) return line.norm.replace(/[^A-ZΑ-Ω%()]/g, '') === n.replace(/[^A-ZΑ-Ω%()]/g, '');
  return labelRe(label).test(line.norm) || line.norm.includes(n);
}

const centerX = (l: OcrLine) => (l.left + l.right) / 2;
const centerY = (l: OcrLine) => (l.top + l.bottom) / 2;

function readPanels(lines: OcrLine[], p: Panels): Record<string, ReadField> {
  type Anchor = { line: OcrLine; kind: 'lean' | 'fat' | null; trunk: number | null };
  const anchors: Anchor[] = [];
  const titles: { line: OcrLine; kind: 'lean' | 'fat' }[] = [];
  for (const line of lines) {
    for (const kind of ['fat', 'lean'] as const) {
      if (p.titles[kind].some((t) => titleMatch(line, t))) titles.push({ line, kind });
      if (p.heads[kind].some((t) => line.norm.replace(/\s+/g, '').includes(normalize(t).replace(/\s+/g, '')))) anchors.push({ line, kind, trunk: null });
    }
    // "ΚΟΡΜΟΣ 11.40 kg": the trunk value starts a panel (rows of scores have no kg)
    for (const label of p.trunk) {
      const after = matchLabel(line, label);
      if (after === null) continue;
      const row = rowItems(line, after, lines).map((x) => x.text).join(' ');
      const m = /^\D*?(\d+[.,]\d+)\s*KG/.exec(row);
      if (m) anchors.push({ line, kind: null, trunk: toNum(m[1]) });
      break;
    }
  }
  // Which kind a trunk panel is: the nearest title above it.
  for (const a of anchors) {
    if (a.kind) continue;
    let best = Infinity;
    for (const t of titles) {
      if (t.line.page !== a.line.page || t.line.top > a.line.top) continue;
      const d = Math.abs(centerY(a.line) - centerY(t.line)) + Math.abs(centerX(a.line) - centerX(t.line));
      if (d < best) {
        best = d;
        a.kind = t.kind;
      }
    }
  }
  const out: Record<string, ReadField> = {};
  const put = (key: string, v: number, page: number, d: number, dist: Record<string, number>) => {
    if (!plausible(key, v)) return;
    if (dist[key] !== undefined && dist[key] <= d) return;
    dist[key] = d;
    out[key] = { value: v, lo: null, hi: null, page, unclear: false };
  };
  const dist: Record<string, number> = {};
  for (const a of anchors) if (a.kind && a.trunk !== null) put(`${a.kind}_tr`, a.trunk, a.line.page, 0, dist);

  // A value box: a line with one number with decimals (and maybe "kg").
  const boxes = lines.filter((l) => /^\D{0,3}\d+[.,]\d+\s*(KG)?\W*$/.test(l.norm));
  const has = (line: OcrLine, words: string[]) => words.some((w) => labelRe(w).test(line.norm) || line.norm.startsWith(normalize(w)));
  for (const line of lines) {
    const limb = has(line, p.arm) ? 'a' : has(line, p.leg) ? 'l' : null;
    if (!limb || /\d/.test(line.norm)) continue;
    // The value box is the nearest one just above or under the label, in the same column.
    const h = Math.max(1, line.bottom - line.top);
    let box: OcrLine | null = null;
    let gap = Infinity;
    for (const b of boxes) {
      if (b.page !== line.page || b.left >= line.right + h || b.right <= line.left - h) continue;
      const g = b.top >= line.top ? b.top - line.bottom : line.top - b.bottom;
      if (g < -h * 0.3 || g > h * 3.5) continue;
      if (g < gap) {
        gap = g;
        box = b;
      }
    }
    if (!box) continue;
    // Its panel: the nearest panel start above it.
    let anchor: Anchor | null = null;
    let best = Infinity;
    for (const a of anchors) {
      if (!a.kind || a.line.page !== line.page || a.line.top > line.top) continue;
      const d = Math.abs(centerY(line) - centerY(a.line)) + Math.abs(centerX(line) - centerX(a.line));
      if (d < best) {
        best = d;
        anchor = a;
      }
    }
    if (!anchor) continue;
    const side = has(line, p.left) ? 'l' : has(line, p.right) ? 'r' : centerX(box) < centerX(anchor.line) ? 'l' : 'r';
    const v = toNum(/(\d+[.,]\d+)/.exec(box.norm)?.[1] ?? '');
    if (!isNaN(v)) put(`${anchor.kind}_${side}${limb}`, v, line.page, best + gap, dist);
  }
  return out;
}

// ---------- Sheet details ----------

function validDate(y: number, mo: number, d: number, h = 0, mi = 0): Date | null {
  if (y < 1900 || y > 2100 || mo < 1 || mo > 12 || d < 1 || d > 31 || h > 23 || mi > 59) return null;
  const date = new Date(y, mo - 1, d, h, mi);
  return date.getMonth() === mo - 1 ? date : null;
}

function findDate(text: string): Date | null {
  const ymd = /(\d{4})[./-](\d{1,2})[./-](\d{1,2})(?:[^0-9]{1,3}(\d{1,2})[:.](\d{2}))?/g;
  const dmy = /(\d{1,2})[./-](\d{1,2})[./-](\d{4})(?:[^0-9]{1,3}(\d{1,2})[:.](\d{2}))?/g;
  const tryText = (s: string): Date | null => {
    let m: RegExpExecArray | null;
    ymd.lastIndex = 0;
    while ((m = ymd.exec(s))) {
      const d = validDate(+m[1], +m[2], +m[3], m[4] ? +m[4] : 9, m[5] ? +m[5] : 0);
      if (d && d.getFullYear() >= 2000) return d;
    }
    dmy.lastIndex = 0;
    while ((m = dmy.exec(s))) {
      const d = validDate(+m[3], +m[2], +m[1], m[4] ? +m[4] : 9, m[5] ? +m[5] : 0);
      if (d && d.getFullYear() >= 2000) return d;
    }
    return null;
  };
  const anchor = /(TEST DATE|DATE|HMEPOMHNIA)/.exec(text);
  if (anchor) {
    const near = tryText(text.slice(anchor.index, anchor.index + 80));
    if (near) return near;
  }
  return tryText(text);
}

function readAbout(text: string): About {
  let height: number | null = null;
  const h1 = /(HEIGHT|YΨOΣ)[^0-9]{0,12}(\d{2,3}(?:[.,]\d)?)/.exec(text);
  if (h1 && toNum(h1[2]) >= 100 && toNum(h1[2]) <= 250) height = toNum(h1[2]);
  let afterHeight = -1;
  const re = /(\d{3}(?:[.,]\d)?)\s*CM\b/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    const v = toNum(m[1]);
    if (v >= 120 && v <= 230) {
      if (height === null) height = v;
      afterHeight = m.index + m[0].length;
      break;
    }
  }
  let age: number | null = null;
  const ageRe = /\b(AGE|HΛIKIA)\b[^0-9]{0,8}(\d{1,3})\b(?![.,]\d)/g;
  let a: RegExpExecArray | null;
  while ((a = ageRe.exec(text))) {
    // "METABOLIC AGE" / "Μεταβολική ηλικία" is not the person's age
    if (/(METABOLIC|METABOΛIKH)\s*$/.test(text.slice(Math.max(0, a.index - 14), a.index))) continue;
    if (+a[2] >= 5 && +a[2] <= 110) age = +a[2];
    break;
  }
  if (age === null && afterHeight > 0) {
    // InBody prints the age right after the height: "180cm 56"
    const n = /^\s*(\d{1,3})\b/.exec(text.slice(afterHeight));
    if (n && +n[1] >= 5 && +n[1] <= 110) age = +n[1];
  }

  let sex: 'male' | 'female' | null = null;
  const s = /\b(GENDER|SEX)\b[^A-Z]{0,6}(FEMALE|MALE|F|M)\b/.exec(text);
  const man = /ANΔPAΣ|AΓOPI/.test(text);
  const woman = /ΓYNAIKA|KOPITΣI/.test(text);
  if (s) sex = s[2].startsWith('F') ? 'female' : 'male';
  // Sheets with both words and tick boxes ("☑ Άνδρας ☐ Γυναίκα") are left for the user to choose.
  else if (man && !woman) sex = 'male';
  else if (woman && !man) sex = 'female';

  let birth: Date | null = null;
  const b = /(BIRTH|DOB|D\.O\.B|ΓENNHΣHΣ)[^0-9]{0,15}(\d{1,4})[./-](\d{1,2})[./-](\d{1,4})/.exec(text);
  if (b) birth = b[2].length === 4 ? validDate(+b[2], +b[3], +b[4]) : validDate(+b[4], +b[3], +b[2]);
  if (!birth) {
    // InBody prints the birth date in brackets under the age: "(10.01.1970.)"
    const p = /\((\d{1,2})[./-](\d{1,2})[./-](\d{4})\.?\)/.exec(text);
    if (p) birth = validDate(+p[3], +p[2], +p[1]);
  }
  return { height, age, sex, birth };
}

// ---------- Putting it together ----------

// Lines in reading order: row by row (lines at about the same height), left to right.
export function readingOrder(lines: OcrLine[]): OcrLine[] {
  const byTop = [...lines].sort((a, b) => a.page - b.page || a.top - b.top);
  const rows: OcrLine[][] = [];
  for (const l of byTop) {
    const row = rows[rows.length - 1];
    const first = row?.[0];
    const h = first ? Math.max(1, first.bottom - first.top) : 0;
    if (first && first.page === l.page && Math.abs((l.top + l.bottom) / 2 - (first.top + first.bottom) / 2) <= h * 0.5) row.push(l);
    else rows.push([l]);
  }
  return rows.flatMap((r) => r.sort((a, b) => a.left - b.left));
}

export function parse(lines: OcrLine[], machineId?: string): ReadResult {
  const sorted = [...lines].sort((a, b) => a.page - b.page || a.top - b.top || a.left - b.left);
  const ordered = readingOrder(lines);
  const fullText = ordered.map((l) => l.norm).join('\n');
  const found = detectMachine(fullText);
  const m = machineId ? getMachine(machineId) : found ?? getMachine('other');
  const fields: Record<string, ReadField> = {};
  const width = (page: number) => Math.max(1, ...sorted.filter((l) => l.page === page).map((l) => l.right));

  const tpl = m.template;
  const rows: Record<string, string> = {};
  const hitRows: Record<string, string[]> = {};
  if (tpl) {
    const every = allLabels(tpl);
    for (const [key, labels] of Object.entries(tpl.labels)) {
      const hits = findLabels(sorted, key, labels, every);
      let best: ReadField | null = null;
      for (const hit of hits) {
        let items = rowItems(hit.line, hit.after, sorted);
        let r = valueFromRow(items, sorted);
        if (r.v === null) {
          // Some values sit under their title ("InBody score" / "54/100 points").
          const under = tpl.below?.includes(key) ? (tpl.belowReach ? numberBelow(hit.line, sorted, tpl.belowReach) : lineBelow(hit.line, sorted)) : null;
          if (under) {
            items = rowItems(under, under.norm, sorted);
            r = valueFromRow(items, sorted);
            if (r.v !== null && tpl.tableLast?.includes(key)) {
              // A table row under the header (phase angle is the last column); dashes there are empty cells, not signs
              const nums = (items.map((x) => x.text).join(' ').match(/\d+(?:[.,]\d+)?/g) ?? []).map(toNum).filter((n) => plausible(key, n));
              if (nums.length) r = { v: nums[nums.length - 1], lo: null, hi: null };
            }
          }
        }
        const fix = (v: number) => (key === 'ecw_ratio' && v > 1 ? v / 100 : v);
        if (tpl.tallRows && (r.v === null || !plausible(key, fix(r.v)))) {
          const tall = rowItems(hit.line, hit.after, sorted, 1.6);
          const t2 = pickValue(tall.map((x) => x.text).join(' '), (n) => plausible(key, fix(n)));
          if (t2.v !== null && plausible(key, fix(t2.v))) {
            r = t2;
            items = tall;
          }
        }
        if (r.v === null) continue;
        let value = r.v;
        if (key === 'ecw_ratio' && value > 1) value = value / 100; // printed as %
        const field = { value, lo: r.lo, hi: r.hi, page: hit.line.page, unclear: !plausible(key, value) };
        if (!field.unclear) {
          if (field.lo === null && tpl.tallRows) {
            // The same number may be printed again elsewhere with its normal range ("18.00 kg 8.4 - 19.2")
            for (const other of hits) {
              if (other === hit) continue;
              const o = valueFromRow(rowItems(other.line, other.after, sorted), sorted);
              if (o.v !== null && o.lo !== null && Math.abs(fix(o.v) - value) < 0.001) {
                field.lo = o.lo;
                field.hi = o.hi;
                break;
              }
            }
          }
          best = field;
          rows[key] = items.map((x) => x.text).join(' ') + ' ' + (lineBelow(items[items.length - 1].line, sorted, 1.2)?.norm ?? '');
          break;
        }
        best = best ?? field;
      }
      fields[key] = best ?? { value: null, lo: null, hi: null, page: null, unclear: true };
      hitRows[key] = hits.map((hit) => rowItems(hit.line, hit.after, sorted, 1.6).map((x) => x.text).join(' '));
    }

    // "11.60 kg 26.2 %": the % of body weight printed next to a kg value, when the sheet has no label of its own for it.
    for (const [key, from] of Object.entries(tpl.pctOfWeight ?? {})) {
      if (fields[key]?.value != null && !fields[key].unclear) continue;
      const kg = fields[from]?.value;
      const weight = fields.weight?.value;
      if (kg == null || !weight) continue;
      const expected = (kg / weight) * 100;
      const texts = [rows[from] ?? '', ...(hitRows[from] ?? [])];
      let found: number | null = null;
      for (const text of texts) {
        const n = tokens(text).nums.find((x) => Math.abs(x.v - expected) <= 0.8 && x.v !== kg);
        if (n) {
          found = n.v;
          break;
        }
      }
      if (found !== null) fields[key] = { value: found, lo: null, hi: null, page: fields[from].page, unclear: !plausible(key, found) };
    }

    if (tpl.panels) Object.assign(fields, readPanels(sorted, tpl.panels));

    if (tpl.segments) {
      const seg = tpl.segments;
      const kinds = ['lean', 'fat', 'ecw'] as const;
      const headers = kinds.map((k) => {
        for (const fuzzy of [false, true]) for (const line of sorted) for (const label of seg.sections[k]) if (matchLabel(line, label, fuzzy) !== null) return line;
        return null;
      });
      const sameColumn = (a: OcrLine, b: OcrLine) => Math.abs(a.left - b.left) < width(a.page) * 0.2;
      kinds.forEach((kind, i) => {
        const header = headers[i];
        const region = header
          ? sorted.filter(
              (l) =>
                l.page === header.page &&
                l.top > header.top &&
                !headers.some((o) => o && o !== header && o.page === header.page && o.top > header.top && sameColumn(o, header) && l.top >= o.top),
            )
          : [];
        for (const part of PARTS) {
          const key = `${kind}_${part}`;
          if (kind === 'ecw' && seg.ecwInLeanRow) continue;
          let hit: { line: OcrLine; after: string } | null = null;
          for (const line of region) {
            if (header && !sameColumn(line, header)) continue;
            for (const label of seg.parts[part]) {
              const after = matchLabel(line, label, true);
              if (after !== null) {
                hit = { line, after };
                break;
              }
            }
            if (hit) break;
          }
          // Body part rows are two bars high (kg and %), so the row is taller and the value must fit the body part.
          const items = hit ? rowItems(hit.line, hit.after, sorted, 1.6) : [];
          const { v } = hit ? pickValue(items.map((x) => x.text).join(' '), (n) => plausible(key, n)) : { v: null };
          fields[key] = { value: v, lo: null, hi: null, page: hit ? hit.line.page : null, unclear: v === null || !plausible(key, v) };
          if (kind === 'lean' && seg.ecwInLeanRow) {
            // The ECW ratio of each body part is printed at the end of its lean row (0.3–0.45).
            const nums = hit ? tokens(items.map((x) => x.text).join(' ')).nums.map((n) => n.v).filter((n) => n >= 0.3 && n <= 0.45) : [];
            const e = nums.length ? nums[nums.length - 1] : null;
            fields[`ecw_${part}`] = { value: e, lo: null, hi: null, page: hit ? hit.line.page : null, unclear: e === null };
          }
        }
      });
    }

    if (tpl.balance) {
      let value: number | null = null;
      const idx = tpl.balance.map((l) => fullText.indexOf(normalize(l))).filter((i) => i >= 0)[0];
      if (idx !== undefined) {
        const segText = fullText.slice(idx, idx + 200);
        value = /EXTREMELY/.test(segText) ? 2 : /SLIGHTLY/.test(segText) ? 1 : /BALANCED/.test(segText) ? 0 : null;
      }
      fields.balance = { value, lo: null, hi: null, page: null, unclear: value === null };
    }
  }

  const pageNumbers = Array.from(new Set(sorted.map((l) => l.page))).sort((a, b) => a - b);
  const maxPage = pageNumbers.length ? pageNumbers[pageNumbers.length - 1] : 0;
  const pages: PageInfo[] = [];
  for (let p = 1; p <= maxPage; p++) {
    const text = ordered.filter((l) => l.page === p).map((l) => l.norm).join('\n');
    pages.push({ date: findDate(text), machineId: detectMachine(text)?.id ?? null });
  }

  return {
    machineId: m.id,
    detected: !!found && (!machineId || found.id === machineId),
    fields,
    about: readAbout(fullText),
    date: findDate(fullText),
    pages,
    textFound: sorted.length > 0,
  };
}
