// One sheet in a list: date, machine, weight and change since the previous scan.
import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { router } from 'expo-router';
import { Bubble, Icon, Muted } from './ui';
import { C } from './theme';
import { Scan } from './api';
import { machineName } from './machines';
import { Units, fmtDate, fmtDelta, fmtMetric, parseLocal } from './format';

export function weightChange(scans: Scan[], index: number): number | null {
  const cur = scans[index]?.values.weight?.v;
  for (let i = index - 1; i >= 0; i--) {
    const prev = scans[i].values.weight?.v;
    if (prev !== undefined && cur !== undefined) return cur - prev;
  }
  return null;
}

export function SheetRow({ scan, change, units, last }: { scan: Scan; change: number | null; units: Units; last?: boolean }) {
  const d = parseLocal(scan.scanned_at);
  const w = scan.values.weight?.v;
  return (
    <Pressable
      accessibilityRole="button"
      onPress={() => router.push(`/sheet/${scan.id}`)}
      style={{ minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: last ? 0 : 1, borderBottomColor: C.soft }}
    >
      <Bubble icon="sheet" radius={12} />
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 15, fontWeight: '600', color: C.ink }}>{d ? fmtDate(d) : scan.scanned_at}</Text>
        <Muted>{machineName(scan.machine)}</Muted>
      </View>
      <View style={{ alignItems: 'flex-end' }}>
        {w !== undefined && <Text style={{ fontSize: 15, fontWeight: '700', color: C.ink }}>{fmtMetric('weight', w, units)}</Text>}
        {change !== null && <Muted>{fmtDelta('weight', change, units)}</Muted>}
      </View>
    </Pressable>
  );
}
