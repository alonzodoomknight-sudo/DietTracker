// Local reminder the day before the next scan, at 18:00. No server needed.
// Also: appointments (the day before at 18:00 and 1 hour before), meal times from the plan, and water.
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { t } from './i18n';
import { addDays, fmtTime, parseLocal } from './format';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

export async function askNotificationPermission(): Promise<boolean> {
  try {
    const current = await Notifications.getPermissionsAsync();
    if (current.granted) return true;
    const asked = await Notifications.requestPermissionsAsync();
    return asked.granted;
  } catch {
    return false;
  }
}

export function reminderDate(nextScan: string | null): Date | null {
  const d = parseLocal(nextScan);
  if (!d) return null;
  const r = addDays(d, -1);
  r.setHours(18, 0, 0, 0);
  return r;
}

export type Extra =
  | { kind: 'appointment'; at: string; title: string; video: boolean }
  | { kind: 'meal'; meal: number; time: string }
  | { kind: 'water'; time: string };

let extras: Extra[] = [];

export function setExtras(list: Extra[]) {
  extras = list;
}

const MEAL_KEYS = ['n_meal_0', 'n_meal_1', 'n_meal_2', 'n_meal_3', 'n_meal_4'] as const;

export async function scheduleReminder(nextScan: string | null, enabled: boolean): Promise<void> {
  try {
    await Notifications.cancelAllScheduledNotificationsAsync();
    const scan = parseLocal(nextScan);
    const when = reminderDate(nextScan);
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('reminders', {
        name: t('n_channel'),
        importance: Notifications.AndroidImportance.DEFAULT,
      });
    }
    if (enabled && scan && when && when.getTime() > Date.now()) {
      await Notifications.scheduleNotificationAsync({
        content: { title: t('n_title'), body: t('n_body', { time: fmtTime(scan) }) },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when, channelId: 'reminders' },
      });
    }
    await scheduleExtras();
  } catch {
    // Reminders are a convenience; the app keeps working without them.
  }
}

async function scheduleExtras(): Promise<void> {
  for (const x of extras) {
    try {
      if (x.kind === 'appointment') {
        const at = parseLocal(x.at);
        if (!at) continue;
        const dayBefore = addDays(at, -1);
        dayBefore.setHours(18, 0, 0, 0);
        const hourBefore = new Date(at.getTime() - 3600000);
        const content = { title: x.title || t('n_appt_soon'), body: t(x.video ? 'n_appt_video' : 'n_appt_at', { time: fmtTime(at) }), data: { screen: 'appointments' } };
        for (const d of [dayBefore, hourBefore]) {
          if (d.getTime() > Date.now()) {
            await Notifications.scheduleNotificationAsync({ content, trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: d, channelId: 'reminders' } });
          }
        }
      } else {
        const [h, m] = x.time.split(':').map(Number);
        const content =
          x.kind === 'meal'
            ? { title: t(MEAL_KEYS[x.meal] ?? 'n_meal_0'), body: t('n_meal_body'), data: { screen: 'plan' } }
            : { title: t('n_water_title'), body: t('n_water_body'), data: { screen: 'water' } };
        await Notifications.scheduleNotificationAsync({
          content,
          trigger: { type: Notifications.SchedulableTriggerInputTypes.DAILY, hour: h, minute: m, channelId: 'reminders' },
        });
      }
    } catch {
      // skip this one
    }
  }
}
