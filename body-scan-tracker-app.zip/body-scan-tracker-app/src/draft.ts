// The scan being added or edited, shared by the Snap, Reading and Check screens.
import { useSyncExternalStore } from 'react';
import { OcrLine, ReadResult, parse } from './reader';
import { Me, Scan, ScanInput, Val } from './api';
import { machine } from './machines';
import { lang } from './i18n';
import { parseLocal, parseNum, toLocal } from './format';

export type DraftField = { text: string; lo: number | null; hi: number | null; page: number | null; unclear: boolean };

type Draft = {
  pages: string[]; // local photo files, in page order
  lines: OcrLine[]; // text read from the pages
  editingId: number | null;
  machineId: string;
  detected: boolean;
  date: Date;
  fields: Record<string, DraftField>;
  height: string;
  age: string;
  birth: Date | null;
  sex: 'male' | 'female' | null;
  showAll: boolean;
};

const fresh = (): Draft => ({
  pages: [],
  lines: [],
  editingId: null,
  machineId: 'other',
  detected: false,
  date: new Date(),
  fields: {},
  height: '',
  age: '',
  birth: null,
  sex: null,
  showAll: false,
});

export let draft: Draft = fresh();
export const getDraft = () => draft;
let version = 0;
const listeners = new Set<() => void>();

function changed() {
  version++;
  listeners.forEach((l) => l());
}

export function useDraft(): Draft {
  useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => {
        listeners.delete(l);
      };
    },
    () => version,
  );
  return draft;
}

export const numText = (v: number | null | undefined) => {
  if (v === null || v === undefined) return '';
  const s = String(Math.round(v * 1000) / 1000);
  return lang() === 'el' ? s.replace('.', ',') : s;
};

export function resetDraft() {
  draft = fresh();
  changed();
}

export function addPage(uri: string, at?: number) {
  const pages = [...draft.pages];
  if (at !== undefined && at < pages.length) pages[at] = uri;
  else pages.push(uri);
  draft = { ...draft, pages };
  changed();
}

export function removePage(index: number) {
  draft = { ...draft, pages: draft.pages.filter((_, i) => i !== index) };
  changed();
}

export function applyRead(result: ReadResult, lines: OcrLine[], keepMachine = false) {
  const fields: Record<string, DraftField> = {};
  for (const [key, f] of Object.entries(result.fields)) {
    fields[key] = { text: numText(f.value), lo: f.lo, hi: f.hi, page: f.page, unclear: f.unclear };
  }
  const a = result.about;
  draft = {
    ...draft,
    lines,
    machineId: keepMachine ? draft.machineId : result.machineId,
    detected: keepMachine ? draft.detected : result.detected,
    date: result.date ?? draft.date,
    fields,
    height: a.height !== null ? numText(a.height) : draft.height,
    age: a.age !== null ? String(a.age) : draft.age,
    birth: a.birth ?? draft.birth,
    sex: a.sex ?? draft.sex,
    showAll: !machine(result.machineId).template,
  };
  changed();
}

// Fills the draft from the user's profile (used before reading a sheet).
export function prefillAbout(me: Me | null) {
  if (!me) return;
  draft = {
    ...draft,
    height: me.height_cm !== null ? numText(me.height_cm) : draft.height,
    age: me.age !== null ? String(me.age) : draft.age,
    birth: parseLocal(me.birth_date) ?? draft.birth,
    sex: me.sex ?? draft.sex,
  };
  changed();
}

export function loadFromScan(scan: Scan, me: Me | null) {
  draft = fresh();
  prefillAbout(me);
  const fields: Record<string, DraftField> = {};
  for (const [key, v] of Object.entries(scan.values)) {
    fields[key] = { text: numText(v.v), lo: v.lo ?? null, hi: v.hi ?? null, page: v.p ?? null, unclear: false };
  }
  draft = {
    ...draft,
    editingId: scan.id,
    machineId: scan.machine,
    detected: true,
    date: parseLocal(scan.scanned_at) ?? new Date(),
    fields,
    showAll: !machine(scan.machine).template,
  };
  changed();
}

export function setField(key: string, text: string) {
  const old = draft.fields[key] ?? { text: '', lo: null, hi: null, page: null, unclear: false };
  draft = { ...draft, fields: { ...draft.fields, [key]: { ...old, text, unclear: false } } };
  changed();
}

export function setDraft(patch: Partial<Draft>) {
  draft = { ...draft, ...patch };
  changed();
}

// Changing the machine reads the same pages again with that machine's template.
export function setMachine(id: string) {
  const m = machine(id);
  if (m.template && draft.lines.length) {
    draft = { ...draft, machineId: id, detected: false };
    applyRead(parse(draft.lines, id), draft.lines, true);
  } else {
    draft = { ...draft, machineId: id, detected: false, showAll: draft.showAll || !m.template };
    changed();
  }
}

export function unclearCount(): number {
  return Object.values(draft.fields).filter((f) => f.unclear).length;
}

// Turns the draft into what the server stores. Returns an error key if something is wrong.
export function draftToInput(): { input?: ScanInput; error?: 'c_need_one' | 'c_bad_number' } {
  const values: Record<string, Val> = {};
  for (const [key, f] of Object.entries(draft.fields)) {
    const n = parseNum(f.text);
    if (n === null) continue;
    if (Number.isNaN(n)) return { error: 'c_bad_number' };
    values[key] = { v: n, lo: f.lo, hi: f.hi, p: draft.pages.length > 1 ? f.page : null };
  }
  if (!Object.keys(values).length) return { error: 'c_need_one' };
  return { input: { machine: draft.machineId, scanned_at: toLocal(draft.date), values } };
}
