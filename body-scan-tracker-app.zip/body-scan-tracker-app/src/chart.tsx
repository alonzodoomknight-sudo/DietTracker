// Small line chart for the progress cards.
import React, { useState } from 'react';
import { View } from 'react-native';
import Svg, { Circle, Path } from 'react-native-svg';
import { C } from './theme';

export function Sparkline({ values, height = 56, color = C.accent, label }: { values: number[]; height?: number; color?: string; label?: string }) {
  const [width, setWidth] = useState(0);
  const pad = 6;
  let path = '';
  let last: [number, number] | null = null;
  if (width > 0 && values.length) {
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min || 1;
    const pts = values.map((v, i): [number, number] => [
      values.length === 1 ? width / 2 : pad + ((width - 2 * pad) * i) / (values.length - 1),
      pad + (height - 2 * pad) * (1 - (v - min) / range),
    ]);
    path = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
    last = pts[pts.length - 1];
  }
  return (
    <View
      accessible={!!label}
      accessibilityLabel={label}
      accessibilityRole={label ? 'image' : undefined}
      style={{ height }}
      onLayout={(e) => setWidth(e.nativeEvent.layout.width)}
    >
      {width > 0 && (
        <Svg width={width} height={height}>
          {values.length > 1 && <Path d={path} stroke={color} strokeWidth={3} fill="none" strokeLinecap="round" strokeLinejoin="round" />}
          {last && <Circle cx={last[0]} cy={last[1]} r={4.5} fill={color} />}
        </Svg>
      )}
    </View>
  );
}
