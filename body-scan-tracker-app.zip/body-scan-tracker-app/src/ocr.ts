// Reads the text of one photo. First on your own server (Tesseract: Greek and English),
// and if the server can't be reached, on the phone (ML Kit: Latin letters only). No AI.
import { OcrLine, makeLine, readPageOnPhone } from './reader';
import { serverOcr } from './store';

export async function readPage(uri: string, page: number): Promise<OcrLine[]> {
  try {
    const boxes = await serverOcr(uri);
    if (boxes.length) return boxes.map((b) => makeLine(b.text, b, page));
  } catch {
    // no server or no connection: read on the phone instead
  }
  return readPageOnPhone(uri, page);
}
