// Body scan machines and their templates.
// A template tells the reader which printed label belongs to which number.
// Labels are written in capitals, the way the text reader returns them after cleaning.
// To support a new machine model, add a template here (test it on real sheets first).
import { t, Key } from './i18n';

export type Template = {
  pages: number; // how many pages this machine normally prints
  labels: Record<string, string[]>; // metric key -> printed labels (Greek and English)
  segments?: {
    sections: Record<'lean' | 'fat' | 'ecw', string[]>; // section titles on the sheet
    parts: Record<'ra' | 'la' | 'tr' | 'rl' | 'll', string[]>; // row labels inside a section
    ecwInLeanRow?: boolean; // ECW ratio of each body part printed at the end of its lean row
  };
  balance?: string[]; // label of the body balance line
  below?: string[]; // metrics whose value is printed under the title, not next to it
  ignore?: string[]; // titles that contain a label but are not that number
  belowReach?: number; // how far down (in line heights) to look for a value printed under its title
  tallRows?: boolean; // a label can sit between two printed lines ("BMR" next to "1975 kcal" and "8263 kJ")
  tableLast?: string[]; // metrics read from the row under a table header, where the value is the last number
  pctOfWeight?: Record<string, string>; // "% of body weight" printed next to a kg value (pbf next to fat mass)
  // Arms, legs and trunk drawn around a body figure (Tanita): "ΚΟΡΜΟΣ 11.40 kg", then a value box at each hand and foot.
  panels?: {
    trunk: string[]; // trunk label, followed by its value
    heads: Record<'lean' | 'fat', string[]>; // headings that start a panel with no trunk value (children's sheet)
    titles: Record<'lean' | 'fat', string[]>; // section titles that tell if a panel shows fat or muscle
    arm: string[];
    leg: string[];
    left: string[]; // words that name the side in a label ("Αριστερό Χέρι")
    right: string[];
  };
};

export type Machine = {
  id: string;
  name?: string; // brand names are not translated
  nameKey?: Key;
  detect?: RegExp; // matched against the whole sheet text (capitals, spaces removed)
  template?: Template;
};

// InBody sheets print the same names in every model; Greek and English sheets are both covered.
const INBODY_LABELS: Record<string, string[]> = {
  weight: ['Βάρος', 'WEIGHT'],
  smm: ['Σκελετική Μυϊκή Μάζα', 'Σκελετική', 'SKELETAL MUSCLE MASS', 'SMM'],
  fat_mass: ['Λιπώδης Μάζα Σώματος', 'Λιπώδης Μάζα', 'BODY FAT MASS'],
  pbf: ['Ποσοστό Λίπους', 'PERCENT BODY FAT', 'PBF'],
  bmi: ['Δ.Μ.Σ.', 'Δ.Μ.Σ', 'ΔΜΣ', 'BODY MASS INDEX', 'BMI'],
  vfa: ['Περιοχή σπλαχνικού λίπους', 'VISCERAL FAT AREA', 'VFA'],
  vfl: ['Επίπεδο Σπλαχνικού Λίπους', 'VISCERAL FAT LEVEL'],
  whr: ['Αναλογία Μέσης/Γοφών', 'Αναλογία Μέσης', 'WAIST-HIP RATIO', 'WAIST HIP RATIO', 'WHR'],
  obesity_degree: ['Βαθμός Παχυσαρκίας', 'OBESITY DEGREE'],
  score: ['Επίδοση InBody', 'INBODY SCORE'],
  tbw: ['Συν. Σωματικά Υγρά', 'Συν. Σωματικά', 'TOTAL BODY WATER', 'TBW'],
  icw: ['Ενδοκυττάρια Υγρά', 'Ενδοκυττάρια', 'INTRACELLULAR WATER', 'ICW'],
  ecw: ['Εξωκυττάρια Υγρά', 'Εξωκυττάρια', 'EXTRACELLULAR WATER', 'ECW'],
  ecw_ratio: ['Αναλογία ECW', 'ECW RATIO', 'ECW/TBW'],
  tbw_ffm: ['TBW/FFM'],
  protein: ['Πρωτεΐνη', 'PROTEIN'],
  minerals: ['Ανόργανα στοιχεία', 'Ανόργανα', 'MINERALS', 'MINERAL'],
  bmc: ['Περιεκτικότητα Οστών', 'BONE MINERAL CONTENT', 'BMC'],
  ffm: ['Άλιπη Μάζα', 'FAT FREE MASS', 'FFM'],
  slm: ['Μαλακή Άλιπη Μάζα', 'SOFT LEAN MASS', 'SLM'],
  bcm: ['Κυτταρική Μάζα Σώματος', 'BODY CELL MASS', 'BCM'],
  target_weight: ['Στόχος Βάρους', 'TARGET WEIGHT'],
  weight_control: ['Έλεγχος Βάρους', 'WEIGHT CONTROL'],
  fat_control: ['Έλεγχος Λίπους', 'FAT CONTROL'],
  muscle_control: ['Έλεγχος Μυών', 'MUSCLE CONTROL'],
  bmr: ['Βασικός Ρυθμός Μεταβολισμού', 'Βασικός Ρυθμός', 'BASAL METABOLIC RATE', 'BMR'],
  waist: ['Περίμετρος Μέσης', 'WAIST CIRCUMFERENCE'],
  arm: ['Περιφέρεια Βραχίονα', 'ARM CIRCUMFERENCE'],
  amc: ['Μυϊκή Περιφ. Βραχίονα', 'Μυϊκή Περιφ', 'ARM MUSCLE CIRCUMFERENCE', 'AMC'],
  ffmi: ['Δείκτης Άλιπης Μάζας', 'FAT FREE MASS INDEX', 'FFMI'],
  fmi: ['Δείκτης Σωματικού Λίπους', 'FAT MASS INDEX', 'FMI'],
  phase_angle: ['Γωνία Φάσης', 'PHASE ANGLE'],
  smi: ['SMI'],
};

const INBODY_PARTS = {
  ra: ['Δεξί Χέρι', 'RIGHT ARM'],
  la: ['Αριστερό Χέρι', 'LEFT ARM'],
  tr: ['Κορμός', 'TRUNK'],
  rl: ['Δεξί Πόδι', 'RIGHT LEG'],
  ll: ['Αριστερό Πόδι', 'LEFT LEG'],
};

const INBODY_570: Template = {
  pages: 1,
  labels: INBODY_LABELS,
  segments: {
    sections: {
      lean: ['Ανάλυση Τμηματικής Άλιπης', 'SEGMENTAL LEAN'],
      fat: ['Ανάλυση Τμηματικού Λίπους', 'SEGMENTAL FAT'],
      ecw: ['Τμηματική Ανάλυση ECW', 'SEGMENTAL ECW', 'ECW/TBW ANALYSIS', 'ECW RATIO ANALYSIS'],
    },
    parts: INBODY_PARTS,
  },
  balance: ['BODY BALANCE'],
  below: ['score', 'phase_angle'],
};

// InBody 770 / 770S. The result sheet can come with a second "body water" sheet; both are read as one scan.
const INBODY_770: Template = {
  pages: 1,
  labels: INBODY_LABELS,
  segments: {
    sections: {
      lean: ['Ανάλυση Τμηματικής Άλιπης', 'SEGMENTAL LEAN'],
      fat: ['Ανάλυση Τμηματικού Λίπους', 'SEGMENTAL FAT'],
      ecw: ['Τμηματική Ανάλυση ECW', 'SEGMENTAL ECW'],
    },
    parts: INBODY_PARTS,
    ecwInLeanRow: true,
  },
  below: ['score', 'phase_angle'],
};

// Tanita MC-780. English sheets, and the Greek sheets (results table, body composition analysis,
// segment analysis and the children's sheet), which print "Βιοηλεκτρική Εμπέδηση" but no model name.
const TANITA_MC780: Template = {
  pages: 1,
  labels: {
    weight: ['Βάρος', 'WEIGHT'],
    pbf: ['Λίπος %', 'Λίπος%', 'Ποσοστό Λίπους', 'BODY FAT %', 'FAT %', 'FAT%'],
    fat_mass: ['Λιπώδης Μάζα', 'Λίπος', 'FAT MASS'],
    ffm: ['Άλιπη Μάζα', 'FAT FREE MASS', 'FFM'],
    muscle_mass: ['Μυϊκή Μάζα', 'Μύες kg', 'PREDICTED MUSCLE MASS', 'MUSCLE MASS'],
    smm: ['Μάζα Σκελετικών Μυών', 'SKELETAL MUSCLE MASS'],
    tbw: ['Συνολικά υγρά σώματος', 'TOTAL BODY WATER', 'TBW'],
    tbw_pct: ['TBW %', 'TBW%'],
    ecw: ['Εξωκυττάριο υγρό', 'ECW'],
    icw: ['Ενδοκυττάριο υγρό', 'ICW'],
    ecw_ratio: ['ECW/TBW'],
    protein: ['Πρωτεΐνες', 'PROTEIN'],
    bmc: ['Οστική Μάζα', 'BONE MASS'],
    vfl: ['Σπλαχνικό Λίπος', 'Σπλαχνικό', 'VISCERAL FAT RATING', 'VISCERAL FAT'],
    bmr: ['Βασικός Μεταβολικός Ρυθμός', 'BMR', 'BASAL METABOLIC RATE'],
    metabolic_age: ['Μεταβολική ηλικία', 'Μεταβολική', 'METABOLIC AGE'],
    bmi: ['Δείκτης Μάζας Σώματος', 'BMI'],
    ffmi: ['FFMI'],
    fmi: ['BFMI', 'FMI'],
    phase_angle: ['Γωνία Φάσης', 'Φάσης', 'PHASE ANGLE'],
  },
  ignore: [
    'Βάρος Ρούχων', 'Ιδανικό βάρος', 'Προβλεπόμενο βάρος', 'Το ιδανικό σου βάρος', 'Το βάρος σου χωρίς',
    'Ιδανικό λίπος', 'Προβλεπόμενο λίπος', 'Το ιδανικό σου λίπος', 'χωρίς το λίπος', 'Ιδανική Μυϊκή Μάζα',
    'BMR/kg', 'BMR / kg', 'BMR/ kg', 'BMR /kg',
    // other forms of the same words, so near matches don't take them
    'Λίπους', 'Μυϊκής μάζας', 'Μυϊκής', 'Βάρους', 'Μεταβολικός',
  ],
  below: ['protein', 'ffm', 'tbw', 'ecw', 'icw', 'fat_mass', 'bmc', 'bmr', 'phase_angle'],
  belowReach: 8,
  tallRows: true,
  tableLast: ['phase_angle'],
  pctOfWeight: { pbf: 'fat_mass', tbw_pct: 'tbw' },
  panels: {
    trunk: ['ΚΟΡΜΟΣ', 'TRUNK'],
    heads: { fat: ['ΛΙΠΟΣ (kg)', 'ΛΙΠΟΣ(kg)'], lean: ['ΜΥΕΣ (kg)', 'ΜΥΕΣ(kg)'] },
    titles: {
      fat: ['Ανάλυση Λίπους', 'ισορροπία του λίπους', 'Λίπος', 'SEGMENTAL FAT', 'FAT'],
      lean: ['Ανάλυση Μυϊκής μάζας', 'Μυϊκής μάζας', 'ανάπτυξη των μυών', 'Μύες', 'SEGMENTAL MUSCLE', 'MUSCLE'],
    },
    arm: ['Χέρι', 'ARM'],
    leg: ['Πόδι', 'LEG'],
    left: ['Αριστερό', 'Αριστερ', 'Α.', 'LEFT'],
    right: ['Δεξί', 'Δεξ', 'Δ.', 'RIGHT'],
  },
};

export const MACHINES: Machine[] = [
  { id: 'inbody770', name: 'InBody 770', detect: /INBODY77\d/, template: INBODY_770 },
  { id: 'inbody570', name: 'InBody 570', detect: /INBODY570/, template: INBODY_570 },
  {
    id: 'tanita_mc780',
    name: 'Tanita MC-780',
    // Greek sheets: bioelectrical impedance table, clothes weight, body type, Rohrer index (children)
    detect: /MC-?780|^(?!.*INBODY).*(BIOHΛEKTPIK|EMΠEΔHΣHΣ|BAPOΣPOYX|AΘΛHTIKOΣ|ROHRER)/,
    template: TANITA_MC780,
  },
  { id: 'inbody_other', nameKey: 'm_inbody_other', detect: /INBODY/ },
  { id: 'tanita_other', nameKey: 'm_tanita_other', detect: /TANITA/ },
  { id: 'seca', name: 'seca', detect: /SECA/ },
  { id: 'evolt360', name: 'Evolt 360', detect: /EVOLT/ },
  { id: 'styku', name: 'Styku', detect: /STYKU/ },
  { id: 'dexa', name: 'DEXA', detect: /DEXA|DXA/ },
  { id: 'bodpod', name: 'Bod Pod', detect: /BODPOD/ },
  { id: 'omron', name: 'Omron', detect: /OMRON/ },
  { id: 'smart_scale', nameKey: 'm_smart_scale' },
  { id: 'other', nameKey: 'm_other' },
];

export function machine(id: string): Machine {
  return MACHINES.find((m) => m.id === id) ?? MACHINES[MACHINES.length - 1];
}

export function machineName(id: string): string {
  const m = machine(id);
  return m.name ?? (m.nameKey ? t(m.nameKey) : id);
}

// Finds the machine from the sheet text. The first match wins, so exact models come before brands.
export function detectMachine(sheetText: string): Machine | null {
  const compact = sheetText.toUpperCase().replace(/\s+/g, '');
  for (const m of MACHINES) {
    if (m.detect && m.detect.test(compact)) return m;
  }
  return null;
}
