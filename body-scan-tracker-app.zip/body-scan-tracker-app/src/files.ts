// Export (spreadsheet, PDF) and sheet photo download, save and share.
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as MediaLibrary from 'expo-media-library';
import { fetch as expoFetch } from 'expo/fetch';
import { File, Paths } from 'expo-file-system';
import { Scan, api } from './api';
import { DEMO } from './demo'; // DEMO
import { METRICS } from './metrics';
import { t } from './i18n';
import { machineName } from './machines';
import { Units, fmtDate, parseLocal } from './format';
import { metricLabel, valueText } from './labels';

async function writeFile(name: string, content: string | Uint8Array): Promise<File> {
  const file = new File(Paths.cache, name);
  if (file.exists) file.delete();
  file.create();
  await file.write(content);
  return file;
}

export async function writeBase64Jpeg(name: string, base64: string): Promise<File> {
  const file = new File(Paths.cache, name);
  if (file.exists) file.delete();
  file.create();
  await file.write(base64, { encoding: 'base64' });
  return file;
}

function usedKeys(scans: Scan[]): string[] {
  return METRICS.map((m) => m.key).filter((k) => scans.some((s) => s.values[k]));
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export async function exportSpreadsheet(scans: Scan[]): Promise<void> {
  const keys = usedKeys(scans);
  const head = [t('ex_date'), t('ex_machine'), ...keys.map((k) => metricLabel(k))];
  const rows = scans.map((s) => [s.scanned_at, machineName(s.machine), ...keys.map((k) => (s.values[k] ? String(s.values[k].v) : ''))]);
  const cell = (x: string) => (/[",;\n]/.test(x) ? `"${x.replace(/"/g, '""')}"` : x);
  const csv = '﻿' + [head, ...rows].map((r) => r.map(cell).join(',')).join('\r\n');
  const file = await writeFile('body-scans.csv', csv);
  await Sharing.shareAsync(file.uri, { mimeType: 'text/csv', UTI: 'public.comma-separated-values-text', dialogTitle: t('ex_title') });
}

export async function exportPdf(scans: Scan[], units: Units): Promise<void> {
  const sections = [...scans].reverse().map((s) => {
    const d = parseLocal(s.scanned_at);
    const rows = METRICS.filter((m) => s.values[m.key])
      .map((m) => `<tr><td>${esc(metricLabel(m.key))}</td><td class="v">${esc(valueText(m.key, s.values[m.key].v, units))}</td></tr>`)
      .join('');
    return `<h2>${esc(d ? fmtDate(d) : s.scanned_at)} · ${esc(machineName(s.machine))}</h2><table>${rows}</table>`;
  });
  const html = `<!doctype html><html><head><meta charset="utf-8"><style>
    body{font-family:-apple-system,Roboto,Arial,sans-serif;color:#15201C;padding:24px}
    h1{font-size:22px} h2{font-size:16px;margin:24px 0 8px}
    table{width:100%;border-collapse:collapse;font-size:12px}
    td{padding:5px 8px;border-bottom:1px solid #E2E6E1} td.v{text-align:right;white-space:nowrap}
  </style></head><body><h1>${esc(t('ex_title'))}</h1>${sections.join('')}</body></html>`;
  const { uri } = await Print.printToFileAsync({ html });
  await Sharing.shareAsync(uri, { mimeType: 'application/pdf', UTI: 'com.adobe.pdf', dialogTitle: t('ex_title') });
}

async function downloadPage(token: string, scanId: number, page: number): Promise<{ file: File; bytes: Uint8Array }> {
  if (DEMO) {
    // DEMO: the photo is already on the phone
    const bytes = await new File(api.pageUrl(scanId, page)).bytes(); // DEMO
    return { file: await writeFile(`sheet-${scanId}-page-${page}.jpg`, bytes), bytes }; // DEMO
  } // DEMO
  const res = await expoFetch(api.pageUrl(scanId, page), { headers: { Authorization: 'Bearer ' + token } });
  if (!res.ok) throw new Error('download_failed');
  const bytes = new Uint8Array(await res.arrayBuffer());
  const file = await writeFile(`sheet-${scanId}-page-${page}.jpg`, bytes);
  return { file, bytes };
}

function toBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)));
  }
  return btoa(binary);
}

// Saves every page of the sheet to the phone's photos. Returns false if access was refused.
export async function savePages(token: string, scan: Scan): Promise<boolean> {
  const perm = await MediaLibrary.requestPermissionsAsync(true);
  if (!perm.granted) return false;
  for (let p = 1; p <= scan.page_count; p++) {
    const { file } = await downloadPage(token, scan.id, p);
    await MediaLibrary.saveToLibraryAsync(file.uri);
  }
  return true;
}

// Shares the sheet: one page as a photo, several pages together as one PDF.
export async function sharePages(token: string, scan: Scan): Promise<void> {
  if (scan.page_count <= 1) {
    const { file } = await downloadPage(token, scan.id, 1);
    await Sharing.shareAsync(file.uri, { mimeType: 'image/jpeg', UTI: 'public.jpeg' });
    return;
  }
  const imgs: string[] = [];
  for (let p = 1; p <= scan.page_count; p++) {
    const { bytes } = await downloadPage(token, scan.id, p);
    imgs.push(`<img src="data:image/jpeg;base64,${toBase64(bytes)}">`);
  }
  const html = `<!doctype html><html><head><meta charset="utf-8"><style>
    body{margin:0} img{width:100%;display:block;page-break-after:always}
  </style></head><body>${imgs.join('')}</body></html>`;
  const { uri } = await Print.printToFileAsync({ html });
  await Sharing.shareAsync(uri, { mimeType: 'application/pdf', UTI: 'com.adobe.pdf' });
}
