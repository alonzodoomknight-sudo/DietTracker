// Dates, numbers and units in the user's language.
import { lang } from './i18n';
import { metric } from './metrics';

const MONTHS = {
  en: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  el: ['Ιαν', 'Φεβ', 'Μαρ', 'Απρ', 'Μαΐ', 'Ιουν', 'Ιουλ', 'Αυγ', 'Σεπ', 'Οκτ', 'Νοε', 'Δεκ'],
};
const MONTHS_LONG = {
  en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
  // Greek: "16 Νοεμβρίου" (with a day) and "Νοέμβριος 2026" (month alone)
  el: ['Ιανουαρίου', 'Φεβρουαρίου', 'Μαρτίου', 'Απριλίου', 'Μαΐου', 'Ιουνίου', 'Ιουλίου', 'Αυγούστου', 'Σεπτεμβρίου', 'Οκτωβρίου', 'Νοεμβρίου', 'Δεκεμβρίου'],
};
const MONTHS_ALONE_EL = ['Ιανουάριος', 'Φεβρουάριος', 'Μάρτιος', 'Απρίλιος', 'Μάιος', 'Ιούνιος', 'Ιούλιος', 'Αύγουστος', 'Σεπτέμβριος', 'Οκτώβριος', 'Νοέμβριος', 'Δεκέμβριος'];
const DAYS = {
  en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  el: ['Κυρ', 'Δευ', 'Τρί', 'Τετ', 'Πέμ', 'Παρ', 'Σάβ'],
};
const DAYS_LONG = {
  en: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
  el: ['Κυριακή', 'Δευτέρα', 'Τρίτη', 'Τετάρτη', 'Πέμπτη', 'Παρασκευή', 'Σάββατο'],
};

const pad = (n: number) => (n < 10 ? '0' + n : String(n));

// "2026-10-19 09:30" (server format, local time) -> Date
export function parseLocal(s: string | null | undefined): Date | null {
  if (!s) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/.exec(s);
  if (!m) return null;
  return new Date(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] : 0, m[5] ? +m[5] : 0);
}

export function toLocal(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function toDateOnly(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// "Mon 19 Oct 2026"
export function fmtDate(d: Date): string {
  const l = lang();
  return `${DAYS[l][d.getDay()]} ${d.getDate()} ${MONTHS[l][d.getMonth()]} ${d.getFullYear()}`;
}

// "19 Oct"
export function fmtDayMonth(d: Date): string {
  return `${d.getDate()} ${MONTHS[lang()][d.getMonth()]}`;
}

// "3 Mar 1992"
export function fmtDayMonthYear(d: Date): string {
  return `${d.getDate()} ${MONTHS[lang()][d.getMonth()]} ${d.getFullYear()}`;
}

// "Mon 16 Nov"
export function fmtWeekday(d: Date): string {
  const l = lang();
  return `${DAYS[l][d.getDay()]} ${d.getDate()} ${MONTHS[l][d.getMonth()]}`;
}

// "Monday, 16 November 2026"
export function fmtLong(d: Date): string {
  const l = lang();
  return `${DAYS_LONG[l][d.getDay()]}, ${d.getDate()} ${MONTHS_LONG[l][d.getMonth()]} ${d.getFullYear()}`;
}

// "Sunday 15 Nov"
export function fmtWeekdayLong(d: Date): string {
  const l = lang();
  return `${DAYS_LONG[l][d.getDay()]} ${d.getDate()} ${MONTHS[l][d.getMonth()]}`;
}

// "June 2026"
export function fmtMonthYear(d: Date): string {
  const name = lang() === 'el' ? MONTHS_ALONE_EL[d.getMonth()] : MONTHS_LONG.en[d.getMonth()];
  return `${name} ${d.getFullYear()}`;
}

export function fmtMonthShort(d: Date): string {
  return MONTHS[lang()][d.getMonth()];
}

// "9:30"
export function fmtTime(d: Date): string {
  return `${d.getHours()}:${pad(d.getMinutes())}`;
}

export function fmtNum(v: number, decimals = 1): string {
  const s = v.toFixed(decimals);
  return lang() === 'el' ? s.replace('.', ',') : s;
}

// Accepts "78.4" and "78,4".
export function parseNum(s: string): number | null {
  const clean = s.trim().replace(',', '.');
  if (clean === '') return null;
  if (!/^-?\d+(\.\d+)?$/.test(clean)) return NaN;
  return parseFloat(clean);
}

export type Units = { weight: 'kg' | 'lb'; length: 'cm' | 'in' };

// Converts a stored value (kg, cm) to the units the user picked.
export function convert(unit: string, value: number, units: Units): { value: number; unit: string } {
  if (unit === 'kg' && units.weight === 'lb') return { value: value * 2.20462, unit: 'lb' };
  if (unit === 'cm' && units.length === 'in') return { value: value / 2.54, unit: 'in' };
  return { value, unit };
}

// "78.4 kg" for a metric, in the user's units.
export function fmtMetric(key: string, value: number, units: Units, withUnit = true): string {
  const m = metric(key);
  const c = convert(m.unit, value, units);
  const text = fmtNum(c.value, m.decimals);
  return withUnit && c.unit ? `${text} ${c.unit}` : text;
}

// "↓ 1.7 kg"
export function fmtDelta(key: string, delta: number, units: Units): string {
  const m = metric(key);
  const c = convert(m.unit, Math.abs(delta), units);
  const arrow = delta < 0 ? '↓' : delta > 0 ? '↑' : '→';
  const unit = c.unit === '%' ? ' %' : c.unit ? ' ' + c.unit : '';
  return `${arrow} ${fmtNum(c.value, m.decimals)}${unit}`;
}

export function addDays(d: Date, days: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + days);
  return x;
}

export function ageFrom(birth: Date): number {
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const m = now.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age--;
  return age;
}

// Meal plan days: 0 = Monday … 6 = Sunday. "Δευ" / "Δευτέρα"
export function planDayName(i: number, long = false): string {
  const l = lang();
  return (long ? DAYS_LONG : DAYS)[l][(i + 1) % 7];
}

// "12,00 €" in Greek, "€12.00" in English
export function fmtMoney(cents: number, currency: string): string {
  const sym: Record<string, string> = { EUR: '€', USD: '$', GBP: '£' };
  const s = sym[currency?.toUpperCase()] ?? currency?.toUpperCase() ?? '';
  const n = (cents / 100).toFixed(2);
  return lang() === 'el' ? `${n.replace('.', ',')} ${s}` : `${s}${n}`;
}
