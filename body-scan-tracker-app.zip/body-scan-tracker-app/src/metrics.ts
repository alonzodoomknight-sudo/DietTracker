// Every number the app knows. Keys are shared with the website and the database.
// min/max: values outside this are almost surely misread, so they get highlighted.

export type Group = 'main' | 'fat' | 'water' | 'makeup' | 'goal' | 'other' | 'segments' | 'balance';

export type Metric = {
  key: string;
  group: Group;
  unit: string;
  decimals: number;
  min: number;
  max: number;
};

const list: Metric[] = [];
const add = (group: Group, key: string, unit: string, decimals: number, min: number, max: number) =>
  list.push({ key, group, unit, decimals, min, max });

// Main
add('main', 'weight', 'kg', 1, 20, 300);
add('main', 'smm', 'kg', 1, 5, 80);
add('main', 'fat_mass', 'kg', 1, 1, 200);
add('main', 'pbf', '%', 1, 2, 75);
// Fat and belly
add('fat', 'bmi', '', 1, 10, 80);
add('fat', 'vfa', 'cm²', 1, 10, 400);
add('fat', 'vfl', '', 0, 1, 60);
add('fat', 'whr', '', 2, 0.5, 1.5);
add('fat', 'obesity_degree', '%', 0, 50, 300);
add('fat', 'score', '/100', 0, 30, 100);
// Body water
add('water', 'tbw', 'L', 1, 10, 90);
add('water', 'icw', 'L', 1, 5, 60);
add('water', 'ecw', 'L', 1, 4, 40);
add('water', 'ecw_ratio', '', 3, 0.3, 0.45);
add('water', 'tbw_ffm', '%', 1, 60, 80);
add('water', 'tbw_pct', '%', 1, 30, 75);
// Body makeup
add('makeup', 'protein', 'kg', 1, 2, 30);
add('makeup', 'minerals', 'kg', 2, 1, 10);
add('makeup', 'bmc', 'kg', 2, 0.5, 8);
add('makeup', 'ffm', 'kg', 1, 15, 150);
add('makeup', 'slm', 'kg', 1, 15, 140);
add('makeup', 'bcm', 'kg', 1, 10, 80);
add('makeup', 'muscle_mass', 'kg', 1, 15, 120);
// Goal from the sheet
add('goal', 'target_weight', 'kg', 1, 30, 200);
add('goal', 'weight_control', 'kg', 1, -100, 100);
add('goal', 'fat_control', 'kg', 1, -100, 100);
add('goal', 'muscle_control', 'kg', 1, -50, 50);
// Other
add('other', 'bmr', 'kcal', 0, 700, 4000);
add('other', 'waist', 'cm', 1, 40, 200);
add('other', 'arm', 'cm', 1, 15, 60);
add('other', 'amc', 'cm', 1, 15, 50);
add('other', 'ffmi', 'kg/m²', 1, 10, 35);
add('other', 'fmi', 'kg/m²', 1, 1, 30);
add('other', 'phase_angle', '°', 1, 2, 15);
add('other', 'metabolic_age', '', 0, 10, 100);
add('other', 'smi', 'kg/m²', 1, 3, 20);
// Arms, legs and trunk
export const PARTS = ['ra', 'la', 'tr', 'rl', 'll'] as const;
export type Part = (typeof PARTS)[number];
for (const p of PARTS) {
  const big = p === 'tr';
  const leg = p === 'rl' || p === 'll';
  add('segments', 'lean_' + p, 'kg', 2, big ? 8 : leg ? 3 : 0.5, big ? 50 : leg ? 25 : 10);
}
for (const p of PARTS) {
  add('segments', 'fat_' + p, 'kg', 1, 0.1, p === 'tr' ? 60 : 25);
}
for (const p of PARTS) {
  add('segments', 'ecw_' + p, '', 3, 0.3, 0.45);
}
// Body balance: 0 balanced, 1 slightly unbalanced, 2 very unbalanced
add('balance', 'balance', '', 0, 0, 2);

const byKey: Record<string, Metric> = {};
for (const m of list) byKey[m.key] = m;

export const METRICS = list;
export const GROUPS: Group[] = ['main', 'fat', 'water', 'makeup', 'goal', 'other'];

export function metric(key: string): Metric {
  return byKey[key] ?? { key, group: 'other', unit: '', decimals: 1, min: -1e9, max: 1e9 };
}

export function isKnown(key: string): boolean {
  return key in byKey;
}

export function plausible(key: string, v: number): boolean {
  const m = metric(key);
  return v >= m.min && v <= m.max;
}
