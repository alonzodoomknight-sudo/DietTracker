// Pieces shared by the meal plan, meals, water and appointment screens.
import React from 'react';
import { Pressable, Text, View, ViewStyle } from 'react-native';
import { C } from './theme';
import { DARK_RIM, Grad, GRADS, RIM, SHADOW, WELL } from './ui';
import { Key, t } from './i18n';
import { PlanItem } from './api';
import { fmtNum, toDateOnly } from './format';

export const MEAL_NAMES: Key[] = ['meal_0', 'meal_1', 'meal_2', 'meal_3', 'meal_4'];
export const mealName = (i: number) => t(MEAL_NAMES[i] ?? 'meal_0');

export const todayStr = () => toDateOnly(new Date());

// "Greek yogurt 2% · 200 g · 146 kcal"
export function itemText(i: PlanItem): string {
  const parts = [i.text];
  if (typeof i.grams === 'number' && !new RegExp('\\b' + i.grams + '\\s*(g|gr|γρ)', 'i').test(i.text)) parts.push(`${fmtNum(i.grams, 0)} g`);
  if (typeof i.kcal === 'number') parts.push(`${i.kcal} kcal`);
  return parts.join(' · ');
}

export function ProgressBar({ value, max, color = C.accent }: { value: number; max: number; color?: string }) {
  const pct = max > 0 ? Math.max(0, Math.min(1, value / max)) : 0;
  return (
    <View
      accessibilityRole="progressbar"
      accessibilityValue={{ min: 0, max: 100, now: Math.round(pct * 100) }}
      style={[{ height: 14, borderRadius: 7, overflow: 'hidden' }, WELL]}
    >
      <View style={{ width: `${pct * 100}%`, height: '100%', borderRadius: 7, backgroundColor: color }}>
        <Grad colors={[['#FFFFFF', 0.35], ['#FFFFFF', 0]]} radius={7} />
      </View>
    </View>
  );
}

export function Items({ items, faint }: { items: PlanItem[]; faint?: boolean }) {
  return (
    <View style={{ gap: 4 }}>
      {items.map((it, i) => (
        <View key={i} style={{ flexDirection: 'row', gap: 8 }}>
          <Text style={{ color: C.accent, fontSize: 15 }}>•</Text>
          <Text style={{ flex: 1, fontSize: 15, lineHeight: 21, color: faint ? C.muted : C.body }}>{itemText(it)}</Text>
        </View>
      ))}
    </View>
  );
}

export function NoteBox({ text }: { text: string }) {
  if (!text?.trim()) return null;
  return (
    <View style={{ borderRadius: 16, padding: 12, paddingHorizontal: 14, gap: 2, boxShadow: '0 4px 10px rgba(27,45,70,0.06)', borderBottomWidth: 3, borderBottomColor: 'rgba(0,0,0,0.05)' } as ViewStyle}>
      <Grad colors={['#FFF8E6', '#FCEBC0']} dir="diag" radius={16} />
      <Text style={{ fontSize: 12, fontWeight: '800', color: C.warnInk, textTransform: 'uppercase', letterSpacing: 1.5 }}>{t('pl_notes')}</Text>
      <Text style={{ fontSize: 14, lineHeight: 20, color: C.warnInk }}>{text}</Text>
    </View>
  );
}

// Chips in a row that wrap (days, times, meals).
export function Chip({ label, on, onPress, sub }: { label: string; on: boolean; onPress: () => void; sub?: string }) {
  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ checked: on }}
      onPress={onPress}
      style={[{ minHeight: 46, minWidth: 58, paddingHorizontal: 14, borderRadius: 14, alignItems: 'center', justifyContent: 'center', boxShadow: on ? SHADOW.teal : SHADOW.soft } as ViewStyle, on ? DARK_RIM : RIM]}
    >
      <Grad colors={on ? GRADS.primary : GRADS.secondary} radius={14} />
      <Text style={{ fontSize: 15, fontWeight: '800', color: on ? '#FFFFFF' : C.ink }}>{label}</Text>
      {!!sub && <Text style={{ fontSize: 11, fontWeight: '600', color: on ? '#E3F1EC' : C.muted }}>{sub}</Text>}
    </Pressable>
  );
}
