// Date and time pickers that work the same way on Android and iPhone.
import React, { useState } from 'react';
import { Modal, Platform, Pressable, Text, View, ViewStyle } from 'react-native';
import DateTimePicker, { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { C } from './theme';
import { Grad, GRADS, Icon, RIM, SHADOW } from './ui';
import { lang, t } from './i18n';

type Mode = 'date' | 'time';

export function usePicker() {
  const [ios, setIos] = useState<{ mode: Mode; value: Date; onPick: (d: Date) => void } | null>(null);
  const [temp, setTemp] = useState<Date>(new Date());
  const insets = useSafeAreaInsets();

  const open = (mode: Mode, value: Date, onPick: (d: Date) => void, max?: Date) => {
    if (Platform.OS === 'android') {
      DateTimePickerAndroid.open({
        value,
        mode,
        is24Hour: true,
        maximumDate: max,
        onChange: (event, date) => {
          if (event.type === 'set' && date) onPick(date);
        },
      });
    } else {
      setTemp(value);
      setIos({ mode, value, onPick });
    }
  };

  const element =
    Platform.OS === 'ios' && ios ? (
      <Modal visible transparent animationType="slide" onRequestClose={() => setIos(null)}>
        <Pressable accessibilityLabel={t('cancel')} onPress={() => setIos(null)} style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.35)' }} />
        <View style={{ backgroundColor: C.card, borderTopLeftRadius: 22, borderTopRightRadius: 22, paddingBottom: insets.bottom + 8 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'flex-end', padding: 8 }}>
            <Pressable
              accessibilityRole="button"
              onPress={() => {
                ios.onPick(temp);
                setIos(null);
              }}
              style={{ minHeight: 44, paddingHorizontal: 16, justifyContent: 'center' }}
            >
              <Text style={{ fontSize: 16, fontWeight: '700', color: C.accent }}>{t('done')}</Text>
            </Pressable>
          </View>
          <DateTimePicker
            value={temp}
            mode={ios.mode}
            display="spinner"
            locale={lang() === 'el' ? 'el-GR' : 'en-GB'}
            onChange={(_e, d) => d && setTemp(d)}
          />
        </View>
      </Modal>
    ) : null;

  return { open, element };
}

// A tappable box showing a date or a time.
export function PickerBox({ text, onPress, icon = 'calendar', label }: { text: string; onPress: () => void; icon?: 'calendar' | 'bell'; label: string }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${label}, ${text}`}
      onPress={onPress}
      style={[{ flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 52, borderRadius: 16, paddingHorizontal: 14, boxShadow: SHADOW.soft } as ViewStyle, RIM]}
    >
      <Grad colors={GRADS.secondary} radius={16} />
      <Icon name={icon} size={20} color={C.accent} />
      <Text style={{ flex: 1, fontSize: 16, color: C.ink }}>{text}</Text>
      <Icon name="chevron" size={18} color={C.faint} />
    </Pressable>
  );
}
