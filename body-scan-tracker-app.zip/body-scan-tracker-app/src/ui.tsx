// Shared building blocks for every screen.
import React, { ReactNode, createContext, useContext, useId, useState } from 'react';
import {
  ActivityIndicator,
  KeyboardTypeOptions,
  Modal,
  Pressable,
  ScrollView,
  StyleProp,
  StyleSheet,
  Text,
  TextInput,
  TextStyle,
  View,
  ViewStyle,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Defs, LinearGradient, Path, Rect, Stop } from 'react-native-svg';
import { StatusBar } from 'expo-status-bar';
import { router } from 'expo-router';
import { C } from './theme';
import { t } from './i18n';
import { useStore } from './store';

// ---------- Icons (simple line drawings) ----------

const PATHS: Record<string, string[]> = {
  back: ['M15 18l-6-6 6-6'],
  chevron: ['M9 6l6 6-6 6'],
  close: ['M6 6l12 12', 'M18 6L6 18'],
  plus: ['M12 5v14', 'M5 12h14'],
  check: ['M5 12l5 5 9-10'],
  settings: [
    'M12 15a3 3 0 100-6 3 3 0 000 6z',
    'M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z',
  ],
  camera: ['M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z', 'M12 17a4 4 0 100-8 4 4 0 000 8z'],
  upload: ['M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4', 'M17 8l-5-5-5 5', 'M12 3v12'],
  file: ['M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z', 'M14 2v6h6'],
  sheet: ['M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z', 'M14 2v6h6', 'M8 13h8', 'M8 17h5'],
  bell: ['M6 16V11a6 6 0 0112 0v5l2 2H4z', 'M10 20a2 2 0 004 0'],
  share: ['M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8', 'M16 6l-4-4-4 4', 'M12 2v13'],
  download: ['M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4', 'M7 10l5 5 5-5', 'M12 15V3'],
  trash: ['M3 6h18', 'M8 6V4h8v2', 'M19 6l-1 14H6L5 6'],
  alert: ['M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z', 'M12 9v4', 'M12 17h.01'],
  chart: ['M3 3v18h18', 'M7 15l4-4 3 3 5-6'],
  list: ['M8 6h13', 'M8 12h13', 'M8 18h13', 'M3 6h.01', 'M3 12h.01', 'M3 18h.01'],
  calendar: ['M5 5h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2z', 'M3 10h18', 'M8 3v4', 'M16 3v4'],
  user: ['M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2', 'M12 11a4 4 0 100-8 4 4 0 000 8z'],
  sun: ['M12 17a5 5 0 100-10 5 5 0 000 10z', 'M12 1v2', 'M12 21v2', 'M4.22 4.22l1.42 1.42', 'M18.36 18.36l1.42 1.42', 'M1 12h2', 'M21 12h2', 'M4.22 19.78l1.42-1.42', 'M18.36 5.64l1.42-1.42'],
  plate: ['M3 2v7a2 2 0 002 2h4a2 2 0 002-2V2', 'M7 2v20', 'M21 15V2a5 5 0 00-5 5v6a2 2 0 002 2h3', 'M21 15v7'],
  message: ['M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z'],
  drop: ['M12 2.69l5.66 5.66a8 8 0 11-11.31 0z'],
  target: ['M12 22a10 10 0 100-20 10 10 0 000 20z', 'M12 18a6 6 0 100-12 6 6 0 000 12z', 'M12 14a2 2 0 100-4 2 2 0 000 4z'],
  video: ['M23 7l-7 5 7 5V7z', 'M3 5h11a2 2 0 012 2v10a2 2 0 01-2 2H3a2 2 0 01-2-2V7a2 2 0 012-2z'],
  clock: ['M12 22a10 10 0 100-20 10 10 0 000 20z', 'M12 6v6l4 2'],
  cart: ['M9 22a1 1 0 100-2 1 1 0 000 2z', 'M20 22a1 1 0 100-2 1 1 0 000 2z', 'M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6'],
  image: ['M5 3h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2z', 'M8.5 10a1.5 1.5 0 100-3 1.5 1.5 0 000 3z', 'M21 15l-5-5L5 21'],
  edit: ['M12 20h9', 'M16.5 3.5a2.12 2.12 0 013 3L7 19l-4 1 1-4z'],
  send: ['M22 2L11 13', 'M22 2l-7 20-4-9-9-4z'],
  minus: ['M5 12h14'],
  scan: ['M3 7V5a2 2 0 012-2h2', 'M17 3h2a2 2 0 012 2v2', 'M21 17v2a2 2 0 01-2 2h-2', 'M7 21H5a2 2 0 01-2-2v-2', 'M7 12h10'],
  card: ['M3 5h18a2 2 0 012 2v10a2 2 0 01-2 2H3a2 2 0 01-2-2V7a2 2 0 012-2z', 'M1 10h22'],
};

export type IconName = keyof typeof PATHS;

export function Icon({ name, size = 24, color = C.ink, width = 2 }: { name: IconName; size?: number; color?: string; width?: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      {PATHS[name].map((d, i) => (
        <Path key={i} d={d} fill="none" stroke={color} strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" />
      ))}
    </Svg>
  );
}

// ---------- Cushion look (raised gradients, soft shadows, pressed-in wells) ----------

type Stop0 = string | [string, number]; // colour, or [colour, opacity]
const DIRS = { down: [0, 0, 0, 1], diag: [0.3, 0, 0.7, 1], corner: [0, 0, 1, 1], right: [0, 0, 1, 0] } as const;

// A gradient that fills its parent (put it first inside the view).
export function Grad({ colors, dir = 'down', radius = 0 }: { colors: Stop0[]; dir?: keyof typeof DIRS; radius?: number }) {
  const id = 'g' + useId().replace(/[^a-zA-Z0-9]/g, '');
  const [x1, y1, x2, y2] = DIRS[dir];
  // Measured in pixels: a "100%" size would leave out the parent's padding (the gradient stopped short on tablets).
  const [size, setSize] = useState<{ w: number; h: number } | null>(null);
  const mid = colors[Math.floor(colors.length / 2)];
  return (
    <View
      pointerEvents="none"
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
      onLayout={(e) => {
        const { width, height } = e.nativeEvent.layout;
        if (!size || Math.abs(size.w - width) > 0.5 || Math.abs(size.h - height) > 0.5) setSize({ w: width, h: height });
      }}
      style={[StyleSheet.absoluteFill, { borderRadius: radius, backgroundColor: !size && typeof mid === 'string' ? mid : 'transparent' }]}
    >
      {!!size && size.w > 0 && size.h > 0 && (
        <Svg width={size.w} height={size.h}>
          <Defs>
            <LinearGradient id={id} x1={x1} y1={y1} x2={x2} y2={y2}>
              {colors.map((c, i) => (
                <Stop
                  key={i}
                  offset={colors.length === 1 ? 0 : i / (colors.length - 1)}
                  stopColor={Array.isArray(c) ? c[0] : c}
                  stopOpacity={Array.isArray(c) ? c[1] : 1}
                />
              ))}
            </LinearGradient>
          </Defs>
          <Rect x={0} y={0} width={size.w} height={size.h} rx={radius} ry={radius} fill={`url(#${id})`} />
        </Svg>
      )}
    </View>
  );
}

export const SHADOW = {
  card: '0 10px 22px rgba(27,45,70,0.10), 0 2px 4px rgba(27,45,70,0.06)',
  soft: '0 5px 12px rgba(27,45,70,0.12)',
  small: '0 3px 8px rgba(27,45,70,0.12)',
  teal: '0 6px 14px rgba(14,107,92,0.35)',
  blue: '0 6px 14px rgba(46,127,209,0.35)',
  dark: '0 6px 14px rgba(0,0,0,0.35)',
  well: 'inset 0 2px 5px rgba(27,45,70,0.16)',
  banner: '0 6px 16px rgba(7,63,54,0.35)',
};

export const GRADS: Record<string, Stop0[]> = {
  card: ['#FFFFFF', '#F6F8FA', C.cardEnd],
  primary: ['#1B8C78', C.accent, C.accentDark],
  secondary: ['#FFFFFF', '#EEF2F5'],
  danger: ['#FFFFFF', '#F6EEEE'],
  light: [['#FFFFFF', 0.22], ['#FFFFFF', 0.08]],
  water: ['#4A97E3', '#2E7FD1', '#1F64AE'],
  banner: [C.bannerA, C.bannerB, C.bannerC],
  sheet: ['#F6F8FA', C.bg],
  nav: ['#FFFFFF', '#F3F6F8'],
};

// The raised edge: white rim with a darker lip at the bottom.
export const RIM: ViewStyle = { borderWidth: 1, borderColor: 'rgba(255,255,255,0.9)', borderBottomWidth: 3, borderBottomColor: 'rgba(27,45,70,0.08)' };
export const DARK_RIM: ViewStyle = { borderBottomWidth: 3, borderBottomColor: 'rgba(0,0,0,0.18)' };
// Pressed-in wells (inputs, tracks).
export const WELL: ViewStyle = { backgroundColor: C.pressed, boxShadow: SHADOW.well } as ViewStyle;

// Round coloured icon bubble.
const BUBBLES: Record<string, [string, string, string]> = {
  teal: ['#E6F4F0', '#CBE8DF', C.accent],
  blue: ['#EAF3FD', '#CFE2F8', '#2E7FD1'],
  navy: ['#EAF0FD', '#D3DEF8', '#1D45A8'],
  orange: ['#FDF0E8', '#F8DCCB', '#B4541A'],
  purple: ['#EEEAFB', '#DCD3F6', '#5B3FB8'],
  solid: ['#1B8C78', '#0A5246', '#FFFFFF'],
};
export type BubbleTone = 'teal' | 'blue' | 'navy' | 'orange' | 'purple' | 'solid';
export function Bubble({ icon, tone = 'teal', size = 40, radius, iconSize, width }: { icon: IconName; tone?: BubbleTone; size?: number; radius?: number; iconSize?: number; width?: number }) {
  const [a, b, fg] = BUBBLES[tone];
  const r = radius ?? size / 2;
  return (
    <View style={{ width: size, height: size, borderRadius: r, alignItems: 'center', justifyContent: 'center', boxShadow: tone === 'solid' ? SHADOW.teal : SHADOW.small, borderBottomWidth: 2, borderBottomColor: 'rgba(0,0,0,0.08)' } as ViewStyle}>
      <Grad colors={[a, b]} dir="diag" radius={r} />
      <Icon name={icon} color={fg} size={iconSize ?? Math.round(size / 2)} width={width} />
    </View>
  );
}

// True inside the green banner, so text and buttons there turn light.
const OnDark = createContext(false);

export function Banner({ children, inset = true }: { children: ReactNode; inset?: boolean }) {
  const insets = useSafeAreaInsets();
  return (
    <View style={{ paddingTop: inset ? insets.top : 0, paddingBottom: 8, borderBottomWidth: 2, borderBottomColor: C.gold, boxShadow: SHADOW.banner, zIndex: 1 } as ViewStyle}>
      <Grad colors={GRADS.banner} dir="corner" />
      <StatusBar style="light" />
      <OnDark.Provider value={true}>{children}</OnDark.Provider>
    </View>
  );
}

// ---------- Layout ----------

export function Screen({
  children,
  scroll = true,
  footer,
  bg = C.bg,
  header,
  bottom,
}: {
  children: ReactNode;
  scroll?: boolean;
  footer?: ReactNode;
  bg?: string;
  header?: ReactNode;
  bottom?: ReactNode; // shown as is below the content (the bottom bar)
}) {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: bg }} edges={header ? ['left', 'right'] : ['top', 'left', 'right']}>
      {header ? <Banner>{header}</Banner> : <StatusBar style="dark" />}
      {scroll ? (
        <ScrollView contentContainerStyle={{ padding: 20, paddingTop: header ? 18 : 8, paddingBottom: 32, gap: 14 }} keyboardShouldPersistTaps="handled">
          {children}
        </ScrollView>
      ) : (
        <View style={{ flex: 1 }}>{children}</View>
      )}
      {bottom ?? (footer ? <Footer>{footer}</Footer> : <BottomSpace />)}
    </SafeAreaView>
  );
}

function BottomSpace() {
  const insets = useSafeAreaInsets();
  return <View style={{ height: insets.bottom }} />;
}

export function Footer({ children, bg = C.bg }: { children: ReactNode; bg?: string }) {
  const insets = useSafeAreaInsets();
  return <View style={{ paddingHorizontal: 20, paddingTop: 10, paddingBottom: Math.max(insets.bottom, 14), backgroundColor: bg, gap: 10 }}>{children}</View>;
}

export function Header({ title, sub, back = true, right, onBack }: { title?: string; sub?: string; back?: boolean; right?: ReactNode; onBack?: () => void }) {
  const dark = useContext(OnDark);
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingLeft: back ? 12 : 20, paddingRight: 12, paddingTop: 8, paddingBottom: 6, minHeight: 56 }}>
      {back && (
        <RoundButton
          icon="back"
          label={t('back')}
          dark={dark}
          onPress={onBack ?? (() => (router.canGoBack() ? router.back() : router.replace('/home')))}
        />
      )}
      <View style={{ flex: 1 }}>
        {!!title && (
          <Text accessibilityRole="header" style={{ fontSize: 20, fontWeight: '800', color: dark ? '#FFFFFF' : C.ink }} numberOfLines={2}>
            {title}
          </Text>
        )}
        {!!sub && <Text style={{ fontSize: 13, fontWeight: dark ? '600' : '400', color: dark ? C.goldText : C.muted }}>{sub}</Text>}
      </View>
      {right}
    </View>
  );
}

// Back button for pages with their own header. Goes back; when there is no page to go back to it opens `to`.
// Without `to` (first page, Home) it only shows when there is a page to go back to.
export function BackButton({ to, onPress }: { to?: string; onPress?: () => void }) {
  const dark = useContext(OnDark);
  if (!onPress && !to && !router.canGoBack()) return null;
  return <RoundButton icon="back" label={t('back')} dark={dark} onPress={onPress ?? (() => (router.canGoBack() ? router.back() : router.replace(to as any)))} />;
}

// Raised round icon button (light on the green banner, white elsewhere).
function RoundButton({ icon, label, onPress, dark, color }: { icon: IconName; label: string; onPress: () => void; dark: boolean; color?: string }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => [
        { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', boxShadow: dark ? SHADOW.dark : SHADOW.soft, opacity: pressed ? 0.85 : 1 } as ViewStyle,
        dark ? { borderWidth: 1, borderColor: 'rgba(255,255,255,0.22)', ...DARK_RIM } : RIM,
      ]}
    >
      <Grad colors={dark ? GRADS.light : GRADS.secondary} radius={22} />
      <Icon name={icon} color={color ?? (dark ? '#FFFFFF' : C.ink)} size={22} />
    </Pressable>
  );
}

export function IconButton({ icon, label, onPress, color }: { icon: IconName; label: string; onPress: () => void; color?: string }) {
  const dark = useContext(OnDark);
  if (dark) return <View style={{ marginLeft: 8 }}><RoundButton icon={icon} label={label} onPress={onPress} dark color={color} /></View>;
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
      <Icon name={icon} color={color ?? C.ink} />
    </Pressable>
  );
}

// ---------- Text ----------

export function H1({ children, style }: { children: ReactNode; style?: StyleProp<TextStyle> }) {
  const dark = useContext(OnDark);
  return <Text accessibilityRole="header" style={[{ fontSize: 26, fontWeight: '800', color: dark ? '#FFFFFF' : C.ink, lineHeight: 32 }, style]}>{children}</Text>;
}

export function Label({ children, style }: { children: ReactNode; style?: StyleProp<TextStyle> }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 4 }}>
      <Text style={[{ fontSize: 13, fontWeight: '700', color: C.label, textTransform: 'uppercase', letterSpacing: 2 }, style]}>{children}</Text>
      <View style={{ flex: 1, height: 1 }}>
        <Grad colors={['#CDD5DF', ['#CDD5DF', 0]]} dir="right" />
      </View>
    </View>
  );
}

export function Body({ children, style }: { children: ReactNode; style?: StyleProp<TextStyle> }) {
  return <Text style={[{ fontSize: 15, lineHeight: 22, color: C.body }, style]}>{children}</Text>;
}

export function Muted({ children, style }: { children: ReactNode; style?: StyleProp<TextStyle> }) {
  const dark = useContext(OnDark);
  return <Text style={[{ fontSize: 13, lineHeight: 19, color: dark ? C.goldText : C.muted, fontWeight: dark ? '600' : '400' }, style]}>{children}</Text>;
}

// ---------- Controls ----------

type ButtonKind = 'primary' | 'secondary' | 'danger' | 'light';

export function Button({
  title,
  onPress,
  kind = 'primary',
  disabled,
  loading,
  icon,
  style,
}: {
  title: string;
  onPress: () => void;
  kind?: ButtonKind;
  disabled?: boolean;
  loading?: boolean;
  icon?: IconName;
  style?: StyleProp<ViewStyle>;
}) {
  const fg = kind === 'primary' || kind === 'light' ? '#FFFFFF' : kind === 'danger' ? C.danger : kind === 'secondary' ? C.accent : C.ink;
  const rim = kind === 'primary' ? DARK_RIM : kind === 'light' ? { borderWidth: 1, borderColor: 'rgba(255,255,255,0.22)', ...DARK_RIM } : RIM;
  const shadow = kind === 'primary' ? SHADOW.teal : kind === 'light' ? SHADOW.dark : SHADOW.soft;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: !!disabled || !!loading, busy: !!loading }}
      disabled={disabled || loading}
      onPress={onPress}
      style={({ pressed }) => [
        { minHeight: 52, borderRadius: 16, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8, paddingHorizontal: 16, boxShadow: disabled ? undefined : shadow, opacity: disabled ? 0.5 : pressed ? 0.85 : 1 } as ViewStyle,
        rim,
        style,
      ]}
    >
      <Grad colors={GRADS[kind]} radius={16} />
      {loading ? <ActivityIndicator color={fg} /> : icon ? <Icon name={icon} color={fg} size={20} /> : null}
      <Text style={{ color: fg, fontSize: 16, fontWeight: '700' }}>{title}</Text>
    </Pressable>
  );
}

export function Card({ children, style }: { children: ReactNode; style?: StyleProp<ViewStyle> }) {
  return (
    <View style={[{ borderRadius: 22, padding: 16, boxShadow: SHADOW.card } as ViewStyle, RIM, style]}>
      <Grad colors={GRADS.card} dir="diag" radius={21} />
      {children}
    </View>
  );
}

export function Tag({ text, bg = C.accentSoft, color = C.accentDark }: { text: string; bg?: string; color?: string }) {
  return (
    <View style={{ borderRadius: 10, paddingHorizontal: 10, paddingVertical: 4, alignSelf: 'flex-start', boxShadow: '0 2px 5px rgba(27,45,70,0.10)', borderBottomWidth: 2, borderBottomColor: 'rgba(27,45,70,0.07)' } as ViewStyle}>
      <Grad colors={['#FFFFFF', bg]} radius={10} />
      <Text style={{ fontSize: 12, fontWeight: '800', color }}>{text}</Text>
    </View>
  );
}

export function Row({ label, value, onPress, last, right }: { label: string; value?: string; onPress?: () => void; last?: boolean; right?: ReactNode }) {
  const content = (
    <View style={{ minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: last ? 0 : 1, borderBottomColor: C.soft }}>
      <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: C.ink }}>{label}</Text>
      {!!value && <Text style={{ fontSize: 15, color: C.muted, flexShrink: 1, textAlign: 'right' }}>{value}</Text>}
      {right}
      {onPress && <Icon name="chevron" size={18} color={C.faint} />}
    </View>
  );
  if (!onPress) return content;
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={value ? `${label}, ${value}` : label} onPress={onPress}>
      {content}
    </Pressable>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  label,
}: {
  options: { value: T; label: string }[];
  value: T | null;
  onChange: (v: T) => void;
  label?: string;
}) {
  return (
    <View accessibilityRole="radiogroup" accessibilityLabel={label} style={[{ flexDirection: 'row', borderRadius: 16, padding: 4, gap: 4 }, WELL]}>
      {options.map((o) => {
        const on = o.value === value;
        return (
          <Pressable
            key={o.value}
            accessibilityRole="radio"
            accessibilityState={{ checked: on }}
            onPress={() => onChange(o.value)}
            style={[{ flex: 1, minHeight: 42, borderRadius: 12, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 }, on ? ({ boxShadow: SHADOW.teal, ...DARK_RIM } as ViewStyle) : null]}
          >
            {on && <Grad colors={GRADS.primary} radius={12} />}
            <Text style={{ fontSize: 14, fontWeight: on ? '800' : '600', color: on ? '#FFFFFF' : C.muted }} numberOfLines={1}>
              {o.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function Field({
  label,
  value,
  onChangeText,
  unit,
  keyboardType = 'decimal-pad',
  warn,
  note,
  placeholder,
  autoCapitalize = 'none',
  maxLength,
}: {
  label: string;
  value: string;
  onChangeText: (s: string) => void;
  unit?: string;
  keyboardType?: KeyboardTypeOptions;
  warn?: string;
  note?: string;
  placeholder?: string;
  autoCapitalize?: 'none' | 'characters' | 'words' | 'sentences';
  maxLength?: number;
}) {
  return (
    <View style={{ gap: 4 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Text style={{ flex: 1, fontSize: 14, fontWeight: '600', color: C.ink }}>{label}</Text>
        {!!note && <Text style={{ fontSize: 12, color: C.muted }}>{note}</Text>}
        {!!warn && <Tag text={warn} bg={C.warnBg} color={C.warnInk} />}
      </View>
      <View
        style={[
          {
            flexDirection: 'row',
            alignItems: 'center',
            height: 50,
            borderRadius: 14,
            paddingHorizontal: 14,
          },
          warn ? ({ borderWidth: 2, borderColor: C.warnLine, backgroundColor: C.warnBg, boxShadow: 'inset 0 2px 5px rgba(150,110,0,0.18)' } as ViewStyle) : WELL,
        ]}
      >
        <TextInput
          accessibilityLabel={label}
          value={value}
          onChangeText={onChangeText}
          keyboardType={keyboardType}
          placeholder={placeholder}
          placeholderTextColor={C.faint}
          autoCapitalize={autoCapitalize}
          autoCorrect={false}
          maxLength={maxLength}
          style={{ flex: 1, fontSize: 16, color: C.ink, paddingVertical: 0 }}
        />
        {!!unit && <Text style={{ fontSize: 14, color: C.muted, marginLeft: 6 }}>{unit}</Text>}
      </View>
    </View>
  );
}

export function Notice({ title, body, tone = 'warn' }: { title: string; body?: string; tone?: 'warn' | 'info' | 'error' }) {
  const bg: [string, string] = tone === 'warn' ? ['#FFF8E6', '#FCEBC0'] : tone === 'error' ? ['#FFF1EF', '#F9D6D1'] : ['#F0F8F5', '#D5ECE4'];
  const fg = tone === 'warn' ? C.warnInk : tone === 'error' ? C.danger : C.accentDark;
  return (
    <View
      accessibilityRole={tone === 'error' ? 'alert' : undefined}
      style={{ borderRadius: 18, padding: 14, paddingHorizontal: 16, flexDirection: 'row', gap: 12, boxShadow: '0 6px 14px rgba(27,45,70,0.08)', borderBottomWidth: 3, borderBottomColor: 'rgba(0,0,0,0.05)' } as ViewStyle}
    >
      <Grad colors={bg} dir="diag" radius={18} />
      <Icon name="alert" size={20} color={fg} />
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={{ fontSize: 15, fontWeight: '700', color: fg }}>{title}</Text>
        {!!body && <Text style={{ fontSize: 14, lineHeight: 20, color: fg }}>{body}</Text>}
      </View>
    </View>
  );
}

export function ChoiceModal<T extends string>({
  visible,
  title,
  options,
  value,
  onPick,
  onClose,
}: {
  visible: boolean;
  title: string;
  options: { value: T; label: string; sub?: string }[];
  value?: T | null;
  onPick: (v: T) => void;
  onClose: () => void;
}) {
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable accessibilityLabel={t('cancel')} onPress={onClose} style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.35)' }} />
      <View style={{ backgroundColor: C.bg, borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingTop: 12, paddingBottom: insets.bottom + 12, maxHeight: '80%', boxShadow: '0 -10px 30px rgba(0,0,0,0.25)' } as ViewStyle}>
        <SheetTop />
        <Text accessibilityRole="header" style={{ fontSize: 18, fontWeight: '800', color: C.ink, paddingHorizontal: 20, marginBottom: 6 }}>
          {title}
        </Text>
        <ScrollView>
          {options.map((o) => {
            const on = o.value === value;
            return (
              <Pressable
                key={o.value}
                accessibilityRole="radio"
                accessibilityState={{ checked: on }}
                onPress={() => {
                  onPick(o.value);
                  onClose();
                }}
                style={{ minHeight: 56, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: 1, borderBottomColor: C.soft }}
              >
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 16, fontWeight: on ? '700' : '500', color: on ? C.accent : C.ink }}>{o.label}</Text>
                  {!!o.sub && <Text style={{ fontSize: 13, color: C.muted }}>{o.sub}</Text>}
                </View>
                {on && <Icon name="check" color={C.accent} size={20} />}
              </Pressable>
            );
          })}
        </ScrollView>
      </View>
    </Modal>
  );
}

// Top of a bottom sheet: soft gradient and a grab handle.
function SheetTop() {
  return (
    <>
      <Grad colors={GRADS.sheet} radius={28} />
      <View style={{ alignSelf: 'center', width: 44, height: 5, borderRadius: 3, backgroundColor: '#C8D1DB', marginBottom: 10 }} />
    </>
  );
}

// Raised round button in the middle of the bottom bar.
function CenterButton({ icon, label, a11y, onPress }: { icon: IconName; label: string; a11y: string; onPress: () => void }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', gap: 4, marginTop: -26 }}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={a11y}
        onPress={onPress}
        style={({ pressed }) =>
          ({
            width: 66,
            height: 66,
            borderRadius: 33,
            borderWidth: 4,
            borderColor: '#FFFFFF',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 0 6px rgba(14,107,92,0.14), 0 10px 20px rgba(14,107,92,0.45)',
            opacity: pressed ? 0.85 : 1,
          }) as ViewStyle
        }
      >
        <Grad colors={['#2BA58E', C.accent, '#084A3F']} dir="corner" radius={29} />
        <Icon name={icon} color="#FFFFFF" size={28} width={2.6} />
      </Pressable>
      <Text style={{ fontSize: 12, fontWeight: '700', color: C.accent }} numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
}

const NAV_BAR: ViewStyle = { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, boxShadow: '0 -6px 16px rgba(27,45,70,0.10)' } as ViewStyle;

export type NavTab = 'progress' | 'sheets' | 'today' | 'plan' | 'chat';

export function BottomNav({ active }: { active: NavTab }) {
  const full = useStore((s) => s.me?.dietitian?.status === 'accepted' || !!s.sync.plan);
  if (full) return <FullNav active={active} />;
  return <ScanNav active={active === 'sheets' ? 'sheets' : 'progress'} />;
}

// Today | Plan | + | Progress | Chat
function FullNav({ active }: { active: NavTab }) {
  const insets = useSafeAreaInsets();
  const unread = useStore((s) => s.sync.unread);
  const booking = useStore((s) => !!s.sync.booking);
  const [menu, setMenu] = useState(false);
  const tab = (key: NavTab, label: string, icon: IconName, to: '/today' | '/plan' | '/home' | '/chat', badge = 0) => {
    const on = active === key || (key === 'progress' && active === 'sheets');
    return (
      <Pressable
        accessibilityRole="tab"
        accessibilityState={{ selected: on }}
        accessibilityLabel={badge ? `${label}, ${badge}` : label}
        onPress={() => !(active === key) && router.replace(to)}
        style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, minHeight: 60 }}
      >
        {on && <View style={{ position: 'absolute', top: 0, left: '18%', right: '18%', height: 3, borderBottomLeftRadius: 3, borderBottomRightRadius: 3, backgroundColor: C.accent }} />}
        <View>
          <Icon name={icon} color={on ? C.accent : C.navIdle} size={23} />
          {badge > 0 && (
            <View style={{ position: 'absolute', top: -5, right: -11, minWidth: 18, height: 18, borderRadius: 9, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4, boxShadow: '0 2px 5px rgba(180,35,24,0.4)' } as ViewStyle}>
              <Grad colors={['#E0453A', C.danger]} radius={9} />
              <Text style={{ color: '#FFFFFF', fontSize: 11, fontWeight: '800' }}>{badge > 99 ? '99+' : badge}</Text>
            </View>
          )}
        </View>
        <Text style={{ fontSize: 12, fontWeight: on ? '800' : '600', color: on ? C.accent : C.navIdle }} numberOfLines={1}>
          {label}
        </Text>
      </Pressable>
    );
  };
  const go = (to: string) => {
    setMenu(false);
    router.push(to as any);
  };
  const item = (icon: IconName, tone: BubbleTone, label: string, to: string) => (
    <Pressable
      key={to}
      accessibilityRole="button"
      onPress={() => go(to)}
      style={({ pressed }) => [{ minHeight: 64, paddingHorizontal: 14, borderRadius: 22, flexDirection: 'row', alignItems: 'center', gap: 14, boxShadow: SHADOW.card, opacity: pressed ? 0.85 : 1 } as ViewStyle, RIM]}
    >
      <Grad colors={GRADS.card} dir="diag" radius={21} />
      <Bubble icon={icon} tone={tone} />
      <Text style={{ flex: 1, fontSize: 16, fontWeight: '700', color: C.ink }}>{label}</Text>
      <Icon name="chevron" size={18} color={C.faint} />
    </Pressable>
  );
  return (
    <View accessibilityRole="tablist" style={[NAV_BAR, { paddingBottom: Math.max(insets.bottom, 6) }]}>
      <Grad colors={GRADS.nav} />
      {tab('today', t('nav_today'), 'sun', '/today')}
      {tab('plan', t('nav_plan'), 'plate', '/plan')}
      <CenterButton icon="plus" label={t('nav_add')} a11y={t('nav_add')} onPress={() => setMenu(true)} />
      {tab('progress', t('progress'), 'chart', '/home')}
      {tab('chat', t('nav_chat'), 'message', '/chat', unread)}
      <Modal visible={menu} transparent animationType="slide" onRequestClose={() => setMenu(false)}>
        <Pressable accessibilityLabel={t('cancel')} onPress={() => setMenu(false)} style={{ flex: 1, backgroundColor: 'rgba(10,20,30,0.45)' }} />
        <View style={{ backgroundColor: C.bg, borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingTop: 12, paddingHorizontal: 16, paddingBottom: insets.bottom + 16, gap: 12, boxShadow: '0 -10px 30px rgba(0,0,0,0.25)' } as ViewStyle}>
          <SheetTop />
          <Text accessibilityRole="header" style={{ fontSize: 20, fontWeight: '800', color: C.ink, paddingHorizontal: 4 }}>
            {t('nav_add')}
          </Text>
          {item('camera', 'teal', t('scan_a_sheet'), '/scan/start')}
          {item('clock', 'navy', t('ap_title'), '/appointments')}
          {item('plate', 'orange', t('lm_title'), '/log-meal')}
          {item('drop', 'blue', t('wa_title'), '/water')}
          {item('calendar', 'navy', booking ? t('bk_title') : t('ad_title'), booking ? '/book' : '/add-dates')}
          {item('image', 'purple', t('ps_title'), '/plan-snap')}
        </View>
      </Modal>
    </View>
  );
}

// Progress | camera | Sheets (only scans, no dietitian and no meal plan)
function ScanNav({ active }: { active: 'progress' | 'sheets' }) {
  const insets = useSafeAreaInsets();
  const tab = (key: 'progress' | 'sheets', label: string, icon: IconName, to: '/home' | '/sheets') => {
    const on = active === key;
    return (
      <Pressable
        accessibilityRole="tab"
        accessibilityState={{ selected: on }}
        onPress={() => !on && router.replace(to)}
        style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, minHeight: 60 }}
      >
        {on && <View style={{ position: 'absolute', top: 0, left: '18%', right: '18%', height: 3, borderBottomLeftRadius: 3, borderBottomRightRadius: 3, backgroundColor: C.accent }} />}
        <Icon name={icon} color={on ? C.accent : C.navIdle} size={23} />
        <Text style={{ fontSize: 12, fontWeight: on ? '800' : '600', color: on ? C.accent : C.navIdle }}>{label}</Text>
      </Pressable>
    );
  };
  return (
    <View accessibilityRole="tablist" style={[NAV_BAR, { paddingBottom: Math.max(insets.bottom, 6) }]}>
      <Grad colors={GRADS.nav} />
      {tab('progress', t('progress'), 'chart', '/home')}
      <CenterButton icon="camera" label={t('scan_a_sheet')} a11y={t('scan_a_sheet')} onPress={() => router.push('/scan/start')} />
      {tab('sheets', t('sheets'), 'list', '/sheets')}
    </View>
  );
}

export function Loading() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg }}>
      <ActivityIndicator color={C.accent} size="large" />
    </View>
  );
}
