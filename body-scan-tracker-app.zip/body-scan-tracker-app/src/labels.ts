// Names and values of the numbers, in the user's language and units.
import { t, tk } from './i18n';
import { Units, fmtMetric, fmtNum } from './format';
import { metric } from './metrics';

const SEG = /^(lean|fat|ecw)_(ra|la|tr|rl|ll)$/;

export function metricLabel(key: string): string {
  const seg = SEG.exec(key);
  if (seg) {
    const kind = seg[1] === 'lean' ? t('c_lean') : seg[1] === 'fat' ? t('c_fat') : t('c_ecw');
    return `${tk('part_' + seg[2])} · ${kind}`;
  }
  return tk('mt_' + key);
}

export function valueText(key: string, v: number, units: Units, withUnit = true): string {
  if (key === 'balance') return tk('bal_' + Math.round(v));
  return fmtMetric(key, v, units, withUnit);
}

export function rangeText(key: string, lo: number | null | undefined, hi: number | null | undefined): string {
  if (lo === null || lo === undefined || hi === null || hi === undefined) return '';
  const d = metric(key).decimals;
  return `${fmtNum(lo, d)}–${fmtNum(hi, d)}`;
}

export function rangeTag(v: number, lo: number | null | undefined, hi: number | null | undefined): 'high' | 'low' | null {
  if (hi !== null && hi !== undefined && v > hi) return 'high';
  if (lo !== null && lo !== undefined && v < lo) return 'low';
  return null;
}
