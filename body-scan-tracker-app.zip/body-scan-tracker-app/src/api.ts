// Talks to the PHP website (the same server the dietitian uses).
// The address comes from EXPO_PUBLIC_API_BASE_URL at build time (GitHub variable API_BASE_URL).

import { DEMO, demoCall, demoPageUrl } from './demo'; // DEMO

export const BASE_URL = (process.env.EXPO_PUBLIC_API_BASE_URL ?? '').trim().replace(/\/+$/, '');

export type Val = { v: number; lo?: number | null; hi?: number | null; p?: number | null };

export type Scan = {
  id: number;
  machine: string;
  scanned_at: string; // "2026-10-19 09:30", local time on the sheet
  page_count: number;
  values: Record<string, Val>;
};

export type Me = {
  name: string | null;
  height_cm: number | null;
  birth_date: string | null;
  age: number | null;
  sex: 'male' | 'female' | null;
  dietitian: { name: string; status: 'pending' | 'accepted' } | null;
};

export type ScanInput = { machine: string; scanned_at: string; values: Record<string, Val> };

export class ApiError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string) {
    super(code);
    this.status = status;
    this.code = code;
  }
}

async function call<T>(method: string, path: string, token: string | null, body?: object | FormData): Promise<T> {
  if (DEMO) return demoCall(method, path, body); // DEMO
  if (!BASE_URL) throw new ApiError(0, 'no_server');
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  let payload: any;
  if (body instanceof FormData) {
    payload = body;
  } else if (body) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }
  let res: Response;
  try {
    res = await fetch(BASE_URL + '/api' + path, { method, headers, body: payload });
  } catch {
    throw new ApiError(0, 'network');
  }
  const text = await res.text();
  let data: any = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }
  if (!res.ok) throw new ApiError(res.status, data?.error ?? 'http_' + res.status);
  return data as T;
}

export const api = {
  register: () => call<{ token: string }>('POST', '/register', null),
  me: (token: string) => call<Me>('GET', '/me', token),
  updateMe: (token: string, data: Partial<Omit<Me, 'dietitian'>>) => call<Me>('PUT', '/me', token, data),
  deleteMe: (token: string) => call<{ deleted: boolean }>('DELETE', '/me', token),
  scans: (token: string) => call<{ scans: Scan[] }>('GET', '/scans', token),

  createScan: (token: string, data: ScanInput, pageUris: string[]) => {
    const form = new FormData();
    form.append('data', JSON.stringify(data));
    pageUris.forEach((uri, i) => {
      form.append('pages[]', { uri, name: `page-${i + 1}.jpg`, type: 'image/jpeg' } as any);
    });
    return call<Scan>('POST', '/scans', token, form);
  },
  updateScan: (token: string, id: number, data: ScanInput) => call<Scan>('PUT', `/scans/${id}`, token, data),
  deleteScan: (token: string, id: number) => call<{ deleted: boolean }>('DELETE', `/scans/${id}`, token),

  // Sends a PDF and gets each page back as a JPEG (base64).
  pdfPages: (token: string, uri: string, name: string) => {
    const form = new FormData();
    form.append('pdf', { uri, name: name || 'sheet.pdf', type: 'application/pdf' } as any);
    return call<{ pages: string[] }>('POST', '/pdf-pages', token, form);
  },

  connect: (token: string, code: string, name: string) => call<Me>('POST', '/connect', token, { code, name }),
  disconnect: (token: string) => call<Me>('DELETE', '/connect', token),

  pageUrl: (scanId: number, page: number) => (DEMO ? demoPageUrl(scanId, page) : `${BASE_URL}/api/scans/${scanId}/pages/${page}`), // DEMO: "DEMO ? demoPageUrl(scanId, page) :"
};

export function errorKey(e: unknown): 'err_network' | 'err_no_server' | 'err_generic' | 'err_demo' /* DEMO */ {
  if (e instanceof ApiError) {
    if (e.code === 'demo') return 'err_demo'; // DEMO
    if (e.code === 'network') return 'err_network';
    if (e.code === 'no_server') return 'err_no_server';
  }
  return 'err_generic';
}

// ---------- Version 3: meal plans, meals, water, goals, chat, appointments ----------

export type PlanItem = { text: string; grams?: number | null; kcal?: number | null; food_id?: number | null };
export type PlanMeal = { items: PlanItem[]; note: string };
export type Plan = {
  id: number;
  name: string | null;
  start_date: string;
  end_date: string | null;
  note: string | null;
  times: string[];
  days: { meals: PlanMeal[] }[];
  source: 'dietitian' | 'paper';
  dietitian: string | null;
  updated_at: string;
};
export type MealLog = { id: number; date: string; meal: number; items: PlanItem[]; kcal: number | null; photo: boolean; from_plan: boolean };
export type Goal = { id: number; title: string; metric: string | null; start: number | null; target: number | null; current: number | null; due: string | null; done: boolean; updated_at: string };
export type Appointment = {
  id: number;
  title: string | null;
  kind: 'appointment' | 'remeasure' | 'other';
  video: boolean;
  starts_at: string;
  minutes: number;
  status: 'pending' | 'confirmed' | 'cancelled' | 'unpaid';
  created_by: 'client' | 'dietitian';
  price_cents: number;
  paid: boolean;
  call_started: boolean;
  with_dietitian: boolean;
};
export type Service = { id: number; el: string; en: string; minutes: number; price_cents: number; video: boolean; kind: string };
export type Booking = { dietitian: string; currency: string; pay_in_app: boolean; services: Service[] };
export type Sync = {
  me: Me;
  plan: Plan | null;
  logs: MealLog[];
  water: Record<string, number>;
  goals: Goal[];
  appointments: Appointment[];
  unread: number;
  booking: Booking | null;
  pay_url?: string | null;
};
export type Food = { id: number; el: string; en: string; kcal: number; piece: number | null };
export type Message = { id: number; mine: boolean; body: string; at: string };
export type OcrBox = { text: string; left: number; top: number; right: number; bottom: number };

export const api3 = {
  sync: (token: string) => call<Sync>('GET', '/sync', token),
  foods: (token: string) => call<{ foods: Food[] }>('GET', '/foods', token),
  ocr: (token: string, uri: string) => {
    const form = new FormData();
    form.append('image', { uri, name: 'page.jpg', type: 'image/jpeg' } as any);
    return call<{ lines: OcrBox[] }>('POST', '/ocr', token, form);
  },
  addLog: (token: string, data: { date: string; meal: number; items: PlanItem[]; kcal: number | null; from_plan: boolean }, photoUri?: string | null) => {
    const form = new FormData();
    form.append('data', JSON.stringify(data));
    if (photoUri) form.append('photo', { uri: photoUri, name: 'meal.jpg', type: 'image/jpeg' } as any);
    return call<Sync>('POST', '/logs', token, form);
  },
  deleteLog: (token: string, id: number) => call<{ deleted: boolean }>('DELETE', `/logs/${id}`, token),
  setWater: (token: string, date: string, ml: number) => call<{ date: string; ml: number }>('PUT', '/water', token, { date, ml }),
  messages: (token: string, after: number) => call<{ messages: Message[] }>('GET', `/messages?after=${after}`, token),
  send: (token: string, body: string, after: number) => call<{ messages: Message[] }>('POST', `/messages?after=${after}`, token, { body }),
  slots: (token: string, serviceId: number) => call<{ days: { date: string; times: string[] }[] }>('GET', `/slots?service_id=${serviceId}`, token),
  book: (token: string, serviceId: number, startsAt: string, lang: string) => call<Sync>('POST', `/appointments?lang=${lang}`, token, { service_id: serviceId, starts_at: startsAt }),
  apptAction: (token: string, id: number, action: 'confirm' | 'cancel') => call<Sync>('POST', `/appointments/${id}/${action}`, token),
  pay: (token: string, id: number) => call<{ url?: string; paid?: boolean }>('POST', `/appointments/${id}/pay`, token),
  callUrl: (token: string, id: number, lang: string) => call<{ url: string }>('POST', `/appointments/${id}/call?lang=${lang}`, token),
  ownDates: (token: string, items: { title: string; kind: string; starts_at: string }[]) => call<Sync>('POST', '/appointments/own', token, { items }),
  device: (token: string, data: { token: string; platform: string; lang: string }) => call<{ ok: boolean }>('POST', '/device', token, data),
  paperPlan: (token: string, days: { meals: PlanMeal[] }[], times: string[], name: string) => call<Sync>('POST', '/plan/paper', token, { days, times, name }),
};
