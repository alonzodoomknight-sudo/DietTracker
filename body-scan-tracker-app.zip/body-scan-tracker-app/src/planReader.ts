// Reads a printed weekly meal plan (days down the side, the 5 meals across the top),
// like the plans Greek dietitians hand out. No AI: the day and meal titles are found by name,
// then every line of text is put in the cell (day, meal) it sits in.
import { OcrLine, normalize } from './reader';

export type PlanItem = { text: string; grams?: number | null; kcal?: number | null; food_id?: number | null };
export type PlanMeal = { items: PlanItem[]; note: string };
export type PlanDay = { meals: PlanMeal[] };

export const MEAL_COUNT = 5;

const MEAL_NAMES = [
  ['Πρωινό', 'BREAKFAST'],
  ['Δεκατιανό', 'ELEVENSES', 'MID-MORNING', 'MORNING SNACK'],
  ['Μεσημεριανό', 'LUNCH'],
  ['Απογευματινό', 'AFTERNOON', 'AFTERNOON SNACK', 'AFTERNOON MEAL'],
  ['Βραδινό', 'DINNER'],
].map((names) => names.map(normalize));

const DAY_NAMES = [
  ['Δευτέρα', 'MONDAY'],
  ['Τρίτη', 'TUESDAY'],
  ['Τετάρτη', 'WEDNESDAY'],
  ['Πέμπτη', 'THURSDAY'],
  ['Παρασκευή', 'FRIDAY'],
  ['Σάββατο', 'SATURDAY'],
  ['Κυριακή', 'SUNDAY'],
].map((names) => names.map(normalize));

const NOTE = new RegExp('^(' + ['Σημειώσεις', 'Σημείωση', 'Notes', 'Note'].map(normalize).join('|') + ')\\s*:?\\s*');

const clean = (s: string) => s.replace(/[^A-Z0-9Α-Ω-]+/g, ' ').trim();
const isName = (line: OcrLine, list: string[][]) => {
  const n = clean(line.norm);
  return list.findIndex((names) => names.some((x) => n === x || (n.startsWith(x) && n.length <= x.length + 3)));
};

export function emptyDays(): PlanDay[] {
  return Array.from({ length: 7 }, () => ({ meals: Array.from({ length: MEAL_COUNT }, () => ({ items: [], note: '' })) }));
}

// Returns the 7 days × 5 meals, or null if this doesn't look like a meal plan.
export function parsePlan(lines: OcrLine[]): PlanDay[] | null {
  const days = emptyDays();
  let fractions: number[] | null = null; // column borders as a share of the content width
  let found = 0;
  const pages = Array.from(new Set(lines.map((l) => l.page))).sort((a, b) => a - b);

  for (const page of pages) {
    const pl = lines.filter((l) => l.page === page);
    const headers = pl.map((l) => ({ l, i: isName(l, MEAL_NAMES) })).filter((x) => x.i >= 0);
    const labels = pl.map((l) => ({ l, i: isName(l, DAY_NAMES) })).filter((x) => x.i >= 0);
    if (!labels.length) continue;
    const labelRight = Math.max(...labels.map((x) => x.l.right));
    const headerBottom = headers.length ? Math.max(...headers.map((x) => x.l.bottom)) : -Infinity;
    const content = pl.filter((l) => !headers.some((x) => x.l === l) && !labels.some((x) => x.l === l) && l.top > headerBottom && l.left > labelRight - 4);
    if (!content.length) continue;
    const spanL = Math.min(...content.map((l) => l.left));
    const spanR = Math.max(...content.map((l) => l.right));
    const span = Math.max(1, spanR - spanL);

    // Column borders: halfway between the meal titles (or the borders found on the first page).
    let borders: number[];
    if (headers.length >= 3) {
      const centers: number[] = [];
      for (let m = 0; m < MEAL_COUNT; m++) {
        const h = headers.find((x) => x.i === m);
        centers[m] = h ? (h.l.left + h.l.right) / 2 : NaN;
      }
      // fill a missing title by spacing evenly
      for (let m = 0; m < MEAL_COUNT; m++) {
        if (Number.isNaN(centers[m])) {
          const known = centers.map((c, i) => ({ c, i })).filter((x) => !Number.isNaN(x.c));
          const step = known.length > 1 ? (known[known.length - 1].c - known[0].c) / (known[known.length - 1].i - known[0].i) : span / MEAL_COUNT;
          centers[m] = known[0].c + (m - known[0].i) * step;
        }
      }
      borders = centers.slice(0, -1).map((c, i) => (c + centers[i + 1]) / 2);
      fractions = borders.map((b) => (b - spanL) / span);
    } else if (fractions) {
      borders = fractions.map((f) => spanL + f * span);
    } else {
      borders = [1, 2, 3, 4].map((k) => spanL + (span * k) / MEAL_COUNT);
    }

    // Row borders: halfway between the day names.
    const rows = labels.sort((a, b) => a.l.top - b.l.top);
    const centersY = rows.map((x) => (x.l.top + x.l.bottom) / 2);
    const rowOf = (y: number) => {
      let r = 0;
      for (let k = 1; k < rows.length; k++) if (y >= (centersY[k - 1] + centersY[k]) / 2) r = k;
      return rows[r].i;
    };
    const colOf = (x: number) => borders.filter((b) => x >= b).length;

    const cells: Record<string, OcrLine[]> = {};
    for (const l of content) {
      const key = `${rowOf((l.top + l.bottom) / 2)}:${colOf((l.left + l.right) / 2)}`;
      (cells[key] = cells[key] ?? []).push(l);
    }

    for (const [key, cellLines] of Object.entries(cells)) {
      const [d, m] = key.split(':').map(Number);
      const meal = days[d].meals[m];
      cellLines.sort((a, b) => a.top - b.top);
      let current: string[] | null = null;
      let inNote = false;
      let prev: OcrLine | null = null;
      const flush = () => {
        if (current && current.length) {
          const text = current.join(' ').replace(/\s+/g, ' ').trim();
          if (inNote) meal.note = meal.note ? `${meal.note} ${text}` : text;
          else if (text) meal.items.push({ text });
        }
        current = null;
      };
      for (const l of cellLines) {
        const h = Math.max(1, l.bottom - l.top);
        const noteStart = NOTE.exec(l.norm);
        const gap = prev ? l.top - prev.bottom : Infinity;
        const startsNew = !prev || gap > h * 0.45 || /^\d/.test(l.text.trim()) || !!noteStart;
        if (startsNew) {
          flush();
          inNote = !!noteStart;
          // keep the original letters, only drop the "Notes:" title
          const raw = l.text.trim();
          const text = !noteStart ? raw : /^[^:]{0,16}:/.test(raw) ? raw.replace(/^[^:]*:\s*/, '') : raw.replace(/^\S+\s*/, '');
          current = [text];
        } else {
          current = current ?? [];
          current.push(l.text.trim());
        }
        prev = l;
      }
      flush();
      found++;
    }
  }
  return found >= 3 ? days : null;
}
