// DEMO MODE: the app works with no website, filled with sample data, so it can be shown to a client.
// Every request the app would send to the website is answered here instead, from memory.
// The sample data comes back each time the app is opened again. All people and numbers are made up.
//
// To turn it off: set DEMO to false below (the app then talks to the website at API_BASE_URL).
// To remove it: delete this file and src/demoSheet.ts, then the lines marked "DEMO" in
// src/api.ts, src/files.ts, src/i18n.ts and app/meals.tsx.
import { File, Paths } from 'expo-file-system';
import { ApiError, Appointment, Food, Me, MealLog, Message, Plan, Scan, Service, Sync, Val } from './api';
import { lang } from './i18n';
import { addDays, toDateOnly, toLocal } from './format';
import { DEMO_SHEET_JPEG } from './demoSheet';

export const DEMO = true;

const DIETITIAN = 'Δέσποινα Ραφαηλίδου';

// ---------- Text in both languages ----------

type Txt = string | { en: string; el: string };
const T = (en: string, el: string) => ({ en, el });
const tx = (x: Txt) => (typeof x === 'string' ? x : x[lang()]);

type DItem = { text: Txt; grams: number | null; kcal: number | null; food_id?: number | null };
const it = (text: Txt, grams: number | null = null, kcal: number | null = null): DItem => ({ text, grams, kcal });

// ---------- Dates, always close to today ----------

const pad = (n: number) => String(n).padStart(2, '0');
const midnight = () => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
};
const dayStr = (n: number) => toDateOnly(addDays(midnight(), n));
const at = (n: number, time: string) => `${dayStr(n)} ${time}`;
// Days from today, moved off Sunday (the office is closed).
const workday = (n: number) => (addDays(midnight(), n).getDay() === 0 ? n + 1 : n);
const mondayThisWeek = () => {
  const d = midnight();
  return toDateOnly(addDays(d, -((d.getDay() + 6) % 7)));
};

// ---------- The sample sheet photo ----------

const sheetFile = new File(Paths.document, 'demo-sheet.jpg');
if (DEMO) {
  try {
    if (!sheetFile.exists) {
      sheetFile.create();
      sheetFile.write(DEMO_SHEET_JPEG, { encoding: 'base64' });
    }
  } catch {
    // no photo: the sheet screens show an empty box
  }
}

// ---------- Foods and the meal plan ----------

const F = {
  bread: T('Wholegrain bread', 'Ψωμί ολικής άλεσης'),
  feta: T('Feta cheese', 'Τυρί φέτα'),
  tomato: T('Tomato', 'Ντομάτα'),
  egg: T('Boiled eggs', 'Αυγά βραστά'),
  oj: T('Orange juice', 'Χυμός πορτοκάλι'),
  apple: T('Apple', 'Μήλο'),
  almonds: T('Almonds', 'Αμύγδαλα'),
  yogurt: T('Greek yogurt 2%', 'Γιαούρτι 2%'),
  honey: T('Honey', 'Μέλι'),
  chicken: T('Grilled chicken breast', 'Κοτόπουλο στήθος ψητό'),
  salad: T('Greek salad', 'Χωριάτικη σαλάτα'),
  oil: T('Olive oil', 'Ελαιόλαδο'),
  salmon: T('Baked salmon', 'Σολομός στον φούρνο'),
  veg: T('Boiled vegetables', 'Βραστά λαχανικά'),
  patties: T('Beef patties', 'Μπιφτέκια μοσχαρίσια'),
  rice: T('Brown rice', 'Καστανό ρύζι'),
  green: T('Green salad', 'Πράσινη σαλάτα'),
  chickpeas: T('Chickpea soup', 'Ρεβιθάδα'),
  gemista: T('Stuffed tomatoes and peppers', 'Γεμιστά'),
  roast: T('Roast chicken with potatoes', 'Κοτόπουλο με πατάτες φούρνου'),
  omelette: T('Omelette with 2 eggs', 'Ομελέτα με 2 αυγά'),
  lentils: T('Lentil soup', 'Φακές'),
  rusk: T('Rusk', 'Παξιμάδι'),
  tuna: T('Tuna salad', 'Τονοσαλάτα'),
  walnuts: T('Walnuts', 'Καρύδια'),
  fish: T('Grilled fish', 'Ψάρι ψητό'),
  greens: T('Boiled greens', 'Χόρτα βραστά'),
  toast: T('Cheese toast', 'Τοστ με τυρί'),
  cucumber: T('Cucumber', 'Αγγούρι'),
  banana: T('Banana', 'Μπανάνα'),
  coffee: T('Coffee with milk', 'Καφές με γάλα'),
  pasta: T('Pasta with tomato sauce', 'Μακαρόνια με σάλτσα ντομάτας'),
};

const FOODS: { el: string; en: string; kcal: number; piece: number | null }[] = [
  { en: 'Almonds', el: 'Αμύγδαλα', kcal: 579, piece: null },
  { en: 'Egg', el: 'Αυγό', kcal: 143, piece: 60 },
  { en: 'Cucumber', el: 'Αγγούρι', kcal: 15, piece: 200 },
  { en: 'Oats', el: 'Βρώμη', kcal: 389, piece: null },
  { en: 'Milk 1.5%', el: 'Γάλα 1,5%', kcal: 47, piece: null },
  { en: 'Greek yogurt 2%', el: 'Γιαούρτι 2%', kcal: 73, piece: 200 },
  { en: 'Olive oil', el: 'Ελαιόλαδο', kcal: 884, piece: null },
  { en: 'Coffee with milk', el: 'Καφές με γάλα', kcal: 22, piece: 200 },
  { en: 'Walnuts', el: 'Καρύδια', kcal: 654, piece: null },
  { en: 'Brown rice, cooked', el: 'Καστανό ρύζι, βρασμένο', kcal: 111, piece: null },
  { en: 'Beef mince', el: 'Κιμάς μοσχαρίσιος', kcal: 250, piece: null },
  { en: 'Chicken breast', el: 'Κοτόπουλο στήθος', kcal: 165, piece: null },
  { en: 'Pasta, cooked', el: 'Μακαρόνια, βρασμένα', kcal: 158, piece: null },
  { en: 'Honey', el: 'Μέλι', kcal: 304, piece: null },
  { en: 'Apple', el: 'Μήλο', kcal: 52, piece: 180 },
  { en: 'Banana', el: 'Μπανάνα', kcal: 89, piece: 120 },
  { en: 'Tomato', el: 'Ντομάτα', kcal: 18, piece: 120 },
  { en: 'Rusk', el: 'Παξιμάδι', kcal: 400, piece: 30 },
  { en: 'Potatoes', el: 'Πατάτες', kcal: 77, piece: 150 },
  { en: 'Orange', el: 'Πορτοκάλι', kcal: 47, piece: 150 },
  { en: 'Chickpeas, cooked', el: 'Ρεβίθια, βρασμένα', kcal: 164, piece: null },
  { en: 'Salmon', el: 'Σολομός', kcal: 208, piece: null },
  { en: 'Feta cheese', el: 'Τυρί φέτα', kcal: 264, piece: null },
  { en: 'Tuna in water', el: 'Τόνος σε νερό', kcal: 116, piece: null },
  { en: 'Lentils, cooked', el: 'Φακές, βρασμένες', kcal: 116, piece: null },
  { en: 'Wholegrain bread', el: 'Ψωμί ολικής άλεσης', kcal: 247, piece: 30 },
];

const BREAKFAST = [it(F.bread, 60, 148), it(F.feta, 30, 80), it(F.tomato, 100, 18)];
const BREAKFAST_WEEKEND = [it(F.egg, 100, 143), it(F.bread, 40, 99), it(F.oj, 200, 90)];
const SNACK_1 = [it(F.apple), it(F.almonds, 15, 87)];
const SNACK_2 = [it(F.yogurt, 200, 146), it(F.honey, 10, 30)];
const LUNCH = [
  [it(F.chicken, 150, 248), it(F.salad), it(F.oil, 10, 88)],
  [it(F.salmon, 150, 312), it(F.veg, 200, 70), it(F.oil, 10, 88)],
  [it(F.patties, 150, 285), it(F.rice, 150, 167), it(F.green)],
  [it(F.chickpeas, 300, 330), it(F.feta, 30, 80)],
  [it(F.chicken, 150, 248), it(F.salad), it(F.oil, 10, 88)],
  [it(F.gemista, 350, 320), it(F.feta, 30, 80)],
  [it(F.roast, 350, 450), it(F.salad)],
];
const DINNER = [
  [it(F.omelette, null, 180), it(F.bread, 30, 74)],
  [it(F.lentils, 300, 315), it(F.rusk)],
  [it(F.tuna, 200, 210)],
  [it(F.yogurt, 200, 146), it(F.walnuts, 15, 98)],
  [it(F.lentils, 300, 315), it(F.rusk)],
  [it(F.fish, 200, 220), it(F.greens, 200, 50), it(F.oil, 10, 88)],
  [it(F.toast, null, 260), it(F.cucumber)],
];
const NO_BREAD = T('No bread at lunch on training days.', 'Χωρίς ψωμί στο μεσημεριανό τις μέρες προπόνησης.');

type DMeal = { items: DItem[]; note: Txt };
type DPlan = Omit<Plan, 'name' | 'note' | 'days'> & { name: Txt | null; note: Txt | null; days: { meals: DMeal[] }[] };

function samplePlan(): DPlan {
  const days = Array.from({ length: 7 }, (_, d) => ({
    meals: [
      { items: d >= 5 ? BREAKFAST_WEEKEND : BREAKFAST, note: '' },
      { items: SNACK_1, note: '' },
      { items: LUNCH[d], note: d === 0 || d === 4 ? NO_BREAD : '' },
      { items: SNACK_2, note: '' },
      { items: DINNER[d], note: '' },
    ],
  }));
  return {
    id: 1,
    name: T('Autumn plan', 'Φθινοπωρινό πρόγραμμα'),
    start_date: mondayThisWeek(),
    end_date: null,
    note: T('Drink 2.5 L of water a day. Walk 30 minutes after dinner.', 'Πίνετε 2,5 λίτρα νερό την ημέρα. Περπάτημα 30 λεπτά μετά το βραδινό.'),
    times: ['08:00', '11:00', '14:00', '17:30', '20:30'],
    days,
    source: 'dietitian',
    dietitian: DIETITIAN,
    updated_at: at(-2, '18:20') + ':00',
  };
}

// ---------- Scans (6 months of a client losing fat) ----------

function sampleScans(): Scan[] {
  const when = [at(-165, '09:30'), at(-133, '09:45'), at(-102, '10:00'), at(-67, '18:40'), at(-39, '09:15'), at(-4, '09:30')];
  const weight = [84.2, 82.9, 81.6, 80.4, 79.5, 78.4];
  const fat = [25.6, 24.1, 22.8, 21.7, 21.1, 19.5];
  const pbf = [30.4, 29.1, 27.9, 27.0, 26.5, 24.9];
  const bmi = [26.6, 26.2, 25.8, 25.4, 25.1, 24.7];
  const tbw = [43.0, 43.1, 43.1, 43.0, 42.8, 43.4];
  const bmr = [1748, 1736, 1729, 1640, 1631, 1643];
  const vfl = [11, 11, 10, 10, 9, 9];
  const r = (v: number, lo?: number, hi?: number): Val => ({ v, lo: lo ?? null, hi: hi ?? null, p: 1 });
  return when.map((scanned_at, i) => {
    const values: Record<string, Val> = {
      weight: r(weight[i], i >= 3 ? 60.6 : undefined, i >= 3 ? 82.0 : undefined),
      fat_mass: r(fat[i], i >= 3 ? 8.6 : undefined, i >= 3 ? 17.1 : undefined),
      pbf: r(pbf[i], i >= 3 ? 10.0 : undefined, i >= 3 ? 20.0 : undefined),
      bmi: r(bmi[i], i >= 3 ? 18.5 : undefined, i >= 3 ? 25.0 : undefined),
      tbw: r(tbw[i], i >= 3 ? 41.3 : undefined, i >= 3 ? 50.5 : undefined),
      bmr: r(bmr[i]),
      vfl: r(vfl[i]),
    };
    if (i < 3) {
      // Tanita MC-780
      values.muscle_mass = r([55.4, 55.6, 55.6][i]);
      values.bmc = r(3.0);
      values.tbw_pct = r([51.1, 52.0, 52.8][i]);
      values.metabolic_age = r([44, 43, 42][i]);
    } else {
      // InBody 770
      const j = i - 3;
      values.smm = r([31.4, 31.5, 31.8][j], 30.6, 37.4);
      values.ffm = r([58.7, 58.4, 58.9][j], 55.7, 68.1);
      values.icw = r([26.6, 26.5, 26.9][j]);
      values.ecw = r([16.4, 16.3, 16.5][j]);
      values.ecw_ratio = r([0.382, 0.381, 0.381][j], 0.36, 0.39);
      values.protein = r([11.5, 11.5, 11.7][j], 11.0, 13.5);
      values.minerals = r([3.83, 3.82, 3.85][j], 3.82, 4.67);
      values.score = r([72, 74, 76][j]);
      values.whr = r([0.95, 0.94, 0.92][j]);
      values.vfa = r([98.5, 95.2, 89.7][j]);
      values.target_weight = r(74.1);
      values.weight_control = r([-6.3, -5.4, -4.3][j]);
      values.fat_control = r([-8.2, -7.6, -6.0][j]);
      values.muscle_control = r([1.9, 2.2, 1.7][j]);
      const lean = [3.15, 3.12, 25.3, 9.05, 9.01].map((x) => x + j * 0.03);
      const fatSeg = [1.3, 1.3, 11.6, 3.2, 3.2].map((x) => Math.round((x - j * 0.1) * 10) / 10);
      (['ra', 'la', 'tr', 'rl', 'll'] as const).forEach((p, k) => {
        values['lean_' + p] = r(Math.round(lean[k] * 100) / 100);
        values['fat_' + p] = r(fatSeg[k]);
        values['ecw_' + p] = r([0.379, 0.38, 0.381, 0.382, 0.382][k]);
      });
      values.balance = r(0);
    }
    return { id: i + 1, machine: i < 3 ? 'tanita_mc780' : 'inbody770', scanned_at, page_count: 1, values };
  });
}

// ---------- Everything else ----------

type DLog = Omit<MealLog, 'items' | 'photo'> & { items: DItem[]; photo: string | null };
type DGoal = { id: number; title: Txt; metric: string | null; start: number | null; target: number | null; due: string | null; done: boolean; updated_at: string };
type DAppt = Omit<Appointment, 'title'> & { title: Txt | null };
type DMsg = { id: number; mine: boolean; body: Txt; at: string; read: boolean };

const SERVICES: Service[] = [
  { id: 1, en: 'First visit', el: 'Πρώτη επίσκεψη', minutes: 60, price_cents: 4000, video: false, kind: 'appointment' },
  { id: 2, en: 'Follow-up', el: 'Επανέλεγχος', minutes: 30, price_cents: 2500, video: false, kind: 'appointment' },
  { id: 3, en: 'Video follow-up', el: 'Επανέλεγχος με βιντεοκλήση', minutes: 30, price_cents: 2000, video: true, kind: 'appointment' },
  { id: 4, en: 'Re-measure', el: 'Νέα μέτρηση', minutes: 15, price_cents: 1500, video: false, kind: 'remeasure' },
];

const svcTitle = (s: Service) => T(s.en, s.el);

function sampleAppts(): DAppt[] {
  const base = { minutes: 30, call_started: false, with_dietitian: true, video: false, paid: false };
  return [
    { ...base, id: 1, title: svcTitle(SERVICES[1]), kind: 'appointment', starts_at: at(-39, '09:00'), status: 'confirmed', created_by: 'client', price_cents: 2500, paid: true },
    { ...base, id: 2, title: svcTitle(SERVICES[3]), kind: 'remeasure', starts_at: at(-4, '09:30'), minutes: 15, status: 'confirmed', created_by: 'dietitian', price_cents: 1500, paid: true },
    { ...base, id: 3, title: svcTitle(SERVICES[1]), kind: 'appointment', starts_at: at(workday(3), '18:00'), status: 'pending', created_by: 'dietitian', price_cents: 2500 },
    { ...base, id: 4, title: svcTitle(SERVICES[2]), kind: 'appointment', video: true, starts_at: at(workday(10), '12:30'), status: 'confirmed', created_by: 'client', price_cents: 2000 },
    { ...base, id: 5, title: svcTitle(SERVICES[3]), kind: 'remeasure', starts_at: at(workday(26), '09:30'), minutes: 15, status: 'confirmed', created_by: 'dietitian', price_cents: 1500 },
  ];
}

function sampleMessages(): DMsg[] {
  const m = (id: number, mine: boolean, en: string, el: string, when: string, read = true): DMsg => ({ id, mine, body: T(en, el), at: when, read });
  return [
    m(1, false, 'Hi Nikos, your new results look great: 1.6 kg less fat in a month!', 'Γεια σου Νίκο, τα νέα σου αποτελέσματα είναι πολύ καλά: 1,6 κιλά λιγότερο λίπος σε έναν μήνα!', at(-4, '12:10')),
    m(2, true, 'Thank you! The plan is easy to follow.', 'Ευχαριστώ! Το πρόγραμμα βγαίνει εύκολα.', at(-4, '12:42')),
    m(3, true, 'Good morning! I had the yogurt with honey yesterday instead of the fruit.', 'Καλημέρα! Χθες έφαγα το γιαούρτι με μέλι αντί για το φρούτο.', at(-1, '09:10')),
    m(4, false, "That's fine, it's a good swap. Keep the honey to one teaspoon.", 'Δεν πειράζει, είναι καλή αλλαγή. Το μέλι μέχρι ένα κουταλάκι.', at(-1, '09:32')),
    m(5, false, 'Please confirm your next appointment in the app.', 'Επιβεβαίωσε το επόμενο ραντεβού σου στην εφαρμογή.', at(0, '08:05'), false),
  ];
}

function sampleLogs(plan: DPlan): DLog[] {
  const logs: DLog[] = [];
  let id = 1;
  const sum = (items: DItem[]) => items.reduce((n, i) => n + (i.kcal ?? 0), 0);
  for (let n = 10; n >= 1; n--) {
    const d = addDays(midnight(), -n);
    const meals = plan.days[(d.getDay() + 6) % 7].meals;
    for (let meal = 0; meal < 5; meal++) {
      if (meal === 3 && (n === 3 || n === 7)) continue;
      if (meal === 2 && n === 5) {
        logs.push({ id: id++, date: toDateOnly(d), meal, items: [it(F.pasta, 250, 390)], kcal: 390, photo: null, from_plan: false });
        continue;
      }
      logs.push({ id: id++, date: toDateOnly(d), meal, items: meals[meal].items, kcal: sum(meals[meal].items), photo: null, from_plan: true });
    }
  }
  const today = plan.days[(midnight().getDay() + 6) % 7].meals;
  logs.push({ id: id++, date: dayStr(0), meal: 0, items: today[0].items, kcal: sum(today[0].items), photo: null, from_plan: true });
  logs.push({ id: id++, date: dayStr(0), meal: 1, items: [it(F.banana, 120, 107), it(F.coffee, 200, 43)], kcal: 150, photo: null, from_plan: false });
  return logs;
}

function sampleWater(): Record<string, number> {
  const w: Record<string, number> = { [dayStr(0)]: 1250 };
  [2000, 2250, 1750, 2500, 2000, 1500, 2250, 2000, 1750, 2500].forEach((ml, i) => (w[dayStr(-(i + 1))] = ml));
  return w;
}

function sampleGoals(): DGoal[] {
  return [
    { id: 1, title: T('Lose 3 kg of fat', 'Να χάσω 3 κιλά λίπος'), metric: 'fat_mass', start: 21.7, target: 18.7, due: dayStr(48), done: false, updated_at: dayStr(-4) },
    { id: 2, title: T('Visceral fat level under 8', 'Σπλαχνικό λίπος κάτω από 8'), metric: 'vfl', start: 11, target: 8, due: dayStr(107), done: false, updated_at: dayStr(-4) },
    { id: 3, title: T('Walk 30 minutes, 5 days a week', 'Περπάτημα 30 λεπτά, 5 μέρες την εβδομάδα'), metric: null, start: null, target: null, due: null, done: true, updated_at: dayStr(-12) },
  ];
}

// ---------- The demo "server" ----------

type DState = {
  name: string | null; // null: the sample name in the app's language
  me: Omit<Me, 'name' | 'dietitian'>;
  dietitian: boolean;
  scans: Scan[];
  pages: Record<number, string[]>; // photos of sheets added during the demo
  plan: DPlan | null;
  logs: DLog[];
  water: Record<string, number>;
  goals: DGoal[];
  appts: DAppt[];
  msgs: DMsg[];
  nextId: number;
};

function sample(): DState {
  const plan = samplePlan();
  return {
    name: null,
    me: { height_cm: 178, birth_date: '1988-03-14', age: 38, sex: 'male' },
    dietitian: true,
    scans: sampleScans(),
    pages: {},
    plan,
    logs: sampleLogs(plan),
    water: sampleWater(),
    goals: sampleGoals(),
    appts: sampleAppts(),
    msgs: sampleMessages(),
    nextId: 1000,
  };
}

let db = sample();

const clone = <X>(x: X): X => JSON.parse(JSON.stringify(x));

function me(): Me {
  return {
    name: db.name ?? tx(T('Nikos Papadakis', 'Νίκος Παπαδάκης')),
    ...db.me,
    dietitian: db.dietitian ? { name: DIETITIAN, status: 'accepted' } : null,
  };
}

const item = (i: DItem) => ({ text: tx(i.text), grams: i.grams, kcal: i.kcal, food_id: i.food_id ?? null });

function sync(): Sync {
  const latest: Record<string, number> = {};
  [...db.scans].sort((a, b) => (a.scanned_at < b.scanned_at ? -1 : 1)).forEach((s) => Object.entries(s.values).forEach(([k, v]) => (latest[k] = v.v)));
  const from35 = dayStr(-35);
  const from90 = dayStr(-90);
  const p = db.plan;
  return clone({
    me: me(),
    plan: p && {
      ...p,
      name: p.name === null ? null : tx(p.name),
      note: p.note === null ? null : tx(p.note),
      days: p.days.map((d) => ({ meals: d.meals.map((m) => ({ items: m.items.map(item), note: tx(m.note) })) })),
    },
    logs: db.logs.filter((l) => l.date >= from35).map((l) => ({ ...l, items: l.items.map(item), photo: !!l.photo })),
    water: db.water,
    goals: [...db.goals]
      .sort((a, b) => Number(a.done) - Number(b.done) || (a.due ?? '9999').localeCompare(b.due ?? '9999') || a.id - b.id)
      .map((g) => ({ ...g, title: tx(g.title), current: g.metric && latest[g.metric] !== undefined ? latest[g.metric] : null })),
    appointments: db.appts
      .filter((a) => a.starts_at >= from90)
      .sort((a, b) => a.starts_at.localeCompare(b.starts_at))
      .map((a) => ({ ...a, title: a.title === null ? null : tx(a.title) })),
    unread: db.dietitian ? db.msgs.filter((m) => !m.mine && !m.read).length : 0,
    booking: db.dietitian ? { dietitian: DIETITIAN, currency: 'EUR', pay_in_app: false, services: SERVICES } : null,
  });
}

function slots(): { date: string; times: string[] }[] {
  const now = new Date();
  const out: { date: string; times: string[] }[] = [];
  for (let n = 0; n < 14; n++) {
    const d = addDays(midnight(), n);
    const date = toDateOnly(d);
    const ranges = d.getDay() === 0 ? [] : d.getDay() === 6 ? [[600, 810]] : [[540, 810], [1020, 1230]];
    const taken = new Set(db.appts.filter((a) => a.status !== 'cancelled' && a.starts_at.startsWith(date)).map((a) => a.starts_at.slice(11, 16)));
    const times: string[] = [];
    for (const [a, b] of ranges) {
      for (let x = a; x <= b; x += 30) {
        const time = `${pad(Math.floor(x / 60))}:${pad(x % 60)}`;
        if (!taken.has(time) && (n > 0 || x > now.getHours() * 60 + now.getMinutes() + 60)) times.push(time);
      }
    }
    out.push({ date, times });
  }
  return out;
}

const messagesAfter = (after: number): { messages: Message[] } => {
  db.msgs.forEach((m) => (m.read = true));
  return { messages: db.msgs.filter((m) => m.id > after).map((m) => ({ id: m.id, mine: m.mine, body: tx(m.body), at: m.at })) };
};

const num = (x: unknown) => (typeof x === 'number' && isFinite(x) ? x : typeof x === 'string' && x.trim() !== '' && isFinite(+x) ? +x : null);

function formParts(body: unknown): [string, any][] {
  const parts = (body as { _parts?: unknown } | null)?._parts;
  return Array.isArray(parts) ? (parts as [string, any][]) : [];
}

function needDietitian() {
  if (!db.dietitian) throw new ApiError(409, 'no_dietitian');
}

export async function demoCall(method: string, fullPath: string, body?: object | FormData): Promise<any> {
  const [path, query = ''] = fullPath.split('?');
  const param = (name: string) => {
    const m = new RegExp('(?:^|&)' + name + '=([^&]*)').exec(query);
    return m ? decodeURIComponent(m[1]) : '';
  };
  const form = formParts(body);
  const field = (name: string) => form.find((p) => p[0] === name)?.[1];
  const json: any = form.length ? {} : body ?? {};
  const route = method + ' ' + path;
  let m: RegExpExecArray | null;

  if (route === 'POST /register') return { token: 'demo-' + Date.now() };
  if (route === 'GET /me') return clone(me());
  if (route === 'PUT /me') {
    const { name, dietitian: _d, ...rest } = json as Partial<Me>;
    if (name !== undefined) db.name = name;
    db.me = { ...db.me, ...rest };
    return clone(me());
  }
  if (route === 'DELETE /me') {
    db = sample();
    return { deleted: true };
  }

  if (route === 'GET /scans') return { scans: clone(db.scans) };
  if (route === 'POST /scans') {
    const data = JSON.parse(String(field('data') ?? '{}'));
    const uris = form.filter((p) => p[0] === 'pages[]').map((p) => p[1]?.uri as string).filter(Boolean);
    const scan: Scan = { id: db.nextId++, machine: data.machine, scanned_at: data.scanned_at, page_count: uris.length, values: data.values ?? {} };
    db.scans.push(scan);
    db.pages[scan.id] = uris;
    return clone(scan);
  }
  if ((m = /^PUT \/scans\/(\d+)$/.exec(route))) {
    const scan = db.scans.find((s) => s.id === +m![1]);
    if (!scan) throw new ApiError(404, 'not_found');
    Object.assign(scan, { machine: json.machine, scanned_at: json.scanned_at, values: json.values ?? {} });
    return clone(scan);
  }
  if ((m = /^DELETE \/scans\/(\d+)$/.exec(route))) {
    db.scans = db.scans.filter((s) => s.id !== +m![1]);
    return { deleted: true };
  }
  if (route === 'POST /pdf-pages') throw new ApiError(0, 'demo');

  if (route === 'POST /connect') {
    if (!String(json.code ?? '').trim()) throw new ApiError(404, 'code_not_found');
    if (String(json.name ?? '').trim()) db.name = String(json.name).trim();
    db.dietitian = true;
    return clone(me());
  }
  if (route === 'DELETE /connect') {
    db.dietitian = false;
    return clone(me());
  }

  if (route === 'GET /sync') return sync();
  if (route === 'GET /foods') return { foods: FOODS.map((f, i): Food => ({ id: i + 1, ...f })) };
  if (route === 'POST /ocr') return { lines: [] }; // read on the phone instead
  if (route === 'POST /logs') {
    const data = JSON.parse(String(field('data') ?? '{}'));
    const items: DItem[] = (Array.isArray(data.items) ? data.items : [])
      .filter((i: any) => String(i?.text ?? '').trim())
      .map((i: any) => ({ text: String(i.text).trim(), grams: num(i.grams), kcal: num(i.kcal) }));
    db.logs.push({ id: db.nextId++, date: data.date, meal: data.meal, items, kcal: num(data.kcal), photo: field('photo')?.uri ?? null, from_plan: !!data.from_plan });
    return sync();
  }
  if ((m = /^DELETE \/logs\/(\d+)$/.exec(route))) {
    db.logs = db.logs.filter((l) => l.id !== +m![1]);
    return { deleted: true };
  }
  if (route === 'PUT /water') {
    db.water[json.date] = json.ml;
    return { date: json.date, ml: json.ml };
  }

  if (path === '/messages') {
    needDietitian();
    if (method === 'POST') {
      const text = String(json.body ?? '').trim();
      if (!text) throw new ApiError(422, 'empty');
      db.msgs.push({ id: db.nextId++, mine: true, body: text, at: toLocal(new Date()), read: true });
    }
    return messagesAfter(+param('after') || 0);
  }
  if (route === 'GET /slots') {
    needDietitian();
    return { days: slots() };
  }
  if (route === 'POST /appointments') {
    needDietitian();
    const svc = SERVICES.find((s) => s.id === json.service_id);
    const startsAt = String(json.starts_at ?? '');
    if (!svc || !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(startsAt)) throw new ApiError(422, 'bad_booking');
    if (!slots().some((d) => d.date === startsAt.slice(0, 10) && d.times.includes(startsAt.slice(11)))) throw new ApiError(409, 'slot_taken');
    db.appts.push({
      id: db.nextId++, title: svcTitle(svc), kind: svc.kind as Appointment['kind'], video: svc.video, starts_at: startsAt, minutes: svc.minutes,
      status: 'confirmed', created_by: 'client', price_cents: svc.price_cents, paid: false, call_started: false, with_dietitian: true,
    });
    return { ...sync(), pay_url: null };
  }
  if (route === 'POST /appointments/own') {
    for (const x of (Array.isArray(json.items) ? json.items : []).slice(0, 10)) {
      if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(String(x?.starts_at ?? ''))) continue;
      db.appts.push({
        id: db.nextId++, title: String(x.title ?? '').trim() || null, kind: ['appointment', 'remeasure', 'other'].includes(x.kind) ? x.kind : 'other',
        video: false, starts_at: x.starts_at, minutes: 30, status: 'confirmed', created_by: 'client', price_cents: 0, paid: false, call_started: false, with_dietitian: false,
      });
    }
    return sync();
  }
  if ((m = /^POST \/appointments\/(\d+)\/(confirm|cancel|pay|call)$/.exec(route))) {
    const a = db.appts.find((x) => x.id === +m![1]);
    if (!a) throw new ApiError(404, 'not_found');
    if (m[2] === 'confirm' && a.status === 'pending') a.status = 'confirmed';
    if (m[2] === 'cancel') a.status = 'cancelled';
    if (m[2] === 'pay') {
      a.paid = true;
      return { paid: true };
    }
    if (m[2] === 'call') throw new ApiError(0, 'demo');
    return sync();
  }
  if (route === 'POST /device') return { ok: true };
  if (route === 'POST /plan/paper') {
    const times: string[] = Array.isArray(json.times) ? json.times : [];
    const def = ['08:00', '11:00', '14:00', '17:30', '20:30'];
    db.plan = {
      id: db.nextId++,
      name: String(json.name ?? '').trim() || null,
      start_date: mondayThisWeek(),
      end_date: null,
      note: null,
      times: def.map((d, i) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(times[i] ?? '') ? times[i] : d)),
      days: Array.from({ length: 7 }, (_, d) => ({
        meals: Array.from({ length: 5 }, (_, k) => {
          const meal = json.days?.[d]?.meals?.[k];
          const items: DItem[] = (Array.isArray(meal?.items) ? meal.items : [])
            .filter((i: any) => String(i?.text ?? '').trim())
            .map((i: any) => ({ text: String(i.text).trim(), grams: num(i.grams), kcal: num(i.kcal), food_id: num(i.food_id) }));
          return { items, note: String(meal?.note ?? '').trim() };
        }),
      })),
      source: 'paper',
      dietitian: null,
      updated_at: toLocal(new Date()) + ':00',
    };
    return sync();
  }
  throw new ApiError(404, 'not_found');
}

// Where the photo of a sheet page is: a photo taken during the demo, or the sample sheet.
export function demoPageUrl(scanId: number, page: number): string {
  return db.pages[scanId]?.[page - 1] ?? sheetFile.uri;
}

// The photo of a meal logged during the demo.
export function demoLogPhoto(id: number): string {
  return db.logs.find((l) => l.id === id)?.photo ?? '';
}
