// App data: login token, settings, the user's scans and profile.
// Scans live on the server; a copy is kept on the phone so the app works offline.
import { useSyncExternalStore } from 'react';
import * as SecureStore from 'expo-secure-store';
import { File, Paths } from 'expo-file-system';
import { Linking, Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as WebBrowser from 'expo-web-browser';
import { api, api3, ApiError, Appointment, Booking, Food, Goal, Me, MealLog, Message, OcrBox, Plan, PlanItem, PlanMeal, Scan, ScanInput, Sync } from './api';
import { LangSetting, lang, setLanguage } from './i18n';
import { Extra, scheduleReminder, setExtras } from './reminders';
import { addDays, parseLocal, toLocal } from './format';

export type Every = '2w' | '1m' | '2m' | null;

export type Prefs = {
  onboarded: boolean;
  weight: 'kg' | 'lb';
  length: 'cm' | 'in';
  every: Every;
  nextScan: string | null; // "2026-11-16 09:30"
  remind: boolean;
  language: LangSetting;
  waterGoal: number; // ml a day
  glass: number; // ml in one glass
  remindMeals: boolean;
  remindWater: boolean;
  remindAppts: boolean;
  shopDone: string[]; // shopping list items ticked, "planId|item"
};

const DEFAULT_PREFS: Prefs = {
  onboarded: false,
  weight: 'kg',
  length: 'cm',
  every: '1m',
  nextScan: null,
  remind: true,
  language: 'auto',
  waterGoal: 2000,
  glass: 250,
  remindMeals: false,
  remindWater: false,
  remindAppts: true,
  shopDone: [],
};

// Everything the dietitian's website sends to the app (plan, meals, water, goals, appointments, chat).
export type SyncData = {
  plan: Plan | null;
  logs: MealLog[];
  water: Record<string, number>;
  goals: Goal[];
  appointments: Appointment[];
  unread: number;
  booking: Booking | null;
};

const EMPTY_SYNC: SyncData = { plan: null, logs: [], water: {}, goals: [], appointments: [], unread: 0, booking: null };

type State = { ready: boolean; token: string | null; me: Me | null; scans: Scan[]; prefs: Prefs; sync: SyncData; foods: Food[] };

let state: State = { ready: false, token: null, me: null, scans: [], prefs: DEFAULT_PREFS, sync: EMPTY_SYNC, foods: [] };
const listeners = new Set<() => void>();

function set(patch: Partial<State>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

export const getState = () => state;

// Pick one field of the state; the screen re-renders when it changes.
export function useStore<T>(select: (s: State) => T): T {
  return useSyncExternalStore(subscribe, () => select(state));
}

// ---------- Files on the phone ----------

const TOKEN_KEY = 'bst_token';
const prefsFile = () => new File(Paths.document, 'prefs.json');
const cacheFile = () => new File(Paths.document, 'cache.json');

async function readJson<T>(file: File): Promise<T | null> {
  try {
    if (!file.exists) return null;
    return JSON.parse(await file.text()) as T;
  } catch {
    return null;
  }
}

async function writeJson(file: File, data: unknown): Promise<void> {
  try {
    if (file.exists) file.delete();
    file.create();
    await file.write(JSON.stringify(data));
  } catch {
    // ignore: the copy on the phone is only a cache
  }
}

function saveCache() {
  writeJson(cacheFile(), { me: state.me, scans: state.scans, sync: state.sync, foods: state.foods });
}

const sortScans = (list: Scan[]) =>
  [...list].sort((a, b) => (a.scanned_at < b.scanned_at ? -1 : a.scanned_at > b.scanned_at ? 1 : a.id - b.id));

// ---------- Start-up and account ----------

let started = false;

export async function init(): Promise<void> {
  if (started) return;
  started = true;
  const saved = await readJson<Partial<Prefs>>(prefsFile());
  const prefs = { ...DEFAULT_PREFS, ...(saved ?? {}) };
  setLanguage(prefs.language);
  const cache = await readJson<{ me: Me | null; scans: Scan[]; sync?: SyncData; foods?: Food[] }>(cacheFile());
  let token: string | null = null;
  try {
    token = await SecureStore.getItemAsync(TOKEN_KEY);
  } catch {
    token = null;
  }
  set({ ready: true, prefs, token, me: cache?.me ?? null, scans: sortScans(cache?.scans ?? []), sync: { ...EMPTY_SYNC, ...(cache?.sync ?? {}) }, foods: cache?.foods ?? [] });
  updateExtras();
  if (token) refresh().catch(() => undefined);
}

// Every phone gets its own account the first time; no sign-up needed.
export async function ensureToken(): Promise<string> {
  if (state.token) return state.token;
  const { token } = await api.register();
  await SecureStore.setItemAsync(TOKEN_KEY, token);
  set({ token });
  return token;
}

async function authed<T>(fn: (token: string) => Promise<T>): Promise<T> {
  const token = await ensureToken();
  try {
    return await fn(token);
  } catch (e) {
    if (e instanceof ApiError && e.status === 401) {
      // The account no longer exists on the server: start a new one.
      await SecureStore.deleteItemAsync(TOKEN_KEY).catch(() => undefined);
      set({ token: null, me: null, scans: [], sync: EMPTY_SYNC });
      return fn(await ensureToken());
    }
    throw e;
  }
}

export async function refresh(): Promise<void> {
  const [me, list] = await authed((tk) => Promise.all([api.me(tk), api.scans(tk)]));
  set({ me, scans: sortScans(list.scans) });
  saveCache();
  await refreshSync().catch(() => undefined);
}

// ---------- Settings ----------

export async function setPrefs(patch: Partial<Prefs>): Promise<void> {
  const prefs = { ...state.prefs, ...patch };
  set({ prefs });
  if (patch.language !== undefined) setLanguage(prefs.language);
  await writeJson(prefsFile(), prefs);
  if ('remindMeals' in patch || 'remindWater' in patch || 'remindAppts' in patch || 'language' in patch) {
    updateExtras(false);
  }
  if ('nextScan' in patch || 'remind' in patch || 'language' in patch || 'remindMeals' in patch || 'remindWater' in patch || 'remindAppts' in patch) {
    scheduleReminder(prefs.nextScan, prefs.remind);
  }
  if ('language' in patch) registerDevice().catch(() => undefined);
}

export function addEvery(d: Date, every: Every): Date {
  const x = new Date(d);
  if (every === '2w') return addDays(x, 14);
  if (every === '1m') x.setMonth(x.getMonth() + 1);
  if (every === '2m') x.setMonth(x.getMonth() + 2);
  return x;
}

// After a new scan, move the next scan date forward (keeping the usual time of day).
function moveNextScan(scannedAt: string) {
  const { every, nextScan } = state.prefs;
  const scanDate = parseLocal(scannedAt);
  if (!every || !scanDate) return;
  const current = parseLocal(nextScan);
  if (current && current.getTime() > Date.now() && current.getTime() > scanDate.getTime() + 3 * 86400000) return;
  const next = addEvery(scanDate, every);
  next.setHours(current ? current.getHours() : 9, current ? current.getMinutes() : 30, 0, 0);
  if (next.getTime() > Date.now()) setPrefs({ nextScan: toLocal(next) });
}

// ---------- Scans ----------

export async function createScan(data: ScanInput, pageUris: string[]): Promise<Scan> {
  const scan = await authed((tk) => api.createScan(tk, data, pageUris));
  set({ scans: sortScans([...state.scans.filter((s) => s.id !== scan.id), scan]) });
  saveCache();
  moveNextScan(scan.scanned_at);
  return scan;
}

export async function updateScan(id: number, data: ScanInput): Promise<Scan> {
  const scan = await authed((tk) => api.updateScan(tk, id, data));
  set({ scans: sortScans(state.scans.map((s) => (s.id === id ? scan : s))) });
  saveCache();
  return scan;
}

export async function deleteScan(id: number): Promise<void> {
  await authed((tk) => api.deleteScan(tk, id));
  set({ scans: state.scans.filter((s) => s.id !== id) });
  saveCache();
}

// ---------- Profile and dietitian ----------

export async function updateMe(patch: Partial<Omit<Me, 'dietitian'>>): Promise<void> {
  const me = await authed((tk) => api.updateMe(tk, patch));
  set({ me });
  saveCache();
}

export async function connectDietitian(code: string, name: string): Promise<Me> {
  const me = await authed((tk) => api.connect(tk, code, name));
  set({ me });
  saveCache();
  return me;
}

export async function disconnectDietitian(): Promise<void> {
  const me = await authed((tk) => api.disconnect(tk));
  set({ me });
  saveCache();
}

export async function pdfToPages(uri: string, name: string): Promise<string[]> {
  const res = await authed((tk) => api.pdfPages(tk, uri, name));
  return res.pages;
}

// Deletes everything on the server and on the phone.
export async function deleteAllData(): Promise<void> {
  if (state.token) await authed((tk) => api.deleteMe(tk));
  await SecureStore.deleteItemAsync(TOKEN_KEY).catch(() => undefined);
  for (const f of [cacheFile(), prefsFile()]) {
    try {
      if (f.exists) f.delete();
    } catch {
      // ignore
    }
  }
  const prefs = { ...DEFAULT_PREFS, language: state.prefs.language };
  set({ token: null, me: null, scans: [], prefs, sync: EMPTY_SYNC, foods: [] });
  setExtras([]);
  scheduleReminder(null, false);
}

// ---------- Version 3: what the dietitian's website and the app share ----------

function applySync(data: Sync) {
  const { me, pay_url: _pay, ...rest } = data;
  set({ me, sync: { ...EMPTY_SYNC, ...rest, water: { ...(rest.water ?? {}) } } });
  saveCache();
  updateExtras();
}

export async function refreshSync(): Promise<void> {
  applySync(await authed((tk) => api3.sync(tk)));
  registerDevice().catch(() => undefined);
}

// Text of one photo, read on your own server.
export async function serverOcr(uri: string): Promise<OcrBox[]> {
  const res = await authed((tk) => api3.ocr(tk, uri));
  return res.lines ?? [];
}

export async function loadFoods(): Promise<Food[]> {
  try {
    const res = await authed((tk) => api3.foods(tk));
    set({ foods: res.foods });
    saveCache();
  } catch {
    // keep the copy on the phone
  }
  return state.foods;
}

export async function logMeal(data: { date: string; meal: number; items: PlanItem[]; kcal: number | null; from_plan: boolean }, photoUri?: string | null): Promise<void> {
  applySync(await authed((tk) => api3.addLog(tk, data, photoUri)));
}

export async function deleteLog(id: number): Promise<void> {
  await authed((tk) => api3.deleteLog(tk, id));
  set({ sync: { ...state.sync, logs: state.sync.logs.filter((l) => l.id !== id) } });
  saveCache();
}

// Water shows at once; the server is told straight after.
export async function setWater(date: string, ml: number): Promise<void> {
  const before = state.sync.water[date] ?? 0;
  const value = Math.max(0, Math.min(20000, Math.round(ml)));
  set({ sync: { ...state.sync, water: { ...state.sync.water, [date]: value } } });
  try {
    await authed((tk) => api3.setWater(tk, date, value));
    saveCache();
  } catch (e) {
    set({ sync: { ...state.sync, water: { ...state.sync.water, [date]: before } } });
    throw e;
  }
}

export async function chatMessages(after: number): Promise<Message[]> {
  const res = await authed((tk) => api3.messages(tk, after));
  if (state.sync.unread) set({ sync: { ...state.sync, unread: 0 } });
  return res.messages;
}

export async function sendMessage(body: string, after: number): Promise<Message[]> {
  const res = await authed((tk) => api3.send(tk, body, after));
  return res.messages;
}

export async function getSlots(serviceId: number) {
  const res = await authed((tk) => api3.slots(tk, serviceId));
  return res.days;
}

// Books a free time. If the dietitian takes card payments in the app, the payment page opens.
export async function book(serviceId: number, startsAt: string): Promise<{ paid: boolean | null }> {
  const res = await authed((tk) => api3.book(tk, serviceId, startsAt, lang()));
  applySync(res);
  if (!res.pay_url) return { paid: null };
  await WebBrowser.openBrowserAsync(res.pay_url).catch(() => undefined);
  await refreshSync().catch(() => undefined);
  const a = state.sync.appointments.find((x) => x.starts_at === startsAt && x.created_by === 'client');
  return { paid: !!a?.paid };
}

export async function apptAction(id: number, action: 'confirm' | 'cancel'): Promise<void> {
  applySync(await authed((tk) => api3.apptAction(tk, id, action)));
}

export async function payAppt(id: number): Promise<boolean> {
  const res = await authed((tk) => api3.pay(tk, id));
  if (res.url) await WebBrowser.openBrowserAsync(res.url).catch(() => undefined);
  await refreshSync().catch(() => undefined);
  return !!state.sync.appointments.find((a) => a.id === id)?.paid;
}

// The video call opens in the phone's browser (camera and microphone work there, nothing to install).
export async function joinCall(id: number): Promise<void> {
  const res = await authed((tk) => api3.callUrl(tk, id, lang()));
  await Linking.openURL(res.url);
}

export async function addOwnDates(items: { title: string; kind: string; starts_at: string }[]): Promise<void> {
  applySync(await authed((tk) => api3.ownDates(tk, items)));
}

export async function savePaperPlan(days: { meals: PlanMeal[] }[], times: string[], name: string): Promise<void> {
  applySync(await authed((tk) => api3.paperPlan(tk, days, times, name)));
}

// Tells the website where to send notifications (messages, plans, appointments). Only works when
// the app was built with Firebase (google-services.json); without it, nothing happens.
let lastDevice = '';
export async function registerDevice(): Promise<void> {
  if (!state.token || !state.me?.dietitian) return;
  const perm = await Notifications.getPermissionsAsync();
  if (!perm.granted) return;
  const push = await Notifications.getDevicePushTokenAsync();
  const value = typeof push.data === 'string' ? push.data : '';
  const key = value + '|' + lang();
  if (!value || key === lastDevice) return;
  await authed((tk) => api3.device(tk, { token: value, platform: Platform.OS === 'ios' ? 'ios' : 'android', lang: lang() }));
  lastDevice = key;
}

// ---------- Reminders from the plan and appointments ----------

function updateExtras(reschedule = true) {
  const { prefs, sync } = state;
  const list: Extra[] = [];
  if (prefs.remindAppts) {
    const soon = sync.appointments
      .filter((a) => a.status !== 'cancelled' && (parseLocal(a.starts_at)?.getTime() ?? 0) > Date.now())
      .slice(0, 10);
    for (const a of soon) list.push({ kind: 'appointment', at: a.starts_at, title: a.title ?? '', video: a.video });
  }
  if (prefs.remindMeals && sync.plan) {
    sync.plan.times.forEach((time, meal) => {
      if (/^\d{1,2}:\d{2}$/.test(time ?? '')) list.push({ kind: 'meal', meal, time });
    });
  }
  if (prefs.remindWater) {
    for (const time of ['11:00', '14:00', '17:00']) list.push({ kind: 'water', time });
  }
  setExtras(list);
  if (reschedule) scheduleReminder(prefs.nextScan, prefs.remind);
}

// ---------- Helpers for the screens ----------

// Monday = 0 … Sunday = 6, the same order as the meal plan.
export const weekdayIndex = (d: Date) => (d.getDay() + 6) % 7;

export function planDay(plan: Plan | null, d: Date): PlanMeal[] {
  return plan?.days?.[weekdayIndex(d)]?.meals ?? [];
}

export const itemsKcal = (items: PlanItem[]) => {
  const known = items.filter((i) => typeof i.kcal === 'number');
  return known.length ? known.reduce((n, i) => n + (i.kcal ?? 0), 0) : null;
};
