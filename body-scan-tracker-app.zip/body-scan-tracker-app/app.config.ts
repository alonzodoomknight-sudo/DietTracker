import type { ExpoConfig } from 'expo/config';
import { existsSync } from 'fs';

// Set in GitHub: Settings → Secrets and variables → Actions → Variables
const apiBaseUrl = process.env.EXPO_PUBLIC_API_BASE_URL ?? '';
const appId = process.env.APP_ID || 'com.bodyscantracker.app';
const build = Number(process.env.BUILD_NUMBER || '1');
// Optional: Firebase file for notifications from the website (messages, plans, appointments).
// Without it the app works the same; only those notifications are off. Reminders on the phone still work.
const googleServices = existsSync('./google-services.json') ? './google-services.json' : undefined;

const config: ExpoConfig = {
  name: 'Body Scan Tracker',
  slug: 'body-scan-tracker',
  scheme: 'bodyscantracker',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/icon.png',
  userInterfaceStyle: 'light',
  platforms: ['ios', 'android'],
  ios: {
    bundleIdentifier: appId,
    buildNumber: String(build),
    supportsTablet: false,
    infoPlist: {
      ITSAppUsesNonExemptEncryption: false,
    },
  },
  android: {
    package: appId,
    versionCode: build,
    ...(googleServices ? { googleServicesFile: googleServices } : {}),
    adaptiveIcon: {
      foregroundImage: './assets/adaptive-icon.png',
      backgroundColor: '#0E6B5C',
    },
  },
  // Permission texts in Greek and English (iPhone)
  locales: {
    en: './locales/en.json',
    el: './locales/el.json',
  },
  plugins: [
    'expo-router',
    [
      'expo-camera',
      {
        cameraPermission: 'Take photos of your body scan sheets, meal plans and meals.',
        recordAudioAndroid: false,
      },
    ],
    ['expo-image-picker', { photosPermission: 'Pick photos of your body scan sheets and meal plans.', cameraPermission: false, microphonePermission: false }],
    // Finds the sheet's edges by itself, takes the photo when it holds still and straightens it (on the phone, no AI service)
    ['react-native-document-scanner-plugin', { cameraPermission: 'Take photos of your body scan sheets, meal plans and meals.' }],
    ['expo-media-library', { savePhotosPermission: 'Save photos of your scan sheets to your photos.', isAccessMediaLocationEnabled: false }],
    ['expo-notifications', { color: '#0E6B5C' }],
    ['expo-localization', { supportedLocales: { ios: ['en', 'el'], android: ['en', 'el'] } }],
    'expo-secure-store',
    ['expo-splash-screen', { image: './assets/splash-icon.png', imageWidth: 160, backgroundColor: '#F5F6F3' }],
    // Only an http:// server address needs unencrypted traffic; https:// is strongly recommended.
    ['expo-build-properties', { android: { usesCleartextTraffic: apiBaseUrl.startsWith('http://') } }],
  ],
  extra: process.env.EAS_PROJECT_ID ? { eas: { projectId: process.env.EAS_PROJECT_ID } } : {},
};

export default config;
