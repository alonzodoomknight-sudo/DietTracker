// 19 Appointments: confirm, cancel, pay, join the video call, book a new one, add dates from paper
import React, { useCallback, useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Bubble, Button, Card, Header, Icon, Label, Muted, Notice, Screen, Tag } from '../src/ui';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { apptAction, joinCall, payAppt, refreshSync, useStore } from '../src/store';
import { Appointment, errorKey } from '../src/api';
import { fmtLong, fmtMoney, fmtTime, parseLocal } from '../src/format';

export default function Appointments() {
  useLang();
  const list = useStore((s) => s.sync.appointments);
  const booking = useStore((s) => s.sync.booking);
  const [busy, setBusy] = useState<string>('');
  const [error, setError] = useState('');

  useFocusEffect(
    useCallback(() => {
      refreshSync().catch(() => undefined);
    }, []),
  );

  const run = async (key: string, fn: () => Promise<unknown>) => {
    setBusy(key);
    setError('');
    try {
      await fn();
    } catch (e) {
      setError(t(errorKey(e)));
    } finally {
      setBusy('');
    }
  };

  const now = Date.now();
  const end = (a: Appointment) => (parseLocal(a.starts_at)?.getTime() ?? 0) + a.minutes * 60000;
  const upcoming = list.filter((a) => a.status !== 'cancelled' && end(a) > now);
  const past = list.filter((a) => a.status === 'cancelled' || end(a) <= now).reverse();

  const card = (a: Appointment, old: boolean) => {
    const at = parseLocal(a.starts_at);
    if (!at) return null;
    const soon = at.getTime() - now < 15 * 60000 && end(a) + 30 * 60000 > now;
    const title = a.title || t(a.kind === 'remeasure' ? 'ap_remeasure' : a.kind === 'other' ? 'ap_other' : 'ap_appointment');
    return (
      <Card key={a.id} style={{ gap: 10, opacity: old ? 0.65 : 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Bubble icon={a.video ? 'video' : a.kind === 'remeasure' ? 'scan' : 'calendar'} tone={a.video ? 'navy' : 'teal'} />
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.ink }}>{title}</Text>
            <Muted>{`${fmtLong(at)}, ${fmtTime(at)} · ${t('ap_minutes', { n: a.minutes })}`}</Muted>
          </View>
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
          {a.status === 'cancelled' && <Tag text={t('ap_cancelled')} bg={C.soft} color={C.muted} />}
          {a.status === 'pending' && <Tag text={t('ap_pending')} bg={C.warnBg} color={C.warnInk} />}
          {a.status === 'unpaid' && <Tag text={t('ap_unpaid')} bg={C.warnBg} color={C.warnInk} />}
          {a.status === 'confirmed' && <Tag text={t('ap_confirmed')} />}
          {a.video && <Tag text={t('ap_video')} bg={C.lowBg} color={C.lowInk} />}
          {!a.with_dietitian && <Tag text={t('ap_own')} bg={C.soft} color={C.muted} />}
          {a.price_cents > 0 && booking && <Tag text={`${fmtMoney(a.price_cents, booking.currency)}${a.paid ? ' · ' + t('ap_paid') : ''}`} bg={C.soft} color={C.body} />}
        </View>
        {!old && (
          <View style={{ gap: 8 }}>
            {a.status === 'pending' && <Button title={t('ap_confirm')} icon="check" loading={busy === 'c' + a.id} onPress={() => run('c' + a.id, () => apptAction(a.id, 'confirm'))} />}
            {a.status === 'unpaid' && (
              <Button
                title={t('ap_pay')}
                icon="card"
                loading={busy === 'p' + a.id}
                onPress={() =>
                  run('p' + a.id, async () => {
                    const paid = await payAppt(a.id);
                    if (paid) Alert.alert(t('ap_paid_title'));
                  })
                }
              />
            )}
            {a.video && a.with_dietitian && a.status !== 'unpaid' && (soon || a.call_started) && (
              <Button title={t('ap_join')} icon="video" loading={busy === 'v' + a.id} onPress={() => run('v' + a.id, () => joinCall(a.id))} />
            )}
            {a.video && a.with_dietitian && !(soon || a.call_started) && <Muted>{t('ap_join_note')}</Muted>}
            <Button
              title={t('ap_cancel')}
              kind="danger"
              onPress={() =>
                Alert.alert(t('ap_cancel_q'), a.paid ? t('ap_cancel_paid') : undefined, [
                  { text: t('ap_keep'), style: 'cancel' },
                  { text: t('ap_cancel'), style: 'destructive', onPress: () => run('x' + a.id, () => apptAction(a.id, 'cancel')) },
                ])
              }
            />
          </View>
        )}
      </Card>
    );
  };

  return (
    <Screen header={<Header title={t('ap_title')} />}>
      {!!error && <Notice tone="error" title={error} />}
      <View style={{ flexDirection: 'row', gap: 10 }}>
        {booking && <Button title={t('bk_title')} icon="plus" onPress={() => router.push('/book')} style={{ flex: 1 }} />}
        <Button title={t('ad_title')} kind="secondary" icon="calendar" onPress={() => router.push('/add-dates')} style={{ flex: 1 }} />
      </View>
      <Label>{t('ap_upcoming')}</Label>
      {upcoming.length ? upcoming.map((a) => card(a, false)) : <Muted>{t('ap_none')}</Muted>}
      {past.length > 0 && <Label>{t('ap_past')}</Label>}
      {past.slice(0, 20).map((a) => card(a, true))}
    </Screen>
  );
}
