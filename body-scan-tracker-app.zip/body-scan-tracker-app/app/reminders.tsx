// 02 Scan reminders
import React, { useState } from 'react';
import { Pressable, Switch, Text, View } from 'react-native';
import { router } from 'expo-router';
import { BackButton, Body, Button, Card, H1, Icon, Label, Muted, Screen } from '../src/ui';
import { PickerBox, usePicker } from '../src/datetime';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { Every, addEvery, setPrefs, useStore } from '../src/store';
import { askNotificationPermission, reminderDate } from '../src/reminders';
import { fmtLong, fmtTime, fmtWeekdayLong, parseLocal, toLocal } from '../src/format';

const OPTIONS: { value: Every; key: 'r_2w' | 'r_1m' | 'r_2m' | 'r_unsure' }[] = [
  { value: '2w', key: 'r_2w' },
  { value: '1m', key: 'r_1m' },
  { value: '2m', key: 'r_2m' },
  { value: null, key: 'r_unsure' },
];

function defaultNext(every: Every): Date {
  const d = addEvery(new Date(), every ?? '1m');
  d.setHours(9, 30, 0, 0);
  return d;
}

export default function Reminders() {
  useLang();
  const prefs = useStore((s) => s.prefs);
  const [every, setEvery] = useState<Every>(prefs.every);
  const [next, setNext] = useState<Date | null>(parseLocal(prefs.nextScan));
  const [remind, setRemind] = useState(prefs.remind);
  const picker = usePicker();

  const pickDate = () =>
    picker.open('date', next ?? defaultNext(every), (d) => {
      const x = new Date(d);
      const base = next ?? defaultNext(every);
      x.setHours(base.getHours(), base.getMinutes(), 0, 0);
      setNext(x);
    });
  const pickTime = () =>
    picker.open('time', next ?? defaultNext(every), (d) => {
      const x = new Date(next ?? defaultNext(every));
      x.setHours(d.getHours(), d.getMinutes(), 0, 0);
      setNext(x);
    });

  const finish = async () => {
    if (remind && next) await askNotificationPermission();
    await setPrefs({ every, nextScan: next ? toLocal(next) : null, remind, onboarded: true });
    router.replace('/home');
  };

  const reminder = next ? reminderDate(toLocal(next)) : null;

  return (
    <Screen footer={<Button title={t('continue')} onPress={finish} />}>
      <View style={{ flexDirection: 'row' }}>
        <BackButton to="/welcome" />
      </View>
      <View style={{ height: 8 }} />
      <H1>{t('r_title')}</H1>
      <Body>{t('r_body')}</Body>

      <Label>{t('r_how')}</Label>
      <Card style={{ padding: 0, paddingHorizontal: 16 }}>
        {OPTIONS.map((o, i) => {
          const on = every === o.value;
          return (
            <Pressable
              key={o.key}
              accessibilityRole="radio"
              accessibilityState={{ checked: on }}
              onPress={() => setEvery(o.value)}
              style={{ minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: i < OPTIONS.length - 1 ? 1 : 0, borderBottomColor: C.soft }}
            >
              <View style={{ width: 22, height: 22, borderRadius: 11, borderWidth: on ? 7 : 2, borderColor: on ? C.accent : C.faint }} />
              <Text style={{ flex: 1, fontSize: 16, fontWeight: on ? '700' : '500', color: C.ink }}>{t(o.key)}</Text>
            </Pressable>
          );
        })}
      </Card>

      <Label>{t('r_next')}</Label>
      <PickerBox label={t('r_next')} text={next ? fmtLong(next) : t('r_pick_date')} onPress={pickDate} />
      {next && <PickerBox label={t('r_next')} icon="bell" text={fmtTime(next)} onPress={pickTime} />}

      <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Icon name="bell" color={C.accent} />
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 15, fontWeight: '600', color: C.ink }}>{t('r_remind')}</Text>
          {reminder && <Muted>{t('r_remind_at', { date: fmtWeekdayLong(reminder) })}</Muted>}
        </View>
        <Switch
          accessibilityLabel={t('r_remind')}
          value={remind}
          onValueChange={setRemind}
          trackColor={{ true: C.accent, false: '#C8D1DB' }}
          thumbColor="#FFFFFF"
        />
      </Card>
      {picker.element}
    </Screen>
  );
}
