// 18 Chat with the dietitian (the website's Messages page on the other side)
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, Text, TextInput, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { BackButton, BottomNav, Button, Card, DARK_RIM, Grad, GRADS, H1, Icon, Muted, RIM, SHADOW, Screen, WELL } from '../src/ui';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { chatMessages, sendMessage, useStore } from '../src/store';
import { Message, errorKey } from '../src/api';
import { fmtTime, fmtWeekday, parseLocal } from '../src/format';

export default function Chat() {
  useLang();
  const dietitian = useStore((s) => s.me?.dietitian);
  const connected = dietitian?.status === 'accepted';
  const [list, setList] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [error, setError] = useState('');
  const [sending, setSending] = useState(false);
  const lastId = useRef(0);
  const listRef = useRef<FlatList<Message>>(null);

  const merge = (msgs: Message[]) => {
    if (!msgs.length) return;
    setList((old) => {
      const seen = new Set(old.map((m) => m.id));
      const next = [...old, ...msgs.filter((m) => !seen.has(m.id))].sort((a, b) => a.id - b.id);
      lastId.current = next.length ? next[next.length - 1].id : 0;
      return next;
    });
  };

  // New messages every 4 seconds while the chat is open.
  useFocusEffect(
    useCallback(() => {
      if (!connected) return undefined;
      let alive = true;
      const poll = async () => {
        try {
          const msgs = await chatMessages(lastId.current);
          if (alive) {
            merge(msgs);
            setError('');
          }
        } catch (e) {
          if (alive) setError(t(errorKey(e)));
        }
      };
      poll();
      const timer = setInterval(poll, 4000);
      return () => {
        alive = false;
        clearInterval(timer);
      };
    }, [connected]),
  );

  useEffect(() => {
    if (list.length) setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 50);
  }, [list.length]);

  const send = async () => {
    const body = text.trim();
    if (!body || sending) return;
    setSending(true);
    try {
      merge(await sendMessage(body, lastId.current));
      setText('');
      setError('');
    } catch (e) {
      setError(t(errorKey(e)));
    } finally {
      setSending(false);
    }
  };

  const header = (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 20, paddingTop: 8, paddingBottom: 6 }}>
      <BackButton to="/today" />
      <View style={{ flex: 1 }}>
        <H1>{connected ? dietitian!.name : t('nav_chat')}</H1>
        {connected && <Muted>{t('ch_sub')}</Muted>}
      </View>
    </View>
  );

  if (!connected) {
    return (
      <Screen header={header} bottom={<BottomNav active="chat" />}>
        <Card style={{ alignItems: 'center', gap: 12, paddingVertical: 28 }}>
          <Icon name="message" size={36} color={C.accent} />
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.ink, textAlign: 'center' }}>{t('ch_none')}</Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: C.body, textAlign: 'center' }}>{dietitian ? t('ch_pending', { name: dietitian.name }) : t('ch_none_body')}</Text>
          {!dietitian && <Button title={t('st_connect')} onPress={() => router.push('/connect')} style={{ alignSelf: 'stretch' }} />}
        </Card>
      </Screen>
    );
  }

  const dayOf = (m?: Message) => {
    const d = m ? parseLocal(m.at) : null;
    return d ? fmtWeekday(d) : '';
  };
  return (
    <Screen header={header} scroll={false} bottom={<BottomNav active="chat" />}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <FlatList
          ref={listRef}
          data={list}
          keyExtractor={(m) => String(m.id)}
          contentContainerStyle={{ padding: 16, gap: 8 }}
          ListEmptyComponent={<Muted style={{ textAlign: 'center', marginTop: 24 }}>{t('ch_empty')}</Muted>}
          renderItem={({ item, index }) => {
            const at = parseLocal(item.at);
            const day = dayOf(item);
            const showDay = day !== dayOf(list[index - 1]);
            return (
              <View>
                {showDay && <Muted style={{ textAlign: 'center', marginVertical: 6 }}>{day}</Muted>}
                <View
                  style={[
                    {
                      alignSelf: item.mine ? 'flex-end' : 'flex-start',
                      maxWidth: '82%',
                      backgroundColor: item.mine ? C.accent : C.card,
                      borderRadius: 20,
                      borderBottomRightRadius: item.mine ? 6 : 20,
                      borderBottomLeftRadius: item.mine ? 20 : 6,
                      paddingHorizontal: 14,
                      paddingVertical: 9,
                      boxShadow: item.mine ? SHADOW.teal : SHADOW.card,
                    } as any,
                    item.mine ? DARK_RIM : RIM,
                  ]}
                >
                  <Text style={{ fontSize: 15, lineHeight: 21, color: item.mine ? '#FFFFFF' : C.ink }}>{item.body}</Text>
                  <Text style={{ fontSize: 11, marginTop: 2, color: item.mine ? '#CDEBE2' : C.muted, textAlign: 'right' }}>{at ? fmtTime(at) : ''}</Text>
                </View>
              </View>
            );
          }}
        />
        {!!error && <Text style={{ color: C.danger, paddingHorizontal: 16, paddingBottom: 4 }}>{error}</Text>}
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 10, paddingHorizontal: 14, paddingVertical: 10, boxShadow: '0 -4px 12px rgba(27,45,70,0.08)' } as any}>
          <Grad colors={GRADS.nav} />
          <TextInput
            accessibilityLabel={t('ch_write')}
            value={text}
            onChangeText={setText}
            placeholder={t('ch_write')}
            placeholderTextColor={C.faint}
            multiline
            maxLength={4000}
            style={[{ flex: 1, minHeight: 46, maxHeight: 120, borderRadius: 23, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 12, fontSize: 15, color: C.ink }, WELL]}
          />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t('ch_send')}
            disabled={!text.trim() || sending}
            onPress={send}
            style={[{ width: 46, height: 46, borderRadius: 23, backgroundColor: text.trim() ? C.accent : C.faint, alignItems: 'center', justifyContent: 'center' }, text.trim() ? ({ boxShadow: SHADOW.teal, ...DARK_RIM } as any) : null]}
          >
            {!!text.trim() && <Grad colors={GRADS.primary} radius={23} />}
            <Icon name="send" size={20} color="#FFFFFF" />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}
