// 25 Book an appointment: service, day, time, then pay by card or at the office
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { router } from 'expo-router';
import { Button, Card, Header, Icon, Label, Muted, Notice, Screen, Tag } from '../src/ui';
import { C } from '../src/theme';
import { lang, t, useLang } from '../src/i18n';
import { book, getSlots, useStore } from '../src/store';
import { Service, errorKey } from '../src/api';
import { Chip } from '../src/meals';
import { fmtLong, fmtMoney, fmtWeekday, parseLocal } from '../src/format';

export default function Book() {
  useLang();
  const booking = useStore((s) => s.sync.booking);
  const [service, setService] = useState<Service | null>(null);
  const [days, setDays] = useState<{ date: string; times: string[] }[] | null>(null);
  const [day, setDay] = useState<string | null>(null);
  const [time, setTime] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!service) return;
    setDays(null);
    setDay(null);
    setTime(null);
    getSlots(service.id)
      .then((d) => {
        const open = d.filter((x) => x.times.length);
        setDays(open);
        setDay(open[0]?.date ?? null);
      })
      .catch((e) => {
        setDays([]);
        setError(t(errorKey(e)));
      });
  }, [service]);

  if (!booking) {
    return (
      <Screen header={<Header title={t('bk_title')} />}>
        <Muted>{t('bk_need_dt')}</Muted>
      </Screen>
    );
  }

  const name = (s: Service) => (lang() === 'el' ? s.el : s.en) || s.el || s.en;
  const card = booking.pay_in_app && (service?.price_cents ?? 0) > 0;

  const confirm = async () => {
    if (!service || !day || !time) return;
    setBusy(true);
    setError('');
    try {
      const res = await book(service.id, `${day} ${time}`);
      if (res.paid === false) Alert.alert(t('bk_not_paid'), t('bk_not_paid_body'));
      else Alert.alert(t('bk_done'), card ? t('bk_done_paid') : t('bk_done_body'));
      router.replace('/appointments');
    } catch (e) {
      setError(e instanceof Error && e.message === 'slot_taken' ? t('bk_taken') : t(errorKey(e)));
      if (e instanceof Error && e.message === 'slot_taken') setService({ ...service });
    } finally {
      setBusy(false);
    }
  };

  const chosen = day && time ? parseLocal(`${day} ${time}`) : null;

  return (
    <Screen
      header={<Header title={t('bk_title')} sub={booking.dietitian} />}
      footer={service && day && time ? <Button title={card ? t('bk_book_pay', { price: fmtMoney(service.price_cents, booking.currency) }) : t('bk_book')} onPress={confirm} loading={busy} /> : undefined}
    >
      {!!error && <Notice tone="error" title={error} />}
      <Label>{t('bk_what')}</Label>
      {!booking.services.length && <Muted>{t('bk_no_services')}</Muted>}
      <Card style={{ paddingVertical: 0 }}>
        {booking.services.map((s, i) => {
          const on = service?.id === s.id;
          return (
            <Pressable
              key={s.id}
              accessibilityRole="radio"
              accessibilityState={{ checked: on }}
              onPress={() => setService(s)}
              style={{ minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: i < booking.services.length - 1 ? 1 : 0, borderBottomColor: C.soft }}
            >
              <View style={{ width: 22, height: 22, borderRadius: 11, borderWidth: on ? 7 : 2, borderColor: on ? C.accent : C.faint }} />
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={{ fontSize: 16, fontWeight: on ? '700' : '600', color: C.ink }}>{name(s)}</Text>
                <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
                  <Muted>{t('ap_minutes', { n: s.minutes })}</Muted>
                  {s.video && <Tag text={t('ap_video')} bg={C.lowBg} color={C.lowInk} />}
                </View>
              </View>
              <Text style={{ fontSize: 15, fontWeight: '700', color: C.ink }}>{s.price_cents > 0 ? fmtMoney(s.price_cents, booking.currency) : t('bk_free')}</Text>
            </Pressable>
          );
        })}
      </Card>

      {service && (
        <>
          <Label>{t('bk_when')}</Label>
          {days === null && <ActivityIndicator color={C.accent} />}
          {days && !days.length && <Muted>{t('bk_no_slots')}</Muted>}
          {days && days.length > 0 && (
            <>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
                {days.map((d) => {
                  const dt = parseLocal(d.date);
                  return (
                    <Chip
                      key={d.date}
                      label={dt ? fmtWeekday(dt) : d.date}
                      on={day === d.date}
                      onPress={() => {
                        setDay(d.date);
                        setTime(null);
                      }}
                    />
                  );
                })}
              </ScrollView>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                {(days.find((d) => d.date === day)?.times ?? []).map((tm) => (
                  <Chip key={tm} label={tm} on={time === tm} onPress={() => setTime(tm)} />
                ))}
              </View>
            </>
          )}
        </>
      )}

      {service && chosen && (
        <Card style={{ gap: 6 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Icon name="calendar" color={C.accent} />
            <Text style={{ flex: 1, fontSize: 15, fontWeight: '700', color: C.ink }}>{`${fmtLong(chosen)}, ${time}`}</Text>
          </View>
          <Muted>{service.video ? t('bk_video_note') : t('bk_office_note')}</Muted>
          {service.price_cents > 0 && <Muted>{card ? t('bk_card_note') : t('bk_pay_office')}</Muted>}
        </Card>
      )}
    </Screen>
  );
}
