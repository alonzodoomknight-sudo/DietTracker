// 23 Shopping list: everything in the week's plan, added up, with ticks
import React from 'react';
import { Pressable, Text, View } from 'react-native';
import { Button, Card, Header, Icon, Muted, Screen } from '../src/ui';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { setPrefs, useStore } from '../src/store';
import { fmtNum } from '../src/format';

// "150 γρ. Κοτόπουλο ψητό" and "Κοτόπουλο ψητό 150g" are the same food.
const keyOf = (text: string) =>
  text
    .toLocaleLowerCase()
    .replace(/\d+([.,]\d+)?\s*(g|gr|γρ|γραμμάρια|ml|κ\.σ\.|κ\.γ\.)?\.?/g, ' ')
    .replace(/[(),.:;]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

export default function Shopping() {
  useLang();
  const plan = useStore((s) => s.sync.plan);
  const done = useStore((s) => s.prefs.shopDone);

  const list = new Map<string, { name: string; grams: number; times: number }>();
  for (const day of plan?.days ?? []) {
    for (const meal of day.meals) {
      for (const it of meal.items) {
        const k = keyOf(it.text);
        if (!k) continue;
        const row = list.get(k) ?? { name: k.charAt(0).toLocaleUpperCase() + k.slice(1), grams: 0, times: 0 };
        row.grams += typeof it.grams === 'number' ? it.grams : 0;
        row.times += 1;
        list.set(k, row);
      }
    }
  }
  const rows = [...list.entries()].sort((a, b) => a[1].name.localeCompare(b[1].name));
  const id = (k: string) => `${plan?.id ?? 0}|${k}`;
  const toggle = (k: string) => setPrefs({ shopDone: done.includes(id(k)) ? done.filter((x) => x !== id(k)) : [...done, id(k)] });
  const left = rows.filter(([k]) => !done.includes(id(k))).length;

  return (
    <Screen header={<Header title={t('sl_title')} sub={rows.length ? t('sl_left', { a: left, b: rows.length }) : undefined} />}>
      {!rows.length && <Muted>{t('sl_empty')}</Muted>}
      {rows.length > 0 && (
        <Card style={{ paddingVertical: 0 }}>
          {rows.map(([k, r], i) => {
            const on = done.includes(id(k));
            return (
              <Pressable
                key={k}
                accessibilityRole="checkbox"
                accessibilityState={{ checked: on }}
                onPress={() => toggle(k)}
                style={{ minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: i < rows.length - 1 ? 1 : 0, borderBottomColor: C.soft }}
              >
                <View style={{ width: 24, height: 24, borderRadius: 6, borderWidth: 2, borderColor: on ? C.accent : C.faint, backgroundColor: on ? C.accent : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
                  {on && <Icon name="check" size={16} color="#FFFFFF" width={3} />}
                </View>
                <Text style={{ flex: 1, fontSize: 15, color: on ? C.faint : C.ink, textDecorationLine: on ? 'line-through' : 'none' }}>{r.name}</Text>
                <Muted>{r.grams > 0 ? `${fmtNum(r.grams, 0)} g` : `×${r.times}`}</Muted>
              </Pressable>
            );
          })}
        </Card>
      )}
      {done.some((d) => d.startsWith(`${plan?.id ?? 0}|`)) && (
        <Button title={t('sl_clear')} kind="secondary" onPress={() => setPrefs({ shopDone: done.filter((d) => !d.startsWith(`${plan?.id ?? 0}|`)) })} />
      )}
      <Muted>{t('sl_note')}</Muted>
    </Screen>
  );
}
