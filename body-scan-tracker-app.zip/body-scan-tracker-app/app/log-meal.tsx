// 14 Log a meal: as planned, or pick foods (grams → kcal), with an optional photo
import React, { useEffect, useMemo, useState } from 'react';
import { Image, Pressable, Text, TextInput, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { Button, Card, Field, Header, Icon, Label, Muted, Notice, Screen, WELL } from '../src/ui';
import { C } from '../src/theme';
import { lang, t, useLang } from '../src/i18n';
import { itemsKcal, loadFoods, logMeal, planDay, useStore } from '../src/store';
import { Food, PlanItem, errorKey } from '../src/api';
import { Chip, Items, mealName } from '../src/meals';
import { fmtNum, parseLocal, parseNum, toDateOnly } from '../src/format';

type Row = { text: string; grams: string; food: Food | null };

const kcalOf = (r: Row) => {
  const g = parseNum(r.grams);
  return r.food && g !== null && !Number.isNaN(g) ? Math.round((r.food.kcal * g) / 100) : null;
};

export default function LogMeal() {
  useLang();
  const params = useLocalSearchParams<{ meal?: string; date?: string }>();
  const plan = useStore((s) => s.sync.plan);
  const foods = useStore((s) => s.foods);
  const [meal, setMeal] = useState(() => {
    const n = Number(params.meal);
    if (n >= 0 && n <= 4) return n;
    const h = new Date().getHours();
    return h < 10 ? 0 : h < 12 ? 1 : h < 16 ? 2 : h < 19 ? 3 : 4;
  });
  const date = params.date && /^\d{4}-\d{2}-\d{2}$/.test(params.date) ? params.date : toDateOnly(new Date());
  const [rows, setRows] = useState<Row[]>([]);
  const [search, setSearch] = useState('');
  const [photo, setPhoto] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadFoods();
  }, []);

  const planned = planDay(plan, parseLocal(date) ?? new Date())[meal]?.items ?? [];
  const name = (f: Food) => (lang() === 'el' ? f.el : f.en) || f.el || f.en;

  const matches = useMemo(() => {
    const q = search.trim().toLocaleLowerCase();
    if (q.length < 2) return [];
    return foods.filter((f) => f.el.toLocaleLowerCase().includes(q) || f.en.toLocaleLowerCase().includes(q)).slice(0, 8);
  }, [search, foods]);

  const add = (f: Food | null) => {
    setRows((r) => [...r, { text: f ? name(f) : search.trim(), grams: f ? String(f.piece ?? 100) : '', food: f }]);
    setSearch('');
  };

  const takePhoto = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) return;
    const res = await ImagePicker.launchCameraAsync({ quality: 0.6 });
    if (!res.canceled && res.assets?.[0]) setPhoto(res.assets[0].uri);
  };

  const save = async (fromPlan: boolean) => {
    setError('');
    const items: PlanItem[] = fromPlan
      ? planned
      : rows
          .filter((r) => r.text.trim())
          .map((r) => {
            const g = parseNum(r.grams);
            return { text: r.text.trim(), grams: g !== null && !Number.isNaN(g) ? g : null, kcal: kcalOf(r), food_id: r.food?.id ?? null };
          });
    if (!items.length && !photo) {
      setError(t('lm_need_one'));
      return;
    }
    setBusy(true);
    try {
      await logMeal({ date, meal, items, kcal: itemsKcal(items), from_plan: fromPlan }, photo);
      router.back();
    } catch (e) {
      setError(t(errorKey(e)));
    } finally {
      setBusy(false);
    }
  };

  const total = rows.reduce((n, r) => n + (kcalOf(r) ?? 0), 0);

  return (
    <Screen header={<Header title={t('lm_title')} />} footer={<Button title={t('lm_save')} onPress={() => save(false)} loading={busy} />}>
      {!!error && <Notice tone="error" title={error} />}
      <Label>{t('lm_which')}</Label>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {[0, 1, 2, 3, 4].map((i) => (
          <Chip key={i} label={mealName(i)} on={meal === i} onPress={() => setMeal(i)} />
        ))}
      </View>

      {planned.length > 0 && (
        <Card style={{ gap: 10 }}>
          <Text style={{ fontSize: 15, fontWeight: '700', color: C.ink }}>{t('lm_plan')}</Text>
          <Items items={planned} />
          <Button title={t('lm_as_planned')} icon="check" onPress={() => save(true)} loading={busy} />
        </Card>
      )}

      <Label>{planned.length ? t('lm_or_add') : t('lm_add')}</Label>
      <Field label={t('lm_search')} value={search} onChangeText={setSearch} keyboardType="default" autoCapitalize="sentences" placeholder={t('lm_search_ph')} />
      {search.trim().length >= 2 && (
        <Card style={{ paddingVertical: 0 }}>
          {matches.map((f) => (
            <Pressable key={f.id} accessibilityRole="button" onPress={() => add(f)} style={{ minHeight: 52, flexDirection: 'row', alignItems: 'center', gap: 10, borderBottomWidth: 1, borderBottomColor: C.soft }}>
              <Text style={{ flex: 1, fontSize: 15, color: C.ink }}>{name(f)}</Text>
              <Muted>{t('lm_per100', { n: Math.round(f.kcal) })}</Muted>
              <Icon name="plus" size={18} color={C.accent} />
            </Pressable>
          ))}
          <Pressable accessibilityRole="button" onPress={() => add(null)} style={{ minHeight: 52, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Text style={{ flex: 1, fontSize: 15, color: C.accent, fontWeight: '600' }}>{t('lm_add_text', { text: search.trim() })}</Text>
            <Icon name="plus" size={18} color={C.accent} />
          </Pressable>
        </Card>
      )}

      {rows.length > 0 && (
        <Card style={{ gap: 12 }}>
          {rows.map((r, i) => (
            <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ flex: 1, fontSize: 15, color: C.ink }}>{r.text}</Text>
              <View style={[{ width: 86, height: 44, borderRadius: 12, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10 }, WELL]}>
                <TextInput
                  accessibilityLabel={t('lm_grams', { name: r.text })}
                  value={r.grams}
                  onChangeText={(g) => setRows((all) => all.map((x, k) => (k === i ? { ...x, grams: g } : x)))}
                  keyboardType="decimal-pad"
                  style={{ flex: 1, fontSize: 15, color: C.ink, paddingVertical: 0 }}
                />
                <Text style={{ color: C.muted }}>g</Text>
              </View>
              <Text style={{ width: 64, textAlign: 'right', color: C.muted }}>{kcalOf(r) !== null ? `${kcalOf(r)} kcal` : ''}</Text>
              <Pressable accessibilityRole="button" accessibilityLabel={t('delete')} onPress={() => setRows((all) => all.filter((_, k) => k !== i))} style={{ width: 36, height: 44, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="close" size={18} color={C.muted} />
              </Pressable>
            </View>
          ))}
          {total > 0 && <Text style={{ fontSize: 15, fontWeight: '700', color: C.ink, textAlign: 'right' }}>{t('lm_total', { n: fmtNum(total, 0) })}</Text>}
        </Card>
      )}

      {photo ? (
        <Card style={{ padding: 8, gap: 8 }}>
          <Image source={{ uri: photo }} style={{ width: '100%', height: 200, borderRadius: 12 }} resizeMode="cover" accessibilityIgnoresInvertColors />
          <Button title={t('lm_photo_remove')} kind="secondary" onPress={() => setPhoto(null)} />
        </Card>
      ) : (
        <Button title={t('lm_photo')} icon="camera" kind="secondary" onPress={takePhoto} />
      )}
      <Muted>{t('lm_photo_note')}</Muted>
    </Screen>
  );
}
