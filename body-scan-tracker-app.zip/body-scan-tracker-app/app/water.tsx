// 15 Water: glasses today, daily goal, the last 7 days
import React, { useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { Card, DARK_RIM, Grad, GRADS, Header, Icon, Label, Muted, RIM, SHADOW, Screen, Segmented } from '../src/ui';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { setPrefs, setWater, useStore } from '../src/store';
import { errorKey } from '../src/api';
import { ProgressBar, todayStr } from '../src/meals';
import { addDays, fmtNum, fmtWeekday, toDateOnly } from '../src/format';

const GOALS = ['1500', '2000', '2500', '3000'] as const;
const GLASSES = ['200', '250', '330', '500'] as const;

export default function Water() {
  useLang();
  const water = useStore((s) => s.sync.water);
  const prefs = useStore((s) => s.prefs);
  const [saving, setSaving] = useState(false);
  const today = todayStr();
  const ml = water[today] ?? 0;

  const change = async (delta: number) => {
    if (saving) return;
    setSaving(true);
    try {
      await setWater(today, Math.max(0, ml + delta));
    } catch (e) {
      Alert.alert(t(errorKey(e)));
    } finally {
      setSaving(false);
    }
  };

  const days = [6, 5, 4, 3, 2, 1, 0].map((n) => addDays(new Date(), -n));
  const max = Math.max(prefs.waterGoal, ...days.map((d) => water[toDateOnly(d)] ?? 0));
  const glasses = Math.ceil(prefs.waterGoal / prefs.glass);
  const full = Math.floor(ml / prefs.glass);

  return (
    <Screen header={<Header title={t('wa_title')} />}>
      <Card style={{ alignItems: 'center', gap: 10, paddingVertical: 22 }}>
        <Text style={{ fontSize: 40, fontWeight: '800', color: C.ink }}>{fmtNum(ml / 1000, 2)} L</Text>
        <Muted>{t('wa_of', { n: fmtNum(prefs.waterGoal / 1000, 1) })}</Muted>
        <View style={{ alignSelf: 'stretch' }}>
          <ProgressBar value={ml} max={prefs.waterGoal} color="#2E7FD1" />
        </View>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 6, marginTop: 4 }}>
          {Array.from({ length: Math.min(glasses, 16) }, (_, i) => (
            <Icon key={i} name="drop" size={24} color={i < full ? '#2E7FD1' : C.line} />
          ))}
        </View>
        <View style={{ flexDirection: 'row', gap: 16, marginTop: 6 }}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t('wa_less', { n: prefs.glass })}
            onPress={() => change(-prefs.glass)}
            style={[{ width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center', boxShadow: SHADOW.soft } as any, RIM]}
          >
            <Grad colors={GRADS.secondary} radius={32} />
            <Icon name="minus" />
          </Pressable>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={t('wa_more', { n: prefs.glass })}
            onPress={() => change(prefs.glass)}
            style={[{ width: 64, height: 64, borderRadius: 32, backgroundColor: '#2E7FD1', alignItems: 'center', justifyContent: 'center', boxShadow: SHADOW.blue } as any, DARK_RIM]}
          >
            <Grad colors={GRADS.water} radius={32} />
            <Icon name="plus" color="#FFFFFF" />
          </Pressable>
        </View>
        <Muted>{t('wa_glass', { n: prefs.glass })}</Muted>
      </Card>

      <Label>{t('wa_week')}</Label>
      <Card style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 8, height: 170 }}>
        {days.map((d) => {
          const v = water[toDateOnly(d)] ?? 0;
          return (
            <View key={d.toDateString()} style={{ flex: 1, alignItems: 'center', gap: 4 }} accessible accessibilityLabel={`${fmtWeekday(d)}: ${v} ml`}>
              <View style={{ width: '70%', height: Math.max(3, (v / max) * 110), borderRadius: 6, backgroundColor: v >= prefs.waterGoal ? '#2E7FD1' : '#A9CBEF' }} />
              <Text style={{ fontSize: 11, color: C.muted }}>{fmtWeekday(d).split(' ')[0]}</Text>
            </View>
          );
        })}
      </Card>

      <Label>{t('wa_goal')}</Label>
      <Segmented label={t('wa_goal')} value={String(prefs.waterGoal) as any} onChange={(v) => setPrefs({ waterGoal: Number(v) })} options={GOALS.map((g) => ({ value: g, label: `${fmtNum(Number(g) / 1000, 1)} L` }))} />
      <Label>{t('wa_glass_size')}</Label>
      <Segmented label={t('wa_glass_size')} value={String(prefs.glass) as any} onChange={(v) => setPrefs({ glass: Number(v) })} options={GLASSES.map((g) => ({ value: g, label: `${g} ml` }))} />
    </Screen>
  );
}
