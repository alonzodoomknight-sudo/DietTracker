// Snap your meal plan: photos or a PDF of a paper plan (7 days × 5 meals + notes) are read and can be corrected
import React, { useState } from 'react';
import { ActivityIndicator, Alert, Image, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import DocumentScanner from 'react-native-document-scanner-plugin';
import { Button, Card, Field, Header, Label, Muted, Notice, Screen, WELL } from '../src/ui';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { pdfToPages, savePaperPlan } from '../src/store';
import { PlanItem, errorKey } from '../src/api';
import { readPage } from '../src/ocr';
import { OcrLine } from '../src/reader';
import { MEAL_COUNT, PlanDay, emptyDays, parsePlan } from '../src/planReader';
import { writeBase64Jpeg } from '../src/files';
import { Chip, mealName } from '../src/meals';
import { parseNum, planDayName } from '../src/format';

type Cell = { items: string; note: string };
const MAX_PAGES = 6;

const toCells = (days: PlanDay[]): Cell[][] => days.map((d) => d.meals.map((m) => ({ items: m.items.map((i) => i.text).join('\n'), note: m.note ?? '' })));

// One food per line; "150 γρ" / "150g" is kept as grams.
const toItems = (text: string): PlanItem[] =>
  text
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => {
      const m = /(\d+(?:[.,]\d+)?)\s*(g|gr|γρ|γραμ)/i.exec(l);
      const g = m ? parseNum(m[1]) : null;
      return { text: l, grams: g !== null && !Number.isNaN(g) ? g : null, kcal: null, food_id: null };
    });

export default function PlanSnap() {
  useLang();
  const [pages, setPages] = useState<string[]>([]);
  const [step, setStep] = useState<'pick' | 'reading' | 'edit'>('pick');
  const [progress, setProgress] = useState('');
  const [cells, setCells] = useState<Cell[][]>(() => toCells(emptyDays()));
  const [found, setFound] = useState(true);
  const [day, setDay] = useState(0);
  const [name, setName] = useState('');
  const [times, setTimes] = useState<string[]>(['08:00', '11:00', '14:00', '17:00', '20:30']);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const addPages = (uris: string[]) => setPages((p) => [...p, ...uris].slice(0, MAX_PAGES));

  const autoScan = async () => {
    try {
      const res = await DocumentScanner.scanDocument({ maxNumDocuments: MAX_PAGES - pages.length, croppedImageQuality: 90 });
      addPages(res?.scannedImages ?? []);
    } catch {
      Alert.alert(t('s_auto_failed'));
    }
  };
  const photo = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) return;
    const res = await ImagePicker.launchCameraAsync({ quality: 0.85 });
    if (!res.canceled) addPages(res.assets.map((a) => a.uri));
  };
  const library = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsMultipleSelection: true, selectionLimit: MAX_PAGES - pages.length, quality: 0.85 });
    if (!res.canceled) addPages(res.assets.map((a) => a.uri));
  };
  const pdf = async () => {
    const res = await DocumentPicker.getDocumentAsync({ type: ['application/pdf', 'image/*'], copyToCacheDirectory: true });
    if (res.canceled || !res.assets?.length) return;
    const file = res.assets[0];
    if (!(file.mimeType === 'application/pdf' || file.name?.toLowerCase().endsWith('.pdf'))) {
      addPages([file.uri]);
      return;
    }
    setProgress(t('s_opening_pdf'));
    try {
      const jpgs = await pdfToPages(file.uri, file.name ?? 'plan.pdf');
      const stamp = Date.now();
      const uris: string[] = [];
      for (let i = 0; i < jpgs.length; i++) uris.push((await writeBase64Jpeg(`plan-${stamp}-${i + 1}.jpg`, jpgs[i])).uri);
      addPages(uris);
    } catch (e) {
      Alert.alert(t('s_pdf_failed'), t(errorKey(e)));
    } finally {
      setProgress('');
    }
  };

  const read = async () => {
    setStep('reading');
    const lines: OcrLine[] = [];
    for (let i = 0; i < pages.length; i++) {
      setProgress(t('rd_page', { a: i + 1, b: pages.length }));
      try {
        lines.push(...(await readPage(pages[i], i + 1)));
      } catch {
        // skip a page that can't be read; it can be typed in
      }
    }
    const days = lines.length ? parsePlan(lines) : null;
    setFound(!!days);
    setCells(toCells(days ?? emptyDays()));
    setProgress('');
    setStep('edit');
  };

  const setCell = (m: number, patch: Partial<Cell>) => setCells((all) => all.map((d, di) => (di === day ? d.map((c, mi) => (mi === m ? { ...c, ...patch } : c)) : d)));

  const save = async () => {
    setBusy(true);
    setError('');
    try {
      const days = cells.map((d) => ({ meals: d.map((c) => ({ items: toItems(c.items), note: c.note.trim() })) }));
      await savePaperPlan(days, times.map((x) => (/^\d{1,2}:\d{2}$/.test(x.trim()) ? x.trim() : '')), name.trim());
      router.replace('/plan');
    } catch (e) {
      setError(t(errorKey(e)));
    } finally {
      setBusy(false);
    }
  };

  if (step === 'reading') {
    return (
      <Screen header={<Header title={t('ps_title')} back={false} />}>
        <View style={{ alignItems: 'center', gap: 14, paddingTop: 40 }}>
          <ActivityIndicator color={C.accent} size="large" />
          <Text style={{ fontSize: 17, fontWeight: '700', color: C.ink }}>{t('ps_reading')}</Text>
          {!!progress && <Muted>{progress}</Muted>}
        </View>
      </Screen>
    );
  }

  if (step === 'edit') {
    return (
      <Screen header={<Header title={t('ps_check')} />} footer={<Button title={t('ps_save')} onPress={save} loading={busy} />}>
        {!!error && <Notice tone="error" title={error} />}
        {found ? <Notice tone="info" title={t('ps_found')} body={t('ps_found_body')} /> : <Notice title={t('ps_not_found')} body={t('ps_not_found_body')} />}
        <Field label={t('ps_name')} value={name} onChangeText={setName} keyboardType="default" autoCapitalize="sentences" maxLength={120} />
        <Label>{t('ps_times')}</Label>
        <Card style={{ gap: 8 }}>
          {times.map((tm, i) => (
            <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <Text style={{ flex: 1, fontSize: 15, color: C.ink }}>{mealName(i)}</Text>
              <TextInput
                accessibilityLabel={t('ps_time_of', { meal: mealName(i) })}
                value={tm}
                onChangeText={(s) => setTimes((all) => all.map((x, k) => (k === i ? s : x)))}
                keyboardType="numbers-and-punctuation"
                maxLength={5}
                style={[{ width: 84, height: 44, borderRadius: 12, textAlign: 'center', fontSize: 15, color: C.ink }, WELL]}
              />
            </View>
          ))}
        </Card>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
          {[0, 1, 2, 3, 4, 5, 6].map((i) => (
            <Chip key={i} label={planDayName(i)} on={day === i} onPress={() => setDay(i)} />
          ))}
        </ScrollView>
        {Array.from({ length: MEAL_COUNT }, (_, m) => (
          <Card key={`${day}-${m}`} style={{ gap: 8 }}>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.ink }}>{mealName(m)}</Text>
            <TextInput
              accessibilityLabel={t('ps_foods_of', { meal: mealName(m) })}
              value={cells[day][m].items}
              onChangeText={(s) => setCell(m, { items: s })}
              multiline
              placeholder={t('ps_foods_ph')}
              placeholderTextColor={C.faint}
              style={[{ minHeight: 70, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: C.ink, textAlignVertical: 'top' }, WELL]}
            />
            <TextInput
              accessibilityLabel={t('pl_notes')}
              value={cells[day][m].note}
              onChangeText={(s) => setCell(m, { note: s })}
              multiline
              placeholder={t('pl_notes')}
              placeholderTextColor={C.faint}
              style={{ minHeight: 44, borderRadius: 10, borderWidth: 1.5, borderColor: C.warnLine, backgroundColor: C.warnBg, padding: 10, fontSize: 14, color: C.warnInk, textAlignVertical: 'top' }}
            />
          </Card>
        ))}
        <Muted>{t('ps_one_per_line')}</Muted>
      </Screen>
    );
  }

  return (
    <Screen
      header={<Header title={t('ps_title')} />}
      footer={
        <>
          <Button title={t('ps_read')} onPress={read} disabled={!pages.length} />
          <Button title={t('ps_type')} kind="secondary" onPress={() => setStep('edit')} />
        </>
      }
    >
      <Muted>{t('ps_body')}</Muted>
      <Button title={t('s_auto')} icon="scan" onPress={autoScan} disabled={pages.length >= MAX_PAGES} />
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Button title={t('s_take_photo')} icon="camera" kind="secondary" onPress={photo} disabled={pages.length >= MAX_PAGES} style={{ flex: 1 }} />
        <Button title={t('s_upload')} icon="upload" kind="secondary" onPress={library} disabled={pages.length >= MAX_PAGES} style={{ flex: 1 }} />
      </View>
      <Button title={t('s_pdf')} icon="file" kind="secondary" onPress={pdf} disabled={pages.length >= MAX_PAGES} loading={!!progress} />
      {pages.length > 0 && (
        <>
          <Label>{t('ps_pages', { n: pages.length })}</Label>
          <ScrollView horizontal contentContainerStyle={{ gap: 10 }}>
            {pages.map((uri, i) => (
              <Pressable
                key={uri + i}
                accessibilityRole="button"
                accessibilityLabel={t('s_page', { n: i + 1 })}
                onPress={() =>
                  Alert.alert(t('s_page', { n: i + 1 }), undefined, [
                    { text: t('delete'), style: 'destructive', onPress: () => setPages((p) => p.filter((_, k) => k !== i)) },
                    { text: t('cancel'), style: 'cancel' },
                  ])
                }
              >
                <Image source={{ uri }} style={{ width: 90, height: 120, borderRadius: 10, borderWidth: 1, borderColor: C.line }} />
              </Pressable>
            ))}
          </ScrollView>
        </>
      )}
      <Muted>{t('ps_greek_note')}</Muted>
    </Screen>
  );
}
