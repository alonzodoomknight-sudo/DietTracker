// 12 Settings
import React, { useCallback, useState } from 'react';
import { Alert, Modal, Pressable, Switch, Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button, Card, ChoiceModal, Field, Header, Label, Muted, Notice, Row, Screen, Segmented } from '../src/ui';
import { usePicker } from '../src/datetime';
import { C } from '../src/theme';
import { LangSetting, t, useLang } from '../src/i18n';
import { Every, deleteAllData, disconnectDietitian, refresh, setPrefs, updateMe, useStore } from '../src/store';
import { askNotificationPermission } from '../src/reminders';
import { exportPdf, exportSpreadsheet } from '../src/files';
import { errorKey } from '../src/api';
import { ageFrom, convert, fmtDayMonthYear, fmtNum, fmtTime, fmtWeekday, parseLocal, parseNum, toDateOnly, toLocal } from '../src/format';

const EVERY: { value: string; key: 'r_2w' | 'r_1m' | 'r_2m' | 'r_unsure' }[] = [
  { value: '2w', key: 'r_2w' },
  { value: '1m', key: 'r_1m' },
  { value: '2m', key: 'r_2m' },
  { value: 'none', key: 'r_unsure' },
];

function EditNumber({ title, value, onSave, onClose, keyboard = 'decimal-pad' }: { title: string; value: string; onSave: (v: string) => void; onClose: () => void; keyboard?: 'decimal-pad' | 'number-pad' }) {
  const [text, setText] = useState(value);
  const insets = useSafeAreaInsets();
  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <Pressable accessibilityLabel={t('cancel')} onPress={onClose} style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.35)' }} />
      <View style={{ backgroundColor: C.card, borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 20, paddingBottom: insets.bottom + 16, gap: 14 }}>
        <Field label={title} value={text} onChangeText={setText} keyboardType={keyboard} />
        <Button
          title={t('save')}
          onPress={() => {
            onSave(text);
            onClose();
          }}
        />
      </View>
    </Modal>
  );
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (on: boolean) => void }) {
  return (
    <View style={{ minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 12, borderTopWidth: 1, borderTopColor: C.soft }}>
      <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: C.ink }}>{label}</Text>
      <Switch
        accessibilityLabel={label}
        value={value}
        onValueChange={async (on) => {
          if (on) await askNotificationPermission();
          onChange(on);
        }}
        trackColor={{ true: C.accent, false: '#C8D1DB' }}
        thumbColor="#FFFFFF"
      />
    </View>
  );
}

export default function Settings() {
  useLang();
  const me = useStore((s) => s.me);
  const prefs = useStore((s) => s.prefs);
  const scans = useStore((s) => s.scans);
  const picker = usePicker();
  const [modal, setModal] = useState<'height' | 'age' | 'sex' | 'every' | 'lang' | null>(null);
  const [error, setError] = useState('');
  const units = { weight: prefs.weight, length: prefs.length };

  useFocusEffect(
    useCallback(() => {
      refresh().catch(() => undefined);
    }, []),
  );

  const run = async (fn: () => Promise<unknown>) => {
    setError('');
    try {
      await fn();
    } catch (e) {
      setError(t(errorKey(e)));
    }
  };

  const birth = parseLocal(me?.birth_date);
  const height = me?.height_cm ?? null;
  const heightText = height !== null ? (() => {
    const c = convert('cm', height, units);
    return `${fmtNum(c.value, c.unit === 'in' ? 1 : 0)} ${c.unit}`;
  })() : t('not_set');
  const next = parseLocal(prefs.nextScan);

  const pickNext = () => {
    const base = next ?? (() => {
      const d = new Date();
      d.setDate(d.getDate() + 7);
      d.setHours(9, 30, 0, 0);
      return d;
    })();
    picker.open('date', base, (d) => {
      const chosen = new Date(d);
      chosen.setHours(base.getHours(), base.getMinutes(), 0, 0);
      setTimeout(
        () =>
          picker.open('time', chosen, (tm) => {
            const final = new Date(chosen);
            final.setHours(tm.getHours(), tm.getMinutes(), 0, 0);
            setPrefs({ nextScan: toLocal(final) });
          }),
        350,
      );
      setPrefs({ nextScan: toLocal(chosen) });
    });
  };

  const dietitian = me?.dietitian;

  return (
    <Screen header={<Header title={t('settings')} />}>
      {!!error && <Notice tone="error" title={error} />}

      <Label>{t('st_about')}</Label>
      <Card style={{ paddingVertical: 0 }}>
        <Row label={t('st_height')} value={heightText} onPress={() => setModal('height')} />
        <Row
          label={birth ? t('st_birth') : t('st_age')}
          value={birth ? `${fmtDayMonthYear(birth)} · ${ageFrom(birth)}` : me?.age ? String(me.age) : t('not_set')}
          onPress={() => (birth ? picker.open('date', birth, (d) => run(() => updateMe({ birth_date: toDateOnly(d) })), new Date()) : setModal('age'))}
        />
        <Row label={t('st_sex')} value={me?.sex ? t(me.sex) : t('not_set')} onPress={() => setModal('sex')} last />
      </Card>
      <Muted>{t('st_about_note')}</Muted>

      <Label>{t('st_units')}</Label>
      <Card style={{ gap: 12 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: C.ink }}>{t('st_weight')}</Text>
          <View style={{ width: 150 }}>
            <Segmented label={t('st_weight')} value={prefs.weight} onChange={(v) => setPrefs({ weight: v })} options={[{ value: 'kg', label: 'kg' }, { value: 'lb', label: 'lb' }]} />
          </View>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: C.ink }}>{t('st_length')}</Text>
          <View style={{ width: 150 }}>
            <Segmented label={t('st_length')} value={prefs.length} onChange={(v) => setPrefs({ length: v })} options={[{ value: 'cm', label: 'cm' }, { value: 'in', label: 'in' }]} />
          </View>
        </View>
      </Card>

      <Label>{t('st_reminders')}</Label>
      <Card style={{ paddingVertical: 0 }}>
        <Row label={t('st_how')} value={t(EVERY.find((e) => e.value === (prefs.every ?? 'none'))?.key ?? 'r_unsure')} onPress={() => setModal('every')} />
        <Row label={t('st_next')} value={next ? `${fmtWeekday(next)}, ${fmtTime(next)}` : t('not_set')} onPress={pickNext} />
        <View style={{ minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: C.ink }}>{t('st_remind')}</Text>
          <Switch
            accessibilityLabel={t('st_remind')}
            value={prefs.remind}
            onValueChange={async (on) => {
              if (on) await askNotificationPermission();
              setPrefs({ remind: on });
            }}
            trackColor={{ true: C.accent, false: '#C8D1DB' }}
            thumbColor="#FFFFFF"
          />
        </View>
        <Toggle label={t('st_remind_appts')} value={prefs.remindAppts} onChange={(on) => setPrefs({ remindAppts: on })} />
        <Toggle label={t('st_remind_meals')} value={prefs.remindMeals} onChange={(on) => setPrefs({ remindMeals: on })} />
        <Toggle label={t('st_remind_water')} value={prefs.remindWater} onChange={(on) => setPrefs({ remindWater: on })} />
      </Card>

      <Label>{t('st_dietitian')}</Label>
      <Card style={{ paddingVertical: dietitian ? 14 : 0, gap: 10 }}>
        {dietitian ? (
          <>
            <Text style={{ fontSize: 15, fontWeight: '600', color: C.ink }}>
              {dietitian.status === 'accepted' ? t('st_connected', { name: dietitian.name }) : t('st_pending', { name: dietitian.name })}
            </Text>
            <Button
              title={t('st_disconnect')}
              kind="danger"
              onPress={() =>
                Alert.alert(t('st_disconnect_q', { name: dietitian.name }), t('st_disconnect_body'), [
                  { text: t('cancel'), style: 'cancel' },
                  { text: t('st_disconnect'), style: 'destructive', onPress: () => run(disconnectDietitian) },
                ])
              }
            />
          </>
        ) : (
          <Row label={t('st_connect')} onPress={() => router.push('/connect')} last />
        )}
      </Card>

      <Label>{t('st_language')}</Label>
      <Card style={{ paddingVertical: 0 }}>
        <Row
          label={t('st_language')}
          value={prefs.language === 'el' ? 'Ελληνικά' : prefs.language === 'en' ? 'English' : t('lang_auto')}
          onPress={() => setModal('lang')}
          last
        />
      </Card>

      <Label>{t('st_export')}</Label>
      <Card style={{ paddingVertical: 0 }}>
        <Row label={t('st_csv')} onPress={() => scans.length && run(() => exportSpreadsheet(scans))} />
        <Row label={t('st_pdf')} onPress={() => scans.length && run(() => exportPdf(scans, units))} last />
      </Card>

      <View style={{ height: 8 }} />
      <Button
        title={t('st_delete')}
        kind="danger"
        onPress={() =>
          Alert.alert(t('st_delete_q'), t('st_delete_body'), [
            { text: t('cancel'), style: 'cancel' },
            {
              text: t('delete'),
              style: 'destructive',
              onPress: () =>
                run(async () => {
                  await deleteAllData();
                  if (router.canDismiss()) router.dismissAll();
                  router.replace('/welcome');
                }),
            },
          ])
        }
      />
      <Muted>{t('st_delete_body')}</Muted>

      {modal === 'height' && (
        <EditNumber
          title={t('st_edit_height')}
          value={height !== null ? String(height) : ''}
          onClose={() => setModal(null)}
          onSave={(s) => {
            const n = parseNum(s);
            if (n !== null && !Number.isNaN(n)) run(() => updateMe({ height_cm: n }));
          }}
        />
      )}
      {modal === 'age' && (
        <EditNumber
          title={t('st_edit_age')}
          keyboard="number-pad"
          value={me?.age ? String(me.age) : ''}
          onClose={() => setModal(null)}
          onSave={(s) => {
            const n = parseInt(s, 10);
            if (!Number.isNaN(n)) run(() => updateMe({ age: n }));
          }}
        />
      )}
      <ChoiceModal
        visible={modal === 'sex'}
        title={t('st_sex')}
        value={me?.sex ?? null}
        onClose={() => setModal(null)}
        onPick={(v) => run(() => updateMe({ sex: v }))}
        options={[
          { value: 'male' as const, label: t('male') },
          { value: 'female' as const, label: t('female') },
        ]}
      />
      <ChoiceModal
        visible={modal === 'every'}
        title={t('st_how')}
        value={prefs.every ?? 'none'}
        onClose={() => setModal(null)}
        onPick={(v) => setPrefs({ every: v === 'none' ? null : (v as Every) })}
        options={EVERY.map((e) => ({ value: e.value, label: t(e.key) }))}
      />
      <ChoiceModal
        visible={modal === 'lang'}
        title={t('st_language')}
        value={prefs.language}
        onClose={() => setModal(null)}
        onPick={(v) => setPrefs({ language: v as LangSetting })}
        options={[
          { value: 'auto', label: t('lang_auto') },
          { value: 'el', label: 'Ελληνικά' },
          { value: 'en', label: 'English' },
        ]}
      />
      {picker.element}
    </Screen>
  );
}
