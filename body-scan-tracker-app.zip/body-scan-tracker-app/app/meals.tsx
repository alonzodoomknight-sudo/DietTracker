// 22 Today's meals: what the plan says and what was eaten, meal by meal
import React, { useCallback, useState } from 'react';
import { Alert, Image, Pressable, Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Button, Card, Header, Icon, Muted, Screen, Tag } from '../src/ui';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { deleteLog, itemsKcal, planDay, refreshSync, useStore } from '../src/store';
import { BASE_URL, errorKey } from '../src/api';
import { Items, NoteBox, ProgressBar, mealName } from '../src/meals';
import { addDays, fmtWeekdayLong, toDateOnly } from '../src/format';

export default function Meals() {
  useLang();
  const sync = useStore((s) => s.sync);
  const token = useStore((s) => s.token);
  const [day, setDay] = useState(() => new Date());

  useFocusEffect(
    useCallback(() => {
      refreshSync().catch(() => undefined);
    }, []),
  );

  const date = toDateOnly(day);
  const isToday = date === toDateOnly(new Date());
  const meals = planDay(sync.plan, day);
  const logs = sync.logs.filter((l) => l.date === date);
  const eaten = logs.reduce((n, l) => n + (l.kcal ?? itemsKcal(l.items) ?? 0), 0);
  const planned = meals.reduce((n, m) => n + (itemsKcal(m.items) ?? 0), 0);

  const remove = (id: number) =>
    Alert.alert(t('tm_delete_q'), undefined, [
      { text: t('cancel'), style: 'cancel' },
      { text: t('delete'), style: 'destructive', onPress: () => deleteLog(id).catch((e) => Alert.alert(t(errorKey(e)))) },
    ]);

  const move = (n: number) => {
    const d = addDays(day, n);
    if (d.getTime() > Date.now()) return;
    setDay(d);
  };

  return (
    <Screen header={<Header title={t('tm_title')} />}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Pressable accessibilityRole="button" accessibilityLabel={t('tm_prev')} onPress={() => move(-1)} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="back" />
        </Pressable>
        <Text style={{ flex: 1, textAlign: 'center', fontSize: 16, fontWeight: '700', color: C.ink }}>{isToday ? t('tm_today') : fmtWeekdayLong(day)}</Text>
        <Pressable accessibilityRole="button" accessibilityLabel={t('tm_next')} disabled={isToday} onPress={() => move(1)} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center', opacity: isToday ? 0.3 : 1 }}>
          <Icon name="chevron" />
        </Pressable>
      </View>

      <Card style={{ gap: 8 }}>
        <Text style={{ fontSize: 15, fontWeight: '700', color: C.ink }}>{planned ? t('tm_kcal', { a: eaten, b: planned }) : `${eaten} kcal`}</Text>
        {planned > 0 && <ProgressBar value={eaten} max={planned} />}
      </Card>

      {[0, 1, 2, 3, 4].map((i) => {
        const plan = meals[i];
        const done = logs.filter((l) => l.meal === i);
        if (!plan?.items.length && !done.length) return null;
        return (
          <Card key={i} style={{ gap: 10 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ flex: 1, fontSize: 17, fontWeight: '800', color: C.ink }}>{mealName(i)}</Text>
              {!!sync.plan?.times?.[i] && <Muted>{sync.plan.times[i]}</Muted>}
              {done.length > 0 && <Tag text={t('tm_done')} />}
            </View>
            {!!plan?.items.length && (
              <View style={{ gap: 6 }}>
                <Muted>{t('tm_plan_says')}</Muted>
                <Items items={plan.items} faint={done.length > 0} />
              </View>
            )}
            {!!plan?.note && <NoteBox text={plan.note} />}
            {done.map((l) => (
              <View key={l.id} style={{ gap: 6, borderTopWidth: 1, borderTopColor: C.soft, paddingTop: 10 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Text style={{ flex: 1, fontSize: 14, fontWeight: '700', color: C.accentDark }}>{l.from_plan ? t('tm_as_planned') : t('tm_you_ate')}</Text>
                  {l.kcal !== null && <Muted>{l.kcal} kcal</Muted>}
                  <Pressable accessibilityRole="button" accessibilityLabel={t('delete')} onPress={() => remove(l.id)} style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name="trash" size={18} color={C.muted} />
                  </Pressable>
                </View>
                {!l.from_plan && <Items items={l.items} />}
                {l.photo && !!token && !!BASE_URL && (
                  <Image
                    source={{ uri: `${BASE_URL}/api/logs/${l.id}/photo`, headers: { Authorization: 'Bearer ' + token } }}
                    style={{ width: '100%', height: 180, borderRadius: 12, backgroundColor: C.soft }}
                    resizeMode="cover"
                    accessibilityIgnoresInvertColors
                  />
                )}
              </View>
            ))}
            {done.length === 0 && (
              <Button title={t('tm_log')} kind="secondary" icon="plus" onPress={() => router.push({ pathname: '/log-meal', params: { meal: String(i), date } })} />
            )}
          </Card>
        );
      })}

      <Button title={t('lm_title')} icon="plus" onPress={() => router.push({ pathname: '/log-meal', params: { date } })} />
    </Screen>
  );
}
