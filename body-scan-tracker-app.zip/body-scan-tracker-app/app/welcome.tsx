// 01 Welcome
import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { router } from 'expo-router';
import { Body, Bubble, Button, Card, H1, Icon, Muted, Notice, Screen } from '../src/ui';
import { Sparkline } from '../src/chart';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { ensureToken } from '../src/store';
import { errorKey } from '../src/api';
import { fmtNum } from '../src/format';

export default function Welcome() {
  useLang();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const start = async () => {
    setBusy(true);
    setError('');
    try {
      await ensureToken();
      router.replace('/reminders');
    } catch (e) {
      setError(t(errorKey(e)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen footer={<Button title={t('w_start')} onPress={start} loading={busy} />}>
      <View style={{ height: 8 }} />
      <Text style={{ fontSize: 15, fontWeight: '800', color: C.accent }}>Body Tracker</Text>

      {/* Example of what the app shows (decorative) */}
      <Card style={{ gap: 10 }}>
        <View accessibilityElementsHidden importantForAccessibility="no-hide-descendants" style={{ gap: 10 }}>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            <View style={{ backgroundColor: C.accentSoft, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6 }}>
              <Text style={{ fontWeight: '700', color: C.accentDark }}>{fmtNum(78.4)} kg</Text>
            </View>
            <View style={{ backgroundColor: C.soft, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6 }}>
              <Text style={{ fontWeight: '700', color: C.ink }}>{fmtNum(31.2)} kg</Text>
            </View>
            <View style={{ flex: 1 }} />
            <Muted>{t('w_example')}</Muted>
          </View>
          <Muted>{t('w_fat_since')}</Muted>
          <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 8 }}>
            <Text style={{ fontSize: 30, fontWeight: '800', color: C.ink }}>{fmtNum(27.5)} %</Text>
            <Text style={{ fontSize: 15, fontWeight: '700', color: C.accent }}>−{fmtNum(3.4)}</Text>
          </View>
          <Sparkline values={[30.9, 30.1, 29.4, 28.8, 28.6, 27.5]} />
        </View>
      </Card>

      <H1>
        {t('w_title1')}
        {'\n'}
        {t('w_title2')}
      </H1>
      <Body>{t('w_body')}</Body>
      <View style={{ gap: 10 }}>
        {(['w_b1', 'w_b2', 'w_b3'] as const).map((k) => (
          <View key={k} style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Bubble icon="check" size={28} iconSize={16} width={3} />
            <Text style={{ flex: 1, fontSize: 15, color: C.ink }}>{t(k)}</Text>
          </View>
        ))}
      </View>
      {!!error && <Notice tone="error" title={error} />}
    </Screen>
  );
}
