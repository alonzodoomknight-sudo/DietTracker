// 16 Meal plan: the week from the dietitian's website (or a snapped paper plan), day by day
import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { BackButton, BottomNav, Bubble, Button, Card, H1, Icon, IconButton, Muted, Screen } from '../src/ui';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { itemsKcal, refreshSync, useStore, weekdayIndex } from '../src/store';
import { Chip, Items, NoteBox, mealName } from '../src/meals';
import { fmtDayMonthYear, parseLocal, planDayName } from '../src/format';

export default function PlanScreen() {
  useLang();
  const plan = useStore((s) => s.sync.plan);
  const connected = useStore((s) => s.me?.dietitian?.status === 'accepted');
  const [day, setDay] = useState(() => weekdayIndex(new Date()));

  useFocusEffect(
    useCallback(() => {
      refreshSync().catch(() => undefined);
    }, []),
  );

  const header = (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingLeft: 20, paddingRight: 8, paddingTop: 8 }}>
      <BackButton to="/today" />
      <View style={{ flex: 1 }}>
        <H1>{t('pl_title')}</H1>
        {plan && (
          <Muted>
            {[plan.name, plan.source === 'paper' ? t('pl_from_paper') : plan.dietitian ? t('pl_from', { name: plan.dietitian }) : null, (() => {
              const d = parseLocal(plan.start_date);
              return d ? t('pl_since', { date: fmtDayMonthYear(d) }) : null;
            })()]
              .filter(Boolean)
              .join(' · ')}
          </Muted>
        )}
      </View>
      {plan && <IconButton icon="cart" label={t('sl_title')} onPress={() => router.push('/shopping')} />}
    </View>
  );

  if (!plan) {
    return (
      <Screen header={header} bottom={<BottomNav active="plan" />}>
        <Card style={{ alignItems: 'center', gap: 12, paddingVertical: 28 }}>
          <Bubble icon="plate" size={72} iconSize={32} />
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink, textAlign: 'center' }}>{t('pl_empty')}</Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: C.body, textAlign: 'center' }}>{connected ? t('pl_empty_dt') : t('pl_empty_body')}</Text>
          <Button title={t('ps_title')} icon="camera" onPress={() => router.push('/plan-snap')} style={{ alignSelf: 'stretch' }} />
          {!connected && <Button title={t('st_connect')} kind="secondary" onPress={() => router.push('/connect')} style={{ alignSelf: 'stretch' }} />}
        </Card>
      </Screen>
    );
  }

  const meals = plan.days[day]?.meals ?? [];
  const dayKcal = meals.reduce((n, m) => n + (itemsKcal(m.items) ?? 0), 0);
  const today = weekdayIndex(new Date());

  return (
    <Screen header={header} bottom={<BottomNav active="plan" />}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <Chip key={i} label={planDayName(i)} sub={i === today ? t('pl_today') : undefined} on={day === i} onPress={() => setDay(i)} />
        ))}
      </ScrollView>

      {!!plan.note && <NoteBox text={plan.note} />}
      {dayKcal > 0 && <Muted>{t('pl_day_kcal', { day: planDayName(day, true), n: dayKcal })}</Muted>}

      {meals.map((m, i) =>
        m.items.length || m.note ? (
          <Card key={i} style={{ gap: 10 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ flex: 1, fontSize: 17, fontWeight: '800', color: C.ink }}>{mealName(i)}</Text>
              {!!plan.times[i] && (
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                  <Icon name="clock" size={16} color={C.muted} />
                  <Muted>{plan.times[i]}</Muted>
                </View>
              )}
            </View>
            <Items items={m.items} />
            <NoteBox text={m.note} />
            {day === today && m.items.length > 0 && (
              <Button title={t('pl_log')} kind="secondary" icon="check" onPress={() => router.push({ pathname: '/log-meal', params: { meal: String(i) } })} />
            )}
          </Card>
        ) : null,
      )}
      {!meals.some((m) => m.items.length || m.note) && <Muted>{t('pl_day_empty')}</Muted>}

      {(plan.source === 'paper' || !connected) && <Button title={t('ps_new')} kind="secondary" icon="camera" onPress={() => router.push('/plan-snap')} />}
    </Screen>
  );
}
