// 17 Goals set by the dietitian, with progress from the latest scan
import React, { useCallback } from 'react';
import { Text, View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Card, Header, Muted, Screen, Tag } from '../src/ui';
import { C } from '../src/theme';
import { t, tk, useLang } from '../src/i18n';
import { refreshSync, useStore } from '../src/store';
import { ProgressBar } from '../src/meals';
import { fmtDayMonthYear, fmtMetric, parseLocal } from '../src/format';

export default function Goals() {
  useLang();
  const goals = useStore((s) => s.sync.goals);
  const prefs = useStore((s) => s.prefs);
  const units = { weight: prefs.weight, length: prefs.length };

  useFocusEffect(
    useCallback(() => {
      refreshSync().catch(() => undefined);
    }, []),
  );

  const show = (metric: string | null, v: number | null) => (v === null ? '–' : metric ? fmtMetric(metric, v, units) : String(v));

  return (
    <Screen header={<Header title={t('go_title')} />}>
      {!goals.length && <Muted>{t('go_empty')}</Muted>}
      {goals.map((g) => {
        const due = parseLocal(g.due);
        const span = g.start !== null && g.target !== null ? g.target - g.start : null;
        const moved = g.start !== null && g.current !== null ? g.current - g.start : null;
        const pct = span && moved !== null ? Math.max(0, Math.min(1, moved / span)) : g.done ? 1 : 0;
        return (
          <Card key={g.id} style={{ gap: 10, opacity: g.done ? 0.7 : 1 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Text style={{ flex: 1, fontSize: 16, fontWeight: '800', color: C.ink }}>{g.title}</Text>
              {g.done && <Tag text={t('go_done')} />}
            </View>
            {!!g.metric && <Muted>{tk('mt_' + g.metric)}</Muted>}
            {g.target !== null && (
              <>
                <ProgressBar value={pct} max={1} />
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Muted>{t('go_start', { v: show(g.metric, g.start) })}</Muted>
                  <Muted>{t('go_now', { v: show(g.metric, g.current) })}</Muted>
                  <Muted>{t('go_target', { v: show(g.metric, g.target) })}</Muted>
                </View>
              </>
            )}
            {due && <Muted>{t('go_due', { date: fmtDayMonthYear(due) })}</Muted>}
          </Card>
        );
      })}
    </Screen>
  );
}
