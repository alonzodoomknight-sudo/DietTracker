// 20 Connect your dietitian
import React, { useCallback, useState } from 'react';
import { Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Body, Button, Card, Field, Header, Icon, Muted, Notice, Screen } from '../src/ui';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { connectDietitian, refresh, useStore } from '../src/store';
import { ApiError, errorKey } from '../src/api';

export default function Connect() {
  useLang();
  const me = useStore((s) => s.me);
  const [code, setCode] = useState('');
  const [name, setName] = useState(me?.name ?? '');
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState('');

  useFocusEffect(
    useCallback(() => {
      refresh().catch(() => undefined);
    }, []),
  );

  const dietitian = me?.dietitian;

  const connect = async () => {
    setError('');
    const clean = code.trim().toUpperCase();
    if (!name.trim()) {
      setError(t('cn_need_name'));
      return;
    }
    if (!/^[A-Z0-9]{6}$/.test(clean)) {
      setError(t('cn_not_found'));
      return;
    }
    setBusy(true);
    try {
      await connectDietitian(clean, name.trim());
    } catch (e) {
      setError(e instanceof ApiError && e.code === 'code_not_found' ? t('cn_not_found') : t(errorKey(e)));
    } finally {
      setBusy(false);
    }
  };

  const checkAgain = async () => {
    setChecking(true);
    setError('');
    try {
      await refresh();
    } catch (e) {
      setError(t(errorKey(e)));
    } finally {
      setChecking(false);
    }
  };

  if (dietitian) {
    const accepted = dietitian.status === 'accepted';
    return (
      <Screen
        header={<Header title={t('cn_title')} />}
        footer={accepted ? <Button title={t('done')} onPress={() => router.back()} /> : <Button title={t('cn_check_again')} kind="secondary" loading={checking} onPress={checkAgain} />}
      >
        <Card style={{ alignItems: 'center', gap: 10, paddingVertical: 28 }}>
          <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: accepted ? C.accent : C.warnBg, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name={accepted ? 'check' : 'user'} color={accepted ? '#FFFFFF' : C.warnInk} size={30} width={accepted ? 3 : 2} />
          </View>
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink, textAlign: 'center' }}>
            {accepted ? t('cn_connected_title', { name: dietitian.name }) : t('cn_pending_title', { name: dietitian.name })}
          </Text>
          <Body style={{ textAlign: 'center' }}>{accepted ? t('cn_connected_body', { name: dietitian.name }) : t('cn_pending_body', { name: dietitian.name })}</Body>
        </Card>
        <Muted>{t('cn_disconnect_note')}</Muted>
        {!!error && <Notice tone="error" title={error} />}
      </Screen>
    );
  }

  return (
    <Screen header={<Header title={t('cn_title')} />} footer={<Button title={t('cn_connect')} onPress={connect} loading={busy} />}>
      <Body>{t('cn_body')}</Body>
      <Field label={t('cn_code')} value={code} onChangeText={(s) => setCode(s.toUpperCase().replace(/[^A-Z0-9]/g, ''))} keyboardType="default" autoCapitalize="characters" maxLength={6} placeholder="GR7K2Q" />
      <Field label={t('cn_name')} value={name} onChangeText={setName} keyboardType="default" autoCapitalize="words" note={t('cn_name_hint')} />
      <Card style={{ gap: 10 }}>
        <Text style={{ fontSize: 15, fontWeight: '700', color: C.ink }}>{t('cn_will_see')}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Icon name="chart" color={C.accent} size={20} />
          <Text style={{ flex: 1, fontSize: 15, color: C.body }}>{t('cn_see_scans')}</Text>
        </View>
        <Muted>{t('cn_disconnect_note')}</Muted>
      </Card>
      {!!error && <Notice tone="error" title={error} />}
      <Muted style={{ textAlign: 'center' }}>{t('cn_no_dietitian')}</Muted>
    </Screen>
  );
}
