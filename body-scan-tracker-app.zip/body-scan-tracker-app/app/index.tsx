import React from 'react';
import { Redirect } from 'expo-router';
import { useStore } from '../src/store';

export default function Index() {
  const onboarded = useStore((s) => s.prefs.onboarded);
  // With a dietitian or a meal plan the app opens on Today; with scans only, on Progress.
  const full = useStore((s) => s.me?.dietitian?.status === 'accepted' || !!s.sync.plan);
  return <Redirect href={!onboarded ? '/welcome' : full ? '/today' : '/home'} />;
}
