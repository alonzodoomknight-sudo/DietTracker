// 13 Today: next meal, calories, water, next appointment, messages, goals
import React, { ReactNode, useCallback, useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { BackButton, BottomNav, Bubble, BubbleTone, Button, Card, H1, Icon, IconButton, IconName, Label, Muted, Screen } from '../src/ui';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { itemsKcal, joinCall, logMeal, planDay, refreshSync, useStore } from '../src/store';
import { errorKey } from '../src/api';
import { Items, ProgressBar, mealName, todayStr } from '../src/meals';
import { fmtLong, fmtMetric, fmtTime, fmtWeekday, parseLocal } from '../src/format';

const TILE_TONES: Partial<Record<IconName, BubbleTone>> = { drop: 'blue', video: 'navy', message: 'orange', target: 'purple', calendar: 'navy' };

function Tile({ icon, title, sub, onPress, right }: { icon: IconName; title: string; sub?: string; onPress: () => void; right?: ReactNode }) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress}>
      <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Bubble icon={icon} tone={TILE_TONES[icon] ?? 'teal'} />
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 15, fontWeight: '700', color: C.ink }}>{title}</Text>
          {!!sub && <Muted>{sub}</Muted>}
        </View>
        {right ?? <Icon name="chevron" size={18} color={C.faint} />}
      </Card>
    </Pressable>
  );
}

export default function Today() {
  useLang();
  const sync = useStore((s) => s.sync);
  const me = useStore((s) => s.me);
  const prefs = useStore((s) => s.prefs);
  const scans = useStore((s) => s.scans);
  const [busy, setBusy] = useState(false);

  useFocusEffect(
    useCallback(() => {
      refreshSync().catch(() => undefined);
    }, []),
  );

  const now = new Date();
  const today = todayStr();
  const meals = planDay(sync.plan, now);
  const logs = sync.logs.filter((l) => l.date === today);
  const eaten = logs.reduce((n, l) => n + (l.kcal ?? itemsKcal(l.items) ?? 0), 0);
  const planned = meals.reduce((n, m) => n + (itemsKcal(m.items) ?? 0), 0);
  const water = sync.water[today] ?? 0;

  // The next meal of the plan that isn't logged yet (by its time, or in order).
  const times = sync.plan?.times ?? [];
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const order = [0, 1, 2, 3, 4].filter((i) => meals[i]?.items?.length && !logs.some((l) => l.meal === i));
  const next =
    order.find((i) => {
      const m = /^(\d{1,2}):(\d{2})$/.exec(times[i] ?? '');
      return m ? +m[1] * 60 + +m[2] >= nowMin - 60 : true;
    }) ?? order[0];

  const appt = sync.appointments.find((a) => a.status !== 'cancelled' && (parseLocal(a.starts_at)?.getTime() ?? 0) + a.minutes * 60000 > Date.now());
  const apptAt = appt ? parseLocal(appt.starts_at) : null;
  const callOpen = !!appt && appt.video && appt.with_dietitian && !!apptAt && (appt.call_started || Math.abs(apptAt.getTime() - Date.now()) < 15 * 60000 || (apptAt.getTime() < Date.now()));

  const goals = sync.goals.filter((g) => !g.done);
  const last = scans[scans.length - 1];
  const nextScan = parseLocal(prefs.nextScan);

  const ate = async (meal: number) => {
    setBusy(true);
    try {
      await logMeal({ date: today, meal, items: meals[meal].items, kcal: itemsKcal(meals[meal].items), from_plan: true });
    } catch (e) {
      Alert.alert(t(errorKey(e)));
    } finally {
      setBusy(false);
    }
  };

  const header = (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingLeft: 20, paddingRight: 8, paddingTop: 8 }}>
      <BackButton />
      <View style={{ flex: 1 }}>
        <H1>{me?.name ? t('td_hello', { name: me.name.split(' ')[0] }) : t('nav_today')}</H1>
        <Muted>{fmtLong(now)}</Muted>
      </View>
      <IconButton icon="settings" label={t('settings')} onPress={() => router.push('/settings')} />
    </View>
  );

  return (
    <Screen header={header} bottom={<BottomNav active="today" />}>
      {sync.plan ? (
        <>
          <Card style={{ gap: 10 }}>
            <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 8 }}>
              <Text style={{ fontSize: 28, fontWeight: '800', color: C.ink }}>{eaten}</Text>
              <Muted>{planned ? t('td_of_kcal', { n: planned }) : 'kcal'}</Muted>
            </View>
            {planned > 0 && <ProgressBar value={eaten} max={planned} />}
            <Muted>{t('td_meals_logged', { a: logs.length, b: meals.filter((m) => m.items.length).length })}</Muted>
            <Button title={t('tm_title')} kind="secondary" onPress={() => router.push('/meals')} />
          </Card>

          {next !== undefined && (
            <>
              <Label>{t('td_next_meal')}</Label>
              <Card style={{ gap: 10 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Text style={{ flex: 1, fontSize: 17, fontWeight: '800', color: C.ink }}>{mealName(next)}</Text>
                  {!!times[next] && <Muted>{times[next]}</Muted>}
                </View>
                <Items items={meals[next].items} />
                <View style={{ flexDirection: 'row', gap: 10 }}>
                  <Button title={t('td_ate_it')} icon="check" onPress={() => ate(next)} loading={busy} style={{ flex: 1 }} />
                  <Button title={t('td_other')} kind="secondary" onPress={() => router.push({ pathname: '/log-meal', params: { meal: String(next) } })} style={{ flex: 1 }} />
                </View>
              </Card>
            </>
          )}
        </>
      ) : (
        <Card style={{ gap: 10 }}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.ink }}>{t('td_no_plan')}</Text>
          <Muted>{me?.dietitian?.status === 'accepted' ? t('td_no_plan_dt') : t('td_no_plan_body')}</Muted>
          <Button title={t('ps_title')} icon="camera" kind="secondary" onPress={() => router.push('/plan-snap')} />
        </Card>
      )}

      <Tile
        icon="drop"
        title={t('td_water', { a: water, b: prefs.waterGoal })}
        sub={t('wa_glasses', { n: Math.floor(water / prefs.glass) })}
        onPress={() => router.push('/water')}
      />

      {appt && apptAt ? (
        <Tile
          icon={appt.video ? 'video' : 'calendar'}
          title={appt.title || t(appt.kind === 'remeasure' ? 'ap_remeasure' : 'ap_appointment')}
          sub={`${fmtWeekday(apptAt)}, ${fmtTime(apptAt)}${appt.status === 'pending' ? ' · ' + t('ap_pending') : appt.status === 'unpaid' ? ' · ' + t('ap_unpaid') : ''}`}
          onPress={() => router.push('/appointments')}
          right={callOpen ? <Button title={t('ap_join')} icon="video" onPress={() => joinCall(appt.id).catch((e) => Alert.alert(t(errorKey(e))))} /> : undefined}
        />
      ) : (
        <Tile icon="calendar" title={t('ap_title')} sub={t('ap_none')} onPress={() => router.push('/appointments')} />
      )}

      {sync.unread > 0 && <Tile icon="message" title={t('td_unread', { n: sync.unread })} onPress={() => router.push('/chat')} />}

      {goals.length > 0 && (
        <Tile icon="target" title={t('go_title')} sub={goals.length === 1 ? goals[0].title : t('td_goals', { n: goals.length })} onPress={() => router.push('/goals')} />
      )}

      <Tile
        icon="camera"
        title={t('scan_a_sheet')}
        sub={nextScan ? t('h_next', { date: `${fmtWeekday(nextScan)}, ${fmtTime(nextScan)}` }) : undefined}
        onPress={() => router.push('/scan/start')}
      />

      {last?.values.weight && (
        <Tile
          icon="chart"
          title={fmtMetric('weight', last.values.weight.v, { weight: prefs.weight, length: prefs.length })}
          sub={t('td_last_scan', { date: fmtWeekday(parseLocal(last.scanned_at) ?? now) })}
          onPress={() => router.replace('/home')}
        />
      )}
    </Screen>
  );
}
