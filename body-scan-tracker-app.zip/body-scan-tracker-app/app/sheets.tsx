// 09 All sheets
import React, { useCallback } from 'react';
import { View } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { BackButton, BottomNav, Card, H1, Muted, Screen } from '../src/ui';
import { t, useLang } from '../src/i18n';
import { refresh, useStore } from '../src/store';
import { fmtMonthYear, parseLocal } from '../src/format';
import { SheetRow, weightChange } from '../src/sheetRow';

export default function Sheets() {
  useLang();
  const scans = useStore((s) => s.scans);
  const prefs = useStore((s) => s.prefs);
  const units = { weight: prefs.weight, length: prefs.length };

  useFocusEffect(
    useCallback(() => {
      refresh().catch(() => undefined);
    }, []),
  );

  const first = scans.length ? parseLocal(scans[0].scanned_at) : null;
  const rows = scans.map((s, i) => ({ s, change: weightChange(scans, i) })).reverse();

  return (
    <Screen
      bottom={<BottomNav active="sheets" />}
      header={
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 20, paddingTop: 8 }}>
          <BackButton to="/home" />
          <View style={{ flex: 1, gap: 2 }}>
            <H1>{t('sh_title')}</H1>
            {first && <Muted>{scans.length === 1 ? t('sh_count_one', { date: fmtMonthYear(first) }) : t('sh_count', { n: scans.length, date: fmtMonthYear(first) })}</Muted>}
          </View>
        </View>
      }
    >
      {rows.length > 0 && (
        <Card style={{ paddingVertical: 0 }}>
          {rows.map(({ s, change }, i) => (
            <SheetRow key={s.id} scan={s} change={change} units={units} last={i === rows.length - 1} />
          ))}
        </Card>
      )}
    </Screen>
  );
}
