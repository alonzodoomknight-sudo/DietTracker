import React, { useEffect } from 'react';
import { Stack, router } from 'expo-router';
import * as Notifications from 'expo-notifications';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { init, refreshSync, useStore } from '../src/store';

// Where a notification takes you (the website sends "screen" with each one).
const SCREENS: Record<string, string> = {
  progress: '/home',
  plan: '/plan',
  goals: '/goals',
  appointments: '/appointments',
  chat: '/chat',
  connect: '/settings',
  water: '/water',
};
import { Loading } from '../src/ui';
import { C } from '../src/theme';

export default function RootLayout() {
  const ready = useStore((s) => s.ready);

  useEffect(() => {
    init();
  }, []);

  useEffect(() => {
    if (!ready) return undefined;
    const open = (data: unknown) => {
      const screen = (data as { screen?: string } | null)?.screen;
      if (screen && SCREENS[screen]) router.push(SCREENS[screen] as any);
    };
    // A notification that arrives while the app is open: fetch the new data.
    const got = Notifications.addNotificationReceivedListener(() => {
      refreshSync().catch(() => undefined);
    });
    // A tap on a notification
    const tapped = Notifications.addNotificationResponseReceivedListener((r) => {
      refreshSync().catch(() => undefined);
      open(r.notification.request.content.data);
    });
    Notifications.getLastNotificationResponseAsync()
      .then((last) => last && open(last.notification.request.content.data))
      .catch(() => undefined);
    return () => {
      got.remove();
      tapped.remove();
    };
  }, [ready]);

  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      {ready ? (
        <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: C.bg }, animation: 'slide_from_right' }} />
      ) : (
        <Loading />
      )}
    </SafeAreaProvider>
  );
}
