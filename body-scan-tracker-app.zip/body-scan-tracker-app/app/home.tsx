// 03 Home (no scans yet) and 08 Your progress
import React, { ReactNode, useCallback } from 'react';
import { Pressable, Text, View } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { BottomNav, Bubble, Button, Card, Grad, H1, Icon, IconButton, Label, Muted, Screen, WELL } from '../src/ui';
import { SheetRow, weightChange } from '../src/sheetRow';
import { Sparkline } from '../src/chart';
import { C } from '../src/theme';
import { Key, t, useLang } from '../src/i18n';
import { refresh, useStore } from '../src/store';
import { reminderDate } from '../src/reminders';
import { Units, convert, fmtDayMonth, fmtDelta, fmtMetric, fmtMonthShort, fmtNum, fmtWeekday, fmtTime, parseLocal } from '../src/format';
import { metric } from '../src/metrics';

const CHARTS: { key: string; label: Key }[] = [
  { key: 'weight', label: 'ch_weight' },
  { key: 'smm', label: 'ch_muscle' },
  { key: 'pbf', label: 'ch_fat' },
  { key: 'bmi', label: 'ch_bmi' },
  { key: 'vfl', label: 'ch_belly' },
  { key: 'score', label: 'ch_score' },
];

function NextScan() {
  const nextScan = useStore((s) => s.prefs.nextScan);
  const remind = useStore((s) => s.prefs.remind);
  const d = parseLocal(nextScan);
  if (!d || d.getTime() < Date.now()) return null;
  return (
    <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
      <Icon name="calendar" color={C.accent} />
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 15, fontWeight: '600', color: C.ink }}>{t('h_next', { date: `${fmtWeekday(d)}, ${fmtTime(d)}` })}</Text>
        {remind && reminderDate(nextScan) && <Muted>{t('h_remind_note')}</Muted>}
      </View>
    </Card>
  );
}

export default function Home() {
  useLang();
  const scans = useStore((s) => s.scans);
  const prefs = useStore((s) => s.prefs);
  const full = useStore((s) => s.me?.dietitian?.status === 'accepted' || !!s.sync.plan);
  const units: Units = { weight: prefs.weight, length: prefs.length };

  useFocusEffect(
    useCallback(() => {
      refresh().catch(() => undefined);
    }, []),
  );

  const header = (
    <View style={{ flexDirection: 'row', alignItems: 'center', paddingLeft: 20, paddingRight: 8, paddingTop: 8 }}>
      <View style={{ flex: 1 }}>
        <H1>{t('h_title')}</H1>
      </View>
      {full && <IconButton icon="list" label={t('sheets')} onPress={() => router.push('/sheets')} />}
      <IconButton icon="settings" label={t('settings')} onPress={() => router.push('/settings')} />
    </View>
  );

  if (!scans.length) {
    return (
      <Screen header={header} bottom={<BottomNav active="progress" />}>
        <Card style={{ alignItems: 'center', gap: 12, paddingVertical: 28 }}>
          <Bubble icon="sheet" size={72} iconSize={34} />
          <Text style={{ fontSize: 20, fontWeight: '800', color: C.ink }}>{t('h_empty')}</Text>
          <Text style={{ fontSize: 15, lineHeight: 22, color: C.body, textAlign: 'center' }}>{t('h_empty_body')}</Text>
          <Button title={t('h_first')} icon="camera" onPress={() => router.push('/scan/start')} style={{ alignSelf: 'stretch' }} />
          <Muted style={{ textAlign: 'center' }}>{t('h_works')}</Muted>
        </Card>
        <NextScan />
      </Screen>
    );
  }

  // Goal from the most recent sheet that printed a target weight.
  const withTarget = [...scans].reverse().find((s) => s.values.target_weight);
  const first = scans.find((s) => s.values.weight);
  const latest = [...scans].reverse().find((s) => s.values.weight);
  let goal: ReactNode = null;
  if (withTarget && first && latest) {
    const target = withTarget.values.target_weight.v;
    const start = first.values.weight.v;
    const now = latest.values.weight.v;
    const span = target - start;
    const pct = span === 0 ? 100 : Math.max(0, Math.min(100, Math.round(((now - start) / span) * 100)));
    const toGo = Math.abs(target - now);
    const reached = (span <= 0 && now <= target) || (span > 0 && now >= target);
    const targetDate = parseLocal(withTarget.scanned_at);
    const firstDate = parseLocal(first.scanned_at);
    goal = (
      <Card style={{ gap: 10 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Label>{t('p_goal')}</Label>
          <Text style={{ fontSize: 15, fontWeight: '800', color: C.accent }}>{pct}%</Text>
        </View>
        <Text style={{ fontSize: 26, fontWeight: '800', color: C.ink }}>
          {reached ? t('p_reached') : t('p_to_go', { v: fmtMetric('weight', toGo, units) })}
        </Text>
        <View accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: 100, now: pct }} style={[{ height: 14, borderRadius: 7, overflow: 'hidden' }, WELL]}>
          <View style={{ width: `${pct}%`, height: 14, borderRadius: 7, backgroundColor: C.accent }}>
            <Grad colors={[['#FFFFFF', 0.35], ['#FFFFFF', 0]]} radius={7} />
          </View>
        </View>
        <Muted>{t('p_target', { v: fmtMetric('weight', target, units), date: targetDate ? fmtDayMonth(targetDate) : '' })}</Muted>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Muted>{t('p_on', { v: fmtMetric('weight', start, units), date: firstDate ? fmtDayMonth(firstDate) : '' })}</Muted>
          <Muted style={{ fontWeight: '700', color: C.ink }}>{t('p_now', { v: fmtMetric('weight', now, units) })}</Muted>
        </View>
      </Card>
    );
  }

  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
  const recent = scans.filter((s) => {
    const d = parseLocal(s.scanned_at);
    return d && d >= sixMonthsAgo;
  });
  const chartScans = recent.length ? recent : scans.slice(-1);

  return (
    <Screen header={header} bottom={<BottomNav active="progress" />}>
      {goal}
      <Label>{t('p_charts')}</Label>
      {CHARTS.map(({ key, label }) => {
        const pts = chartScans.filter((s) => s.values[key]);
        if (!pts.length) return null;
        const m = metric(key);
        const values = pts.map((s) => convert(m.unit, s.values[key].v, units).value);
        const lastScan = pts[pts.length - 1];
        const prevScan = pts.length > 1 ? pts[pts.length - 2] : null;
        const lastVal = lastScan.values[key].v;
        const unitShown = convert(m.unit, lastVal, units).unit;
        let delta = '';
        if (prevScan) {
          const diff = lastVal - prevScan.values[key].v;
          const prevDate = parseLocal(prevScan.scanned_at);
          const text = m.unit === '%' ? `${diff < 0 ? '↓' : diff > 0 ? '↑' : '→'} ${fmtNum(Math.abs(diff), m.decimals)} ${t('p_points')}` : fmtDelta(key, diff, units);
          delta = t('p_since', { delta: text, date: prevDate ? fmtDayMonth(prevDate) : '' });
        }
        const firstD = parseLocal(pts[0].scanned_at);
        const lastD = parseLocal(lastScan.scanned_at);
        return (
          <Card key={key} style={{ gap: 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 12 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: '600', color: C.muted }}>{t(label)}</Text>
                <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>
                  {fmtMetric(key, lastVal, units, false)} <Text style={{ fontSize: 14, color: C.muted, fontWeight: '600' }}>{unitShown}</Text>
                </Text>
                {!!delta && <Muted>{delta}</Muted>}
              </View>
              <View style={{ width: 140 }}>
                <Sparkline values={values} label={`${t(label)}: ${values.map((v) => fmtNum(v, m.decimals)).join(', ')}`} />
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Muted>{firstD ? fmtMonthShort(firstD) : ''}</Muted>
                  <Muted>{lastD && pts.length > 1 ? fmtMonthShort(lastD) : ''}</Muted>
                </View>
              </View>
            </View>
          </Card>
        );
      })}

      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6 }}>
        <Label>{t('p_recent')}</Label>
        <Pressable accessibilityRole="button" onPress={() => router.replace('/sheets')} style={{ minHeight: 44, justifyContent: 'center', paddingHorizontal: 4 }}>
          <Text style={{ fontSize: 15, fontWeight: '700', color: C.accent }}>{t('p_see_all')}</Text>
        </Pressable>
      </View>
      <Card style={{ paddingVertical: 0 }}>
        {[...scans]
          .map((s, i) => ({ s, change: weightChange(scans, i) }))
          .reverse()
          .slice(0, 3)
          .map(({ s, change }, i, arr) => (
            <SheetRow key={s.id} scan={s} change={change} units={units} last={i === arr.length - 1} />
          ))}
      </Card>
      <NextScan />
    </Screen>
  );
}
