// 24 Add dates from paper: appointments and re-measure days written on the paper plan
import React, { useState } from 'react';
import { Pressable, Text, View } from 'react-native';
import { router } from 'expo-router';
import { Button, Card, Field, Header, Icon, Muted, Notice, Screen, Segmented } from '../src/ui';
import { PickerBox, usePicker } from '../src/datetime';
import { C } from '../src/theme';
import { t, useLang } from '../src/i18n';
import { addOwnDates } from '../src/store';
import { errorKey } from '../src/api';
import { fmtLong, fmtTime, toLocal } from '../src/format';

type Kind = 'appointment' | 'remeasure' | 'other';
type Item = { kind: Kind; title: string; at: Date | null };

export default function AddDates() {
  useLang();
  const picker = usePicker();
  const [items, setItems] = useState<Item[]>([{ kind: 'appointment', title: '', at: null }]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const update = (i: number, patch: Partial<Item>) => setItems((all) => all.map((x, k) => (k === i ? { ...x, ...patch } : x)));

  const pickDay = (i: number) => {
    const base = items[i].at ?? (() => {
      const d = new Date();
      d.setDate(d.getDate() + 7);
      d.setHours(10, 0, 0, 0);
      return d;
    })();
    picker.open('date', base, (d) => {
      const x = new Date(d);
      x.setHours(base.getHours(), base.getMinutes(), 0, 0);
      update(i, { at: x });
    });
  };
  const pickTime = (i: number) => {
    const base = items[i].at;
    if (!base) return;
    picker.open('time', base, (d) => {
      const x = new Date(base);
      x.setHours(d.getHours(), d.getMinutes(), 0, 0);
      update(i, { at: x });
    });
  };

  const save = async () => {
    const ready = items.filter((x) => x.at);
    if (!ready.length) {
      setError(t('ad_need_date'));
      return;
    }
    setBusy(true);
    setError('');
    try {
      await addOwnDates(ready.map((x) => ({ kind: x.kind, title: x.title.trim(), starts_at: toLocal(x.at!) })));
      router.back();
    } catch (e) {
      setError(t(errorKey(e)));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen header={<Header title={t('ad_title')} />} footer={<Button title={t('save')} onPress={save} loading={busy} />}>
      <Muted>{t('ad_body')}</Muted>
      {!!error && <Notice tone="error" title={error} />}
      {items.map((x, i) => (
        <Card key={i} style={{ gap: 10 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={{ flex: 1, fontSize: 15, fontWeight: '700', color: C.ink }}>{t('ad_date_n', { n: i + 1 })}</Text>
            {items.length > 1 && (
              <Pressable accessibilityRole="button" accessibilityLabel={t('delete')} onPress={() => setItems((all) => all.filter((_, k) => k !== i))} style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="close" size={18} color={C.muted} />
              </Pressable>
            )}
          </View>
          <Segmented<Kind>
            label={t('ad_kind')}
            value={x.kind}
            onChange={(v) => update(i, { kind: v })}
            options={[
              { value: 'appointment', label: t('ap_appointment') },
              { value: 'remeasure', label: t('ap_remeasure') },
              { value: 'other', label: t('ap_other') },
            ]}
          />
          <Field label={t('ad_note')} value={x.title} onChangeText={(s) => update(i, { title: s })} keyboardType="default" autoCapitalize="sentences" maxLength={120} />
          <PickerBox label={t('ad_day')} text={x.at ? fmtLong(x.at) : t('r_pick_date')} onPress={() => pickDay(i)} />
          {x.at && <PickerBox label={t('ad_time')} icon="bell" text={fmtTime(x.at)} onPress={() => pickTime(i)} />}
        </Card>
      ))}
      {items.length < 10 && <Button title={t('ad_another')} kind="secondary" icon="plus" onPress={() => setItems((all) => [...all, { kind: 'remeasure', title: '', at: null }])} />}
      {picker.element}
    </Screen>
  );
}
