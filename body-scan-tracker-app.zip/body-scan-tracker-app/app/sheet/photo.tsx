// 11 Sheet photo: every page, pinch to zoom, save and share
import React, { useMemo, useRef, useState } from 'react';
import { Alert, Image, PanResponder, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Banner, Button, Header } from '../../src/ui';
import { C } from '../../src/theme';
import { t, useLang } from '../../src/i18n';
import { useStore } from '../../src/store';
import { api } from '../../src/api';
import { machineName } from '../../src/machines';
import { fmtDate, parseLocal } from '../../src/format';
import { savePages, sharePages } from '../../src/files';

function ZoomPage({ uri, token, width, height, onZoom }: { uri: string; token: string | null; width: number; height: number; onZoom: (s: number) => void }) {
  const [view, setView] = useState({ scale: 1, x: 0, y: 0 });
  const cur = useRef({ scale: 1, x: 0, y: 0 });
  const start = useRef({ dist: 0, scale: 1, x: 0, y: 0 });

  const apply = (next: { scale: number; x: number; y: number }) => {
    cur.current = next;
    setView(next);
    onZoom(next.scale);
  };

  const responder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: (e) => e.nativeEvent.touches.length === 2 || cur.current.scale > 1,
        onMoveShouldSetPanResponder: (e) => e.nativeEvent.touches.length === 2 || cur.current.scale > 1,
        onPanResponderGrant: () => {
          start.current = { dist: 0, ...cur.current };
        },
        onPanResponderMove: (e, g) => {
          const touches = e.nativeEvent.touches;
          if (touches.length === 2) {
            const dist = Math.hypot(touches[0].pageX - touches[1].pageX, touches[0].pageY - touches[1].pageY);
            if (!start.current.dist) start.current = { dist, ...cur.current };
            const scale = Math.max(1, Math.min(4, (start.current.scale * dist) / start.current.dist));
            apply({ ...cur.current, scale });
          } else if (touches.length === 1 && cur.current.scale > 1) {
            if (start.current.dist) start.current = { dist: 0, ...cur.current, x: cur.current.x - g.dx, y: cur.current.y - g.dy };
            apply({ ...cur.current, x: start.current.x + g.dx, y: start.current.y + g.dy });
          }
        },
        onPanResponderRelease: () => {
          start.current.dist = 0;
          if (cur.current.scale <= 1.02) apply({ scale: 1, x: 0, y: 0 });
        },
        onPanResponderTerminationRequest: () => false,
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  return (
    <View style={{ width, height, overflow: 'hidden', alignItems: 'center', justifyContent: 'center' }} {...responder.panHandlers}>
      <Image
        source={{ uri, headers: token ? { Authorization: 'Bearer ' + token } : undefined }}
        resizeMode="contain"
        accessibilityIgnoresInvertColors
        style={{ width, height, transform: [{ translateX: view.x }, { translateY: view.y }, { scale: view.scale }] }}
      />
    </View>
  );
}

export default function SheetPhoto() {
  useLang();
  const { id } = useLocalSearchParams<{ id: string }>();
  const scans = useStore((s) => s.scans);
  const token = useStore((s) => s.token);
  const scan = scans.find((s) => String(s.id) === String(id));
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [page, setPage] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [busy, setBusy] = useState<'save' | 'share' | null>(null);

  if (!scan) return <View style={{ flex: 1, backgroundColor: C.dark }} />;
  const date = parseLocal(scan.scanned_at);
  const pageHeight = height - insets.top - insets.bottom - 200;

  const save = async () => {
    if (!token) return;
    setBusy('save');
    try {
      const ok = await savePages(token, scan);
      Alert.alert(ok ? t('ph_saved') : t('ph_no_access'));
    } catch {
      Alert.alert(t('err_generic'));
    } finally {
      setBusy(null);
    }
  };

  const share = async () => {
    if (!token) return;
    setBusy('share');
    try {
      await sharePages(token, scan);
    } catch {
      Alert.alert(t('err_generic'));
    } finally {
      setBusy(null);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: C.dark }}>
      <SafeAreaView edges={['top']} style={{ backgroundColor: C.bannerA }}>
        <Banner inset={false}>
          <Header title={date ? fmtDate(date) : scan.scanned_at} sub={t('ph_sub', { machine: machineName(scan.machine) })} />
        </Banner>
      </SafeAreaView>
      <ScrollView
        horizontal
        pagingEnabled
        scrollEnabled={zoom <= 1}
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={(e) => setPage(Math.round(e.nativeEvent.contentOffset.x / width))}
      >
        {Array.from({ length: scan.page_count }, (_, i) => (
          <ZoomPage key={i} uri={api.pageUrl(scan.id, i + 1)} token={token} width={width} height={pageHeight} onZoom={setZoom} />
        ))}
      </ScrollView>
      <View style={{ paddingHorizontal: 20, paddingTop: 10, paddingBottom: insets.bottom + 14, gap: 10 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={{ color: '#D5DBD8', fontSize: 13 }}>{t('ph_zoom', { n: Math.round(zoom * 100) })}</Text>
          {scan.page_count > 1 && <Text style={{ color: '#D5DBD8', fontSize: 13 }}>{t('ph_page', { a: page + 1, b: scan.page_count })}</Text>}
        </View>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Button title={t('ph_save')} icon="download" kind="light" onPress={save} loading={busy === 'save'} style={{ flex: 1 }} />
          <Button title={t('ph_share')} icon="share" onPress={share} loading={busy === 'share'} style={{ flex: 1 }} />
        </View>
      </View>
    </View>
  );
}
