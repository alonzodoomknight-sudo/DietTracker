// 10 Scan details: every number with its normal range and High / Low tags
import React, { useState } from 'react';
import { Alert, Image, Pressable, Text, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Button, Card, Header, Icon, Label, Muted, Notice, Screen, Tag } from '../../src/ui';
import { C } from '../../src/theme';
import { t, tk, useLang } from '../../src/i18n';
import { deleteScan, getState, useStore } from '../../src/store';
import { api, errorKey } from '../../src/api';
import { machineName } from '../../src/machines';
import { GROUPS, METRICS, PARTS } from '../../src/metrics';
import { Units, fmtDate, parseLocal } from '../../src/format';
import { metricLabel, rangeTag, rangeText, valueText } from '../../src/labels';
import { loadFromScan } from '../../src/draft';

function HighLow({ tag }: { tag: 'high' | 'low' | null }) {
  if (tag === 'high') return <Tag text={t('d_high')} bg={C.highBg} color={C.highInk} />;
  if (tag === 'low') return <Tag text={t('d_low')} bg={C.lowBg} color={C.lowInk} />;
  return null;
}

export default function ScanDetails() {
  useLang();
  const { id } = useLocalSearchParams<{ id: string }>();
  const scans = useStore((s) => s.scans);
  const token = useStore((s) => s.token);
  const prefs = useStore((s) => s.prefs);
  const units: Units = { weight: prefs.weight, length: prefs.length };
  const [error, setError] = useState('');
  const scan = scans.find((s) => String(s.id) === String(id));

  if (!scan) {
    return <Screen header={<Header />}>{null}</Screen>;
  }
  const date = parseLocal(scan.scanned_at);
  const v = scan.values;
  const count = Object.keys(v).length;

  const confirmDelete = () =>
    Alert.alert(t('d_delete_q'), t('d_delete_body'), [
      { text: t('cancel'), style: 'cancel' },
      {
        text: t('delete'),
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteScan(scan.id);
            router.back();
          } catch (e) {
            setError(t(errorKey(e)));
          }
        },
      },
    ]);

  const edit = () => {
    loadFromScan(scan, getState().me);
    router.push('/scan/check');
  };

  const segKinds = ['lean', 'fat', 'ecw'] as const;
  const hasSegments = PARTS.some((p) => segKinds.some((k) => v[`${k}_${p}`]));

  return (
    <Screen
      header={<Header title={date ? fmtDate(date) : scan.scanned_at} sub={t('d_numbers', { machine: machineName(scan.machine), n: count })} />}
      footer={
        <>
          {!!error && <Notice tone="error" title={error} />}
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Button title={t('d_edit')} kind="secondary" onPress={edit} style={{ flex: 1 }} />
            <Button title={t('d_delete')} kind="danger" onPress={confirmDelete} style={{ flex: 1 }} />
          </View>
        </>
      }
    >
      {scan.page_count > 0 ? (
        <Pressable accessibilityRole="button" onPress={() => router.push(`/sheet/photo?id=${scan.id}`)}>
          <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <Image
              source={{ uri: api.pageUrl(scan.id, 1), headers: token ? { Authorization: 'Bearer ' + token } : undefined }}
              style={{ width: 56, height: 74, borderRadius: 8, backgroundColor: C.soft }}
              accessibilityIgnoresInvertColors
            />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: '700', color: C.ink }}>{t('d_photo')}</Text>
              <Muted>{t('d_photo_sub')}</Muted>
            </View>
            <Icon name="chevron" color={C.faint} size={18} />
          </Card>
        </Pressable>
      ) : (
        <Muted>{t('d_no_photo')}</Muted>
      )}

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
        <Tag text={t('d_high')} bg={C.highBg} color={C.highInk} />
        <Tag text={t('d_low')} bg={C.lowBg} color={C.lowInk} />
        <Muted style={{ flex: 1, minWidth: 180 }}>{t('d_legend')}</Muted>
      </View>

      {GROUPS.map((g) => {
        const keys = METRICS.filter((m) => m.group === g && v[m.key]).map((m) => m.key);
        if (!keys.length) return null;
        return (
          <View key={g} style={{ gap: 10 }}>
            <Label>{tk('g_' + g)}</Label>
            <Card style={{ paddingVertical: 4 }}>
              {keys.map((key, i) => {
                const val = v[key];
                return (
                  <View key={key} style={{ minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6, borderBottomWidth: i < keys.length - 1 ? 1 : 0, borderBottomColor: C.soft }}>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 15, fontWeight: '600', color: C.ink }}>{metricLabel(key)}</Text>
                      {!!rangeText(key, val.lo, val.hi) && <Muted>{rangeText(key, val.lo, val.hi)}</Muted>}
                    </View>
                    <HighLow tag={rangeTag(val.v, val.lo, val.hi)} />
                    <Text style={{ fontSize: 16, fontWeight: '700', color: C.ink }}>{valueText(key, val.v, units)}</Text>
                  </View>
                );
              })}
            </Card>
          </View>
        );
      })}

      {hasSegments && (
        <View style={{ gap: 10 }}>
          <Label>{t('g_segments')}</Label>
          <Card style={{ gap: 6 }}>
            <View style={{ flexDirection: 'row' }}>
              <Text style={{ flex: 1.3, fontSize: 12, fontWeight: '600', color: C.muted }}>{t('c_body_part')}</Text>
              <Text style={{ flex: 1, fontSize: 12, fontWeight: '600', color: C.muted, textAlign: 'right' }}>{t('c_lean')}</Text>
              <Text style={{ flex: 1, fontSize: 12, fontWeight: '600', color: C.muted, textAlign: 'right' }}>{t('c_fat')}</Text>
              <Text style={{ flex: 1, fontSize: 12, fontWeight: '600', color: C.muted, textAlign: 'right' }}>{t('c_ecw')}</Text>
            </View>
            {PARTS.map((p) => (
              <View key={p} style={{ flexDirection: 'row', alignItems: 'center', minHeight: 40, borderTopWidth: 1, borderTopColor: C.soft }}>
                <Text style={{ flex: 1.3, fontSize: 14, fontWeight: '600', color: C.ink }}>{tk('part_' + p)}</Text>
                {segKinds.map((k) => {
                  const val = v[`${k}_${p}`];
                  return (
                    <View key={k} style={{ flex: 1, alignItems: 'flex-end', gap: 2 }}>
                      <Text style={{ fontSize: 14, color: C.ink }}>{val ? valueText(`${k}_${p}`, val.v, units) : '—'}</Text>
                      {val && <HighLow tag={rangeTag(val.v, val.lo, val.hi)} />}
                    </View>
                  );
                })}
              </View>
            ))}
          </Card>
        </View>
      )}

      {v.balance && (
        <Card style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: C.ink }}>{t('mt_balance')}</Text>
          <Text style={{ fontSize: 15, fontWeight: '700', color: C.ink }}>{valueText('balance', v.balance.v, units)}</Text>
        </Card>
      )}
    </Screen>
  );
}
