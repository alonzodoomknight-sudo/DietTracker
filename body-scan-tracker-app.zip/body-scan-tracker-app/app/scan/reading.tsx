// 05 Reading the sheet (all pages read together as one scan)
import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Image, Text, View } from 'react-native';
import { router } from 'expo-router';
import { BackButton, Body, Button, Card, H1, Icon, Muted, Screen } from '../../src/ui';
import { C } from '../../src/theme';
import { t, useLang } from '../../src/i18n';
import { applyRead, getDraft, removePage, resetDraft, setDraft, prefillAbout } from '../../src/draft';
import { OcrLine, ReadResult, parse } from '../../src/reader';
import { readPage } from '../../src/ocr';
import { machine, machineName } from '../../src/machines';
import { getState } from '../../src/store';

type Step = 0 | 1 | 2 | 3 | 4; // 1 found, 2 machine, 3 numbers, 4 checking

function ask(title: string, body: string, buttons: { text: string; value: string; style?: 'cancel' | 'destructive' }[]): Promise<string> {
  return new Promise((resolve) => {
    Alert.alert(
      title,
      body,
      buttons.map((b) => ({ text: b.text, style: b.style, onPress: () => resolve(b.value) })),
      { cancelable: false },
    );
  });
}

function StepRow({ done, active, title, sub }: { done: boolean; active: boolean; title: string; sub?: string }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 48 }}>
      <View style={{ width: 28, height: 28, borderRadius: 14, backgroundColor: done ? C.accent : C.soft, alignItems: 'center', justifyContent: 'center' }}>
        {done ? <Icon name="check" size={16} color="#FFFFFF" width={3} /> : active ? <ActivityIndicator size="small" color={C.accent} /> : null}
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 16, fontWeight: done || active ? '700' : '500', color: done || active ? C.ink : C.muted }}>{title}</Text>
        {!!sub && <Muted>{sub}</Muted>}
      </View>
    </View>
  );
}

export default function Reading() {
  useLang();
  const [run, setRun] = useState(0);
  const [step, setStep] = useState<Step>(0);
  const [pageText, setPageText] = useState('');
  const [machineText, setMachineText] = useState('');
  const [detected, setDetected] = useState(true);
  const [count, setCount] = useState({ a: 0, b: 0 });
  const [failed, setFailed] = useState(false);
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  useEffect(() => {
    (async () => {
      const pages = getDraft().pages;
      if (!pages.length) {
        router.back();
        return;
      }
      setFailed(false);
      setStep(0);
      const lines: OcrLine[] = [];
      for (let i = 0; i < pages.length; i++) {
        if (pages.length > 1) setPageText(t('rd_page', { a: i + 1, b: pages.length }));
        try {
          lines.push(...(await readPage(pages[i], i + 1)));
        } catch {
          // a page that can't be read is skipped; the user can type its numbers
        }
        if (i === 0) setStep(1);
      }
      if (!alive.current) return;
      if (!lines.length) {
        setFailed(true);
        return;
      }
      setStep(1);
      const result: ReadResult = parse(lines);
      setMachineText(result.detected ? machineName(result.machineId) : '');
      setDetected(result.detected);
      setStep(2);

      // Count up to the numbers found, so the user sees the reading happen.
      const total = Object.keys(result.fields).length;
      const found = Object.values(result.fields).filter((f) => f.value !== null).length;
      setStep(3);
      for (let n = 0; n <= found; n += Math.max(1, Math.ceil(found / 12))) {
        if (!alive.current) return;
        setCount({ a: n, b: total });
        await new Promise((r) => setTimeout(r, 60));
      }
      setCount({ a: found, b: total });
      setStep(4);
      await new Promise((r) => setTimeout(r, 400));
      if (!alive.current) return;

      // Pages printed by this machine that weren't added
      const tpl = machine(result.machineId).template;
      if (tpl && tpl.pages > pages.length) {
        const choice = await ask(t('rd_missing_title', { n: pages.length + 1 }), t('rd_missing_body', { total: tpl.pages }), [
          { text: t('rd_skip'), value: 'skip', style: 'cancel' },
          { text: t('rd_add_it'), value: 'add' },
        ]);
        if (choice === 'add') {
          router.back(); // back to the camera; the pages stay
          return;
        }
      }

      // A page with a different date or machine than page 1
      const first = result.pages[0];
      for (let p = 1; p < result.pages.length; p++) {
        const info = result.pages[p];
        const otherDate = first?.date && info.date && first.date.toDateString() !== info.date.toDateString();
        const otherMachine = first?.machineId && info.machineId && first.machineId !== info.machineId;
        if (otherDate || otherMachine) {
          const choice = await ask(t('rd_same_title'), t('rd_same_body', { n: p + 1 }), [
            { text: t('rd_same_no'), value: 'remove', style: 'destructive' },
            { text: t('rd_same_yes'), value: 'keep' },
          ]);
          if (choice === 'remove') {
            removePage(p);
            setRun((r) => r + 1); // read the remaining pages again
            return;
          }
        }
      }

      if (!alive.current) return; // went back
      applyRead(result, lines);
      router.replace('/scan/check');
    })();
  }, [run]);

  const typeInstead = () => {
    setDraft({ machineId: 'other', detected: false, showAll: true, fields: {} });
    router.replace('/scan/check');
  };

  const retakePhoto = () => {
    const keepAbout = getState().me;
    resetDraft();
    prefillAbout(keepAbout);
    router.back();
  };

  const firstPage = getDraft().pages[0];

  if (failed) {
    return (
      <Screen
        footer={
          <>
            <Button title={t('rd_retake')} icon="camera" onPress={retakePhoto} />
            <Button title={t('rd_type')} kind="secondary" onPress={typeInstead} />
          </>
        }
      >
        <View style={{ flexDirection: 'row' }}>
          <BackButton to="/home" />
        </View>
        <View style={{ height: 24 }} />
        <Icon name="alert" size={40} color={C.warnLine} />
        <H1>{t('rd_failed')}</H1>
        <Body>{t('rd_failed_body')}</Body>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={{ flexDirection: 'row' }}>
        <BackButton to="/home" />
      </View>
      <View style={{ height: 8 }} />
      {firstPage && (
        <Card style={{ padding: 8, alignItems: 'center' }}>
          <Image source={{ uri: firstPage }} resizeMode="contain" style={{ width: '100%', height: 260, borderRadius: 12 }} accessibilityIgnoresInvertColors />
        </Card>
      )}
      <H1>{t('rd_title')}</H1>
      <Muted>{pageText || t('rd_sub')}</Muted>
      <Card style={{ gap: 4 }}>
        <StepRow done={step >= 1} active={step === 0} title={t('rd_found')} />
        <StepRow done={step >= 2} active={step === 1} title={detected ? t('rd_machine') : t('rd_no_machine')} sub={machineText || undefined} />
        <StepRow done={step >= 4} active={step === 3} title={t('rd_reading', { n: count.b || '…' })} sub={step >= 3 ? t('rd_count', { a: count.a, b: count.b }) : undefined} />
        <StepRow done={false} active={step === 4} title={t('rd_checking')} />
      </Card>
    </Screen>
  );
}
