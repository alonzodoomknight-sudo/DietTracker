// 06 Check the numbers (also used for "Edit numbers" on a saved scan)
import React, { useState } from 'react';
import { Pressable, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { Button, Card, ChoiceModal, Field, Grad, GRADS, Header, Label, Muted, Notice, RIM, SHADOW, Screen, Segmented, Tag } from '../../src/ui';
import { PickerBox, usePicker } from '../../src/datetime';
import { C } from '../../src/theme';
import { t, tk, useLang } from '../../src/i18n';
import { draftToInput, getDraft, setDraft, setField, setMachine, unclearCount, useDraft } from '../../src/draft';
import { GROUPS, METRICS, PARTS, metric } from '../../src/metrics';
import { MACHINES, machine, machineName } from '../../src/machines';
import { createScan, updateMe, updateScan } from '../../src/store';
import { errorKey } from '../../src/api';
import { fmtDayMonthYear, fmtLong, fmtTime, parseNum, toDateOnly } from '../../src/format';
import { metricLabel } from '../../src/labels';

function CellInput({ value, onChange, warn, label }: { value: string; onChange: (s: string) => void; warn: boolean; label: string }) {
  return (
    <TextInput
      accessibilityLabel={label}
      value={value}
      onChangeText={onChange}
      keyboardType="decimal-pad"
      style={{
        flex: 1,
        height: 44,
        borderRadius: 10,
        borderWidth: warn ? 2 : 1.5,
        borderColor: warn ? C.warnLine : C.line,
        backgroundColor: warn ? C.warnBg : C.card,
        paddingHorizontal: 8,
        fontSize: 15,
        color: C.ink,
        textAlign: 'center',
      }}
    />
  );
}

export default function Check() {
  useLang();
  const d = useDraft();
  const picker = usePicker();
  const [machineOpen, setMachineOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const m = machine(d.machineId);
  const unclear = unclearCount();
  const multi = d.pages.length > 1;

  const shown = (key: string) => !!d.fields[key] || d.showAll;

  const save = async () => {
    setError('');
    const { input, error: problem } = draftToInput();
    if (!input) {
      setError(t(problem ?? 'err_generic'));
      return;
    }
    setSaving(true);
    try {
      const cur = getDraft();
      const scan = cur.editingId ? await updateScan(cur.editingId, input) : await createScan(input, cur.pages);
      const patch: { height_cm?: number; age?: number; birth_date?: string; sex?: 'male' | 'female' } = {};
      const h = parseNum(cur.height);
      if (h !== null && !Number.isNaN(h)) patch.height_cm = h;
      const a = parseInt(cur.age, 10);
      if (!Number.isNaN(a)) patch.age = a;
      if (cur.birth) patch.birth_date = toDateOnly(cur.birth);
      if (cur.sex) patch.sex = cur.sex;
      if (Object.keys(patch).length) await updateMe(patch).catch(() => undefined);
      if (cur.editingId) router.back();
      else router.replace(`/scan/saved?id=${scan.id}`);
    } catch (e) {
      setError(t(errorKey(e)));
    } finally {
      setSaving(false);
    }
  };

  const pickDate = () =>
    picker.open('date', d.date, (x) => {
      const n = new Date(x);
      n.setHours(d.date.getHours(), d.date.getMinutes(), 0, 0);
      setDraft({ date: n });
    }, new Date());
  const pickTime = () =>
    picker.open('time', d.date, (x) => {
      const n = new Date(d.date);
      n.setHours(x.getHours(), x.getMinutes(), 0, 0);
      setDraft({ date: n });
    });
  const pickBirth = () => picker.open('date', d.birth ?? new Date(1990, 0, 1), (x) => setDraft({ birth: x }), new Date());

  const segKinds = ['lean', 'fat', 'ecw'] as const;
  const showSegments = d.showAll || PARTS.some((p) => segKinds.some((k) => d.fields[`${k}_${p}`]));
  const showBalance = d.showAll || !!d.fields.balance;

  return (
    <Screen
      header={<Header title={t('c_title')} right={unclear > 0 ? <Tag text={t('c_to_check', { n: unclear })} bg={C.warnBg} color={C.warnInk} /> : undefined} />}
      footer={
        <>
          {!!error && <Notice tone="error" title={error} />}
          <Button title={saving ? t('c_saving') : t('c_save')} onPress={save} loading={saving} />
        </>
      }
    >
      <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View style={{ flex: 1 }}>
          <Muted>{d.detected ? t('c_machine_detected') : t('c_machine')}</Muted>
          <Text style={{ fontSize: 18, fontWeight: '800', color: C.ink }}>{machineName(d.machineId)}</Text>
        </View>
        <Pressable accessibilityRole="button" onPress={() => setMachineOpen(true)} style={[{ minHeight: 44, paddingHorizontal: 14, borderRadius: 14, justifyContent: 'center', boxShadow: SHADOW.soft } as any, RIM]}>
          <Grad colors={GRADS.secondary} radius={14} />
          <Text style={{ fontSize: 15, fontWeight: '700', color: C.accent }}>{t('c_change')}</Text>
        </Pressable>
      </Card>

      {unclear > 0 && <Notice title={unclear === 1 ? t('c_unclear_one') : t('c_unclear_many', { n: unclear })} body={t('c_unclear_body')} />}
      {!m.template && <Notice tone="info" title={t('c_no_template')} />}

      <Label>{t('c_scan_date')}</Label>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <View style={{ flex: 2 }}>
          <PickerBox label={t('c_scan_date')} text={fmtLong(d.date)} onPress={pickDate} />
        </View>
        <View style={{ flex: 1 }}>
          <PickerBox label={t('c_scan_date')} icon="bell" text={fmtTime(d.date)} onPress={pickTime} />
        </View>
      </View>

      <Label>{t('c_about')}</Label>
      <Card style={{ gap: 12 }}>
        <Muted>{t('c_about_sub')}</Muted>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <View style={{ flex: 1 }}>
            <Field label={t('c_height')} value={d.height} onChangeText={(s) => setDraft({ height: s })} unit="cm" />
          </View>
          <View style={{ flex: 1 }}>
            <Field label={t('c_age')} value={d.age} onChangeText={(s) => setDraft({ age: s.replace(/[^0-9]/g, '') })} unit={t('years')} keyboardType="number-pad" />
          </View>
        </View>
        <View style={{ gap: 4 }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: C.ink }}>{t('c_birth')}</Text>
          <PickerBox label={t('c_birth')} text={d.birth ? fmtDayMonthYear(d.birth) : t('not_set')} onPress={pickBirth} />
        </View>
        <View style={{ gap: 4 }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: C.ink }}>{t('c_sex')}</Text>
          <Segmented
            label={t('c_sex')}
            value={d.sex}
            onChange={(v) => setDraft({ sex: v })}
            options={[
              { value: 'male', label: t('male') },
              { value: 'female', label: t('female') },
            ]}
          />
        </View>
      </Card>

      {GROUPS.map((g) => {
        const keys = METRICS.filter((x) => x.group === g && shown(x.key)).map((x) => x.key);
        if (!keys.length) return null;
        return (
          <View key={g} style={{ gap: 10 }}>
            <Label>{tk('g_' + g)}</Label>
            <Card style={{ gap: 12 }}>
              {keys.map((key) => {
                const f = d.fields[key];
                return (
                  <Field
                    key={key}
                    label={metricLabel(key)}
                    value={f?.text ?? ''}
                    onChangeText={(s) => setField(key, s)}
                    unit={metric(key).unit}
                    warn={f?.unclear ? t('c_check') : undefined}
                    note={multi && f?.page ? t('c_page', { n: f.page }) : undefined}
                  />
                );
              })}
            </Card>
          </View>
        );
      })}

      {showSegments && (
        <View style={{ gap: 10 }}>
          <Label>{t('g_segments')}</Label>
          <Card style={{ gap: 8 }}>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Text style={{ flex: 1.3, fontSize: 12, fontWeight: '600', color: C.muted }}>{t('c_body_part')}</Text>
              <Text style={{ flex: 1, fontSize: 12, fontWeight: '600', color: C.muted, textAlign: 'center' }}>{t('c_lean')}</Text>
              <Text style={{ flex: 1, fontSize: 12, fontWeight: '600', color: C.muted, textAlign: 'center' }}>{t('c_fat')}</Text>
              <Text style={{ flex: 1, fontSize: 12, fontWeight: '600', color: C.muted, textAlign: 'center' }}>{t('c_ecw')}</Text>
            </View>
            {PARTS.map((p) => (
              <View key={p} style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Text style={{ flex: 1.3, fontSize: 14, fontWeight: '600', color: C.ink }}>{tk('part_' + p)}</Text>
                {segKinds.map((k) => {
                  const key = `${k}_${p}`;
                  const f = d.fields[key];
                  return <CellInput key={key} label={metricLabel(key)} value={f?.text ?? ''} onChange={(s) => setField(key, s)} warn={!!f?.unclear} />;
                })}
              </View>
            ))}
          </Card>
        </View>
      )}

      {showBalance && (
        <View style={{ gap: 10 }}>
          <Label>{t('mt_balance')}</Label>
          <Segmented
            label={t('mt_balance')}
            value={(d.fields.balance?.text ?? '') as '0' | '1' | '2' | ''}
            onChange={(v) => setField('balance', v)}
            options={[
              { value: '0', label: t('bal_0') },
              { value: '1', label: t('bal_1') },
              { value: '2', label: t('bal_2') },
            ]}
          />
        </View>
      )}

      {!d.showAll && (
        <Button title={t('c_more')} kind="secondary" icon="plus" onPress={() => setDraft({ showAll: true })} />
      )}

      <ChoiceModal
        visible={machineOpen}
        title={t('c_choose_machine')}
        value={d.machineId}
        onClose={() => setMachineOpen(false)}
        onPick={(id) => setMachine(id)}
        options={MACHINES.map((x) => ({ value: x.id, label: machineName(x.id), sub: x.template ? t('c_read_auto') : t('c_typed_in') }))}
      />
      {picker.element}
    </Screen>
  );
}
