// Starts a new scan with an empty draft, then opens the camera.
import React, { useEffect } from 'react';
import { router } from 'expo-router';
import { Loading } from '../../src/ui';
import { prefillAbout, resetDraft } from '../../src/draft';
import { getState } from '../../src/store';

export default function StartScan() {
  useEffect(() => {
    resetDraft();
    prefillAbout(getState().me);
    router.replace('/scan/snap');
  }, []);
  return <Loading />;
}
