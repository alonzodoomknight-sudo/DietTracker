// 04 Snap the sheet (with 2–3 page sheets: Add another page / Done, thumbnails)
import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Image, Pressable, ScrollView, Text, View } from 'react-native';
import { router } from 'expo-router';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import DocumentScanner from 'react-native-document-scanner-plugin';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button, Icon, IconButton } from '../../src/ui';
import { C } from '../../src/theme';
import { t, useLang } from '../../src/i18n';
import { addPage, removePage, useDraft } from '../../src/draft';
import { pdfToPages } from '../../src/store';
import { writeBase64Jpeg } from '../../src/files';
import { errorKey } from '../../src/api';

const MAX_PAGES = 5;

function Corners() {
  const arm = 34;
  const style = { position: 'absolute' as const, width: arm, height: arm, borderColor: '#FFFFFF' };
  return (
    <View pointerEvents="none" style={{ position: 'absolute', top: '12%', bottom: '24%', left: '9%', right: '9%' }}>
      <View style={[style, { top: 0, left: 0, borderTopWidth: 4, borderLeftWidth: 4, borderTopLeftRadius: 14 }]} />
      <View style={[style, { top: 0, right: 0, borderTopWidth: 4, borderRightWidth: 4, borderTopRightRadius: 14 }]} />
      <View style={[style, { bottom: 0, left: 0, borderBottomWidth: 4, borderLeftWidth: 4, borderBottomLeftRadius: 14 }]} />
      <View style={[style, { bottom: 0, right: 0, borderBottomWidth: 4, borderRightWidth: 4, borderBottomRightRadius: 14 }]} />
    </View>
  );
}

function Tool({ icon, label, onPress }: { icon: 'upload' | 'file'; label: string; onPress: () => void }) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={{ width: 84, alignItems: 'center', gap: 6, minHeight: 56, justifyContent: 'center' }}>
      <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: 'rgba(255,255,255,0.14)', alignItems: 'center', justifyContent: 'center' }}>
        <Icon name={icon} color="#FFFFFF" size={22} />
      </View>
      <Text style={{ color: '#FFFFFF', fontSize: 12, fontWeight: '600', textAlign: 'center' }}>{label}</Text>
    </Pressable>
  );
}

export default function Snap() {
  useLang();
  const d = useDraft();
  const insets = useSafeAreaInsets();
  const [perm, requestPerm] = useCameraPermissions();
  const cam = useRef<CameraView>(null);
  const [added, setAdded] = useState<number | null>(null); // page number just added
  const [retake, setRetake] = useState<number | null>(null); // index of the page being retaken
  const [busy, setBusy] = useState('');

  const full = d.pages.length >= MAX_PAGES && retake === null;

  useEffect(() => {
    if (perm && String(perm.status) === 'undetermined') requestPerm();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [perm?.status]);

  const tooMany = () => Alert.alert(t('s_max_pages', { n: MAX_PAGES }));

  const capture = async () => {
    if (full) return tooMany();
    try {
      const photo = await cam.current?.takePictureAsync({ quality: 0.8 });
      if (!photo?.uri) return;
      if (retake !== null) {
        addPage(photo.uri, retake);
        setAdded(retake + 1);
        setRetake(null);
      } else {
        addPage(photo.uri);
        setAdded(d.pages.length + 1);
      }
    } catch {
      Alert.alert(t('err_generic'));
    }
  };

  const upload = async () => {
    if (full) return tooMany();
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      selectionLimit: MAX_PAGES - d.pages.length,
      quality: 0.8,
      preferredAssetRepresentationMode: ImagePicker.UIImagePickerPreferredAssetRepresentationMode.Compatible,
    });
    if (res.canceled || !res.assets?.length) return;
    let count = d.pages.length;
    for (const a of res.assets.slice(0, MAX_PAGES - count)) {
      addPage(a.uri);
      count++;
    }
    setAdded(count);
  };

  const pickFile = async () => {
    if (full) return tooMany();
    const res = await DocumentPicker.getDocumentAsync({ type: ['application/pdf', 'image/*'], copyToCacheDirectory: true });
    if (res.canceled || !res.assets?.length) return;
    const file = res.assets[0];
    const isPdf = file.mimeType === 'application/pdf' || file.name?.toLowerCase().endsWith('.pdf');
    if (!isPdf) {
      addPage(file.uri);
      setAdded(d.pages.length + 1);
      return;
    }
    setBusy(t('s_opening_pdf'));
    try {
      const pages = await pdfToPages(file.uri, file.name ?? 'sheet.pdf');
      let count = d.pages.length;
      const stamp = Date.now();
      for (let i = 0; i < pages.length && count < MAX_PAGES; i++) {
        const f = await writeBase64Jpeg(`pdf-${stamp}-${i + 1}.jpg`, pages[i]);
        addPage(f.uri);
        count++;
      }
      setAdded(count);
    } catch (e) {
      Alert.alert(t('s_pdf_failed'), t(errorKey(e)));
    } finally {
      setBusy('');
    }
  };

  // Finds the sheet by itself ("Sheet found · hold still"), takes the photo and straightens it.
  const autoScan = async () => {
    if (full) return tooMany();
    try {
      const res = await DocumentScanner.scanDocument({ maxNumDocuments: retake !== null ? 1 : MAX_PAGES - d.pages.length, croppedImageQuality: 90 });
      const images = res?.scannedImages ?? [];
      if (!images.length) return;
      if (retake !== null) {
        addPage(images[0], retake);
        setAdded(retake + 1);
        setRetake(null);
        return;
      }
      let count = d.pages.length;
      for (const uri of images.slice(0, MAX_PAGES - count)) {
        addPage(uri);
        count++;
      }
      setAdded(count);
    } catch {
      Alert.alert(t('s_auto_failed'));
    }
  };

  const pageActions = (index: number) =>
    Alert.alert(t('s_page', { n: index + 1 }), undefined, [
      {
        text: t('s_retake'),
        onPress: () => {
          setRetake(index);
          setAdded(null);
        },
      },
      {
        text: t('delete'),
        style: 'destructive',
        onPress: () => {
          removePage(index);
          setAdded(null);
          setRetake(null);
        },
      },
      { text: t('cancel'), style: 'cancel' },
    ]);

  const done = () => router.push('/scan/reading');

  const cameraOn = perm?.granted;

  return (
    <View style={{ flex: 1, backgroundColor: C.dark }}>
      {cameraOn && <CameraView ref={cam} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} facing="back" />}
      {cameraOn && <Corners />}

      <SafeAreaView edges={['top']} style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 6 }}>
        <IconButton icon="back" label={t('back')} color="#FFFFFF" onPress={() => router.back()} />
        <IconButton icon="close" label={t('back')} color="#FFFFFF" onPress={() => router.back()} />
        <Text accessibilityRole="header" style={{ flex: 1, color: '#FFFFFF', fontSize: 18, fontWeight: '800' }}>
          {t('s_title')}
        </Text>
      </SafeAreaView>

      <View style={{ alignItems: 'center', marginTop: 8 }}>
        <View style={{ backgroundColor: 'rgba(0,0,0,0.55)', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8 }}>
          <Text style={{ color: '#FFFFFF', fontSize: 14, fontWeight: '600' }}>
            {retake !== null ? t('s_retake_now', { n: retake + 1 }) : t('s_hint')}
          </Text>
        </View>
      </View>

      {!cameraOn && perm && (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 28, gap: 12 }}>
          <Icon name="camera" color="#FFFFFF" size={40} />
          <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: '800', textAlign: 'center' }}>{t('s_no_camera')}</Text>
          <Text style={{ color: '#D5DBD8', fontSize: 15, textAlign: 'center' }}>{t('s_no_camera_body')}</Text>
          {perm.canAskAgain && <Button title={t('s_allow')} onPress={requestPerm} />}
        </View>
      )}

      <View style={{ flex: 1 }} />

      <View style={{ backgroundColor: 'rgba(11,15,13,0.88)', paddingTop: 12, paddingBottom: insets.bottom + 12, gap: 12 }}>
        {d.pages.length > 0 && (
          <ScrollView horizontal contentContainerStyle={{ paddingHorizontal: 16, gap: 10 }}>
            {d.pages.map((uri, i) => (
              <Pressable key={uri + i} accessibilityRole="button" accessibilityLabel={t('s_page', { n: i + 1 })} onPress={() => pageActions(i)}>
                <Image source={{ uri }} style={{ width: 54, height: 72, borderRadius: 8, borderWidth: retake === i ? 3 : 1, borderColor: retake === i ? C.warnLine : '#FFFFFF' }} />
                <Text style={{ color: '#FFFFFF', fontSize: 11, textAlign: 'center', marginTop: 2 }}>{i + 1}</Text>
              </Pressable>
            ))}
          </ScrollView>
        )}

        {added !== null && retake === null ? (
          <View style={{ paddingHorizontal: 20, gap: 10 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Icon name="check" color={C.accentTint} />
              <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: '700' }}>{t('s_page_added', { n: added })}</Text>
            </View>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Button title={t('s_add_page')} kind="light" onPress={() => (full ? tooMany() : setAdded(null))} style={{ flex: 1 }} />
              <Button title={t('done')} onPress={done} style={{ flex: 1 }} />
            </View>
          </View>
        ) : (
          <>
          <View style={{ paddingHorizontal: 20 }}>
            <Button title={t('s_auto')} icon="scan" kind="light" onPress={autoScan} />
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', paddingHorizontal: 12 }}>
            <Tool icon="upload" label={t('s_upload')} onPress={upload} />
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={t('s_take_photo')}
              disabled={!cameraOn}
              onPress={capture}
              style={{ width: 76, height: 76, borderRadius: 38, borderWidth: 5, borderColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center', opacity: cameraOn ? 1 : 0.4 }}
            >
              <View style={{ width: 58, height: 58, borderRadius: 29, backgroundColor: '#FFFFFF' }} />
            </Pressable>
            <Tool icon="file" label={t('s_pdf')} onPress={pickFile} />
          </View>
          </>
        )}
        {added === null && d.pages.length > 0 && retake === null && (
          <View style={{ paddingHorizontal: 20 }}>
            <Button title={t('done')} onPress={done} />
          </View>
        )}
      </View>

      {!!busy && (
        <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
          <ActivityIndicator color="#FFFFFF" size="large" />
          <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: '600' }}>{busy}</Text>
        </View>
      )}
    </View>
  );
}
