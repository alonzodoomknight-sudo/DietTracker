// 07 Scan saved
import React, { useEffect } from 'react';
import { Text, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { BackButton, Bubble, Button, Card, H1, Icon, Muted, Screen } from '../../src/ui';
import { C } from '../../src/theme';
import { Key, t, useLang } from '../../src/i18n';
import { useStore } from '../../src/store';
import { machineName } from '../../src/machines';
import { reminderDate } from '../../src/reminders';
import { Units, fmtDate, fmtDayMonth, fmtDelta, fmtMetric, fmtTime, fmtWeekday, parseLocal } from '../../src/format';
import { metric } from '../../src/metrics';
import { resetDraft } from '../../src/draft';

const CARDS: { key: string; label: Key }[] = [
  { key: 'weight', label: 'card_weight' },
  { key: 'fat_mass', label: 'card_fat' },
  { key: 'smm', label: 'card_muscle' },
  { key: 'score', label: 'card_score' },
];

export default function Saved() {
  useLang();
  const { id } = useLocalSearchParams<{ id: string }>();
  const scans = useStore((s) => s.scans);
  const prefs = useStore((s) => s.prefs);
  const units: Units = { weight: prefs.weight, length: prefs.length };

  // The scan is saved; clear the draft so going back can't save it twice.
  useEffect(() => {
    resetDraft();
  }, []);

  const index = scans.findIndex((s) => String(s.id) === String(id));
  const scan = index >= 0 ? scans[index] : null;

  const goHome = () => {
    if (router.canDismiss()) router.dismissAll();
    router.replace('/home');
  };

  if (!scan) {
    return (
      <Screen footer={<Button title={t('sv_see')} onPress={goHome} />}>
        <View style={{ flexDirection: 'row' }}>
          <BackButton onPress={goHome} />
        </View>
        <H1>{t('sv_title')}</H1>
      </Screen>
    );
  }

  const date = parseLocal(scan.scanned_at);
  const prev = index > 0 ? scans[index - 1] : null;
  const prevDate = prev ? parseLocal(prev.scanned_at) : null;
  const count = Object.keys(scan.values).length;

  // Goal from this sheet (or the latest sheet that has one)
  const targetScan = scan.values.target_weight ? scan : [...scans].reverse().find((s) => s.values.target_weight);
  const first = scans.find((s) => s.values.weight);
  const nowW = scan.values.weight?.v;
  const target = targetScan?.values.target_weight?.v;
  const firstDate = first ? parseLocal(first.scanned_at) : null;

  const next = parseLocal(prefs.nextScan);
  const reminder = prefs.remind ? reminderDate(prefs.nextScan) : null;

  return (
    <Screen
      footer={
        <>
          <Button title={t('sv_see')} onPress={goHome} />
          <Button title={t('sv_all', { n: count })} kind="secondary" onPress={() => router.push(`/sheet/${scan.id}`)} />
        </>
      }
    >
      <View style={{ flexDirection: 'row' }}>
        <BackButton onPress={goHome} />
      </View>
      <View style={{ height: 8 }} />
      <Bubble icon="check" tone="solid" size={56} iconSize={28} width={3} />
      <H1>{t('sv_title')}</H1>
      <Muted>
        {machineName(scan.machine)} · {date ? fmtDate(date) : scan.scanned_at}
      </Muted>

      {prev ? <Muted style={{ fontWeight: '600' }}>{t('sv_since', { date: prevDate ? fmtDayMonth(prevDate) : '' })}</Muted> : <Card><Muted>{t('sv_first')}</Muted></Card>}

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
        {CARDS.filter((c) => scan.values[c.key]).map((c) => {
          const v = scan.values[c.key].v;
          const pv = prev?.values[c.key]?.v;
          const m = metric(c.key);
          return (
            <Card key={c.key} style={{ flexBasis: '47%', flexGrow: 1, gap: 2 }}>
              <Muted>{t(c.label)}</Muted>
              <Text style={{ fontSize: 24, fontWeight: '800', color: C.ink }}>
                {fmtMetric(c.key, v, units, false)} <Text style={{ fontSize: 14, color: C.muted }}>{c.key === 'score' ? '/100' : m.unit === 'kg' ? (units.weight === 'lb' ? 'lb' : 'kg') : m.unit}</Text>
              </Text>
              {pv !== undefined && <Text style={{ fontSize: 13, fontWeight: '700', color: C.accent }}>{fmtDelta(c.key, v - pv, units)}</Text>}
            </Card>
          );
        })}
      </View>

      {target !== undefined && nowW !== undefined && (
        <Card style={{ gap: 4 }}>
          <Text style={{ fontSize: 17, fontWeight: '800', color: C.ink }}>{t('sv_goal', { v: fmtMetric('weight', target, units) })}</Text>
          <Muted>{t('sv_from_sheet')}</Muted>
          {first && first.id !== scan.id && firstDate && (
            <Text style={{ fontSize: 15, color: C.body }}>
              {nowW <= first.values.weight.v
                ? t('sv_lost', { v: fmtMetric('weight', first.values.weight.v - nowW, units), date: fmtDayMonth(firstDate) })
                : t('sv_gained', { v: fmtMetric('weight', nowW - first.values.weight.v, units), date: fmtDayMonth(firstDate) })}
            </Text>
          )}
          <Text style={{ fontSize: 15, fontWeight: '700', color: C.accent }}>{t('sv_to_go', { v: fmtMetric('weight', Math.abs(target - nowW), units) })}</Text>
        </Card>
      )}

      {next && next.getTime() > Date.now() && (
        <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <Icon name="calendar" color={C.accent} />
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 15, fontWeight: '600', color: C.ink }}>{t('sv_next', { date: `${fmtWeekday(next)}, ${fmtTime(next)}` })}</Text>
            {reminder && <Muted>{t('sv_reminder', { date: fmtWeekday(reminder) })}</Muted>}
          </View>
        </Card>
      )}
    </Screen>
  );
}
