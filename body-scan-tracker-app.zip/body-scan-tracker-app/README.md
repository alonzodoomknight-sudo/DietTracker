# Body Scan Tracker – app (Android and iPhone)

One codebase (React Native + Expo SDK 58) builds both the Android app and the iPhone app.
The app talks to your PHP website, so what is saved in the app shows on the dietitian's website.

**Order:** put the website online first (install.sh), then build the app.

---

## Part 1 – Website

Follow the steps in `install.sh` (in the website download). At the end it prints your website address,
for example `https://your-domain.com`. You need that address below.

## Part 2 – Build the Android APK on GitHub

1. On github.com, create a new **private** repository (for example `body-scan-tracker-app`).
2. Unzip `body-scan-tracker-app.zip` and upload **everything inside the folder**, including the hidden
   `.github` folder (it holds the build instructions). On a Mac, press Cmd + Shift + . in Finder to show hidden folders.
3. In the repository: **Settings → Secrets and variables → Actions → Variables → New repository variable**
   - `API_BASE_URL` = your website address, e.g. `https://your-domain.com` (must be https)
   - optional `APP_ID` = your app's unique name, e.g. `gr.yourname.bodyscan`. Pick it before you publish;
     it can't change later in the stores. If you leave it out, `com.bodyscantracker.app` is used.
4. **Actions → Build Android APK → Run workflow.** It takes about 15 minutes.
5. Open the finished run and download **body-scan-tracker-apk** under *Artifacts*. Unzip it to get the `.apk`.
6. Copy the `.apk` to an Android phone, open it and allow installing from that source.

Every build is signed with the same test key, so a new APK installs over the old one and keeps your data.
Before publishing on Google Play you will need your own signing key (Play also wants an `.aab` file).

## Part 3 – iPhone (later)

You need the Apple developer account ($99/year) and a free Expo account (expo.dev).

1. On **expo.dev**, create a project named `body-scan-tracker` and copy its *Project ID*.
   In GitHub add the variable `EAS_PROJECT_ID` with it.
2. On expo.dev: **Account settings → Access tokens → Create**. In GitHub add the secret `EXPO_TOKEN`.
3. In **App Store Connect → Users and Access → Integrations → App Store Connect API**, create a key with
   *App Manager* access and download the `.p8` file. In GitHub add these **secrets**:
   - `ASC_API_KEY_P8` – the whole text of the `.p8` file
   - `ASC_KEY_ID` – the key ID
   - `ASC_ISSUER_ID` – the issuer ID shown above the keys
   - `APPLE_TEAM_ID` – your Team ID (developer.apple.com → Membership)
   - If your Apple account is a company, also add the variable `APPLE_TEAM_TYPE` = `COMPANY_OR_ORGANIZATION`.
4. In App Store Connect, create the app with the same bundle ID as `APP_ID` (default `com.bodyscantracker.app`).
5. **Actions → Build iPhone app → Run workflow.** The app is built on GitHub's Mac and sent to TestFlight,
   where you and your testers install it.

Mac build minutes count 10× in a private repository (about 200 Mac minutes free each month; one build takes
roughly 20–30 minutes). If the first run stops at signing, run `npx eas-cli credentials` once from any computer
(choose iOS → production) to create the signing certificate, then run the workflow again.

---

## What's in this first version

- Screens 1–12 (welcome, reminders, scanning, check the numbers, progress, sheets, sheet photo, settings)
  and 20 (connect your dietitian). Sheets with 2 or 3 pages are handled inside the same screens.
- Greek and English. The app follows the phone's language; it can be changed in Settings → Language.
- Data is stored on your website's database, with a copy on the phone so it opens offline.
- Reminders the day before the next scan, at 18:00 (on the phone, no server needed).
- Export to a spreadsheet (CSV) or PDF. Delete all data.

## How the sheets are read (no AI)

- Each photo is sent to your website, which reads the text with **Tesseract** (Greek and English, free, on your server).
  Without a connection the phone reads it with Google ML Kit (free, offline, Latin letters and numbers only).
- **Find the sheet automatically**: the scanner finds the sheet's edges, takes the photo when the phone holds still
  and straightens it (on the phone; Google's document scanner on Android, Apple's on iPhone). The normal camera button stays.
- `src/machines.ts` holds one **template per machine model**: which printed label belongs to which number.
  So far: InBody 570, InBody 770 / 770S (Greek and English), Tanita MC-780 (English, and the Greek results table,
  body composition, segment analysis and children's sheets). Sheets from other machines are typed in.
- The templates must be tested and adjusted on real sheets. Anything the reader misses is highlighted on *Check the numbers*.
- PDFs are sent to your website, which turns each page into a photo (nothing is kept), then read the same way.

## Version 3 – the app and the website work as one

What the dietitian does on the website shows in the app, and what the client does in the app shows on the website.

- **Today**: next meal from the plan (*I ate this* / *Something else*), calories, water, next appointment, messages, goals
- **Meal plan**: the week from the dietitian, day by day, with meal times and notes (like the paper plan). Shopping list.
- **Snap your meal plan**: a paper or PDF plan (7 days × 5 meals + notes) is read and can be corrected, then saved.
- **Log a meal** (as planned, or foods with grams → kcal, with an optional photo), **Today's meals**, **Water**
- **Goals** set by the dietitian, with progress from the latest scan
- **Chat** with the dietitian
- **Appointments**: confirm, cancel, pay by card (if the dietitian turned it on), **join the video call** (opens in the
  phone's browser, nothing to install), **Book** a free time, **Add dates** written on a paper plan
- Reminders on the phone: scan, appointments (day before at 18:00 and 1 hour before), meal times, water (Settings)
- The bottom bar shows *Today · Plan · + · Progress · Chat* when a dietitian is connected or a plan exists; otherwise it stays
  *Progress · camera · Sheets*. *Sheets* is also on the Progress screen.

**Optional – notifications from the website** (new message, new plan, appointment changes): create a free Firebase project,
add an Android app with your `APP_ID`, download `google-services.json` and add its whole text as the GitHub **secret**
`GOOGLE_SERVICES_JSON`. Without it the app works the same; only those notifications are off (reminders on the phone still work).
iPhone notifications from the website need extra Apple and Firebase setup and are not on yet.

No signing key for the stores is added; builds keep using the test key until you decide to publish.

## Where things are

| Folder / file | What it holds |
|---|---|
| `app/` | One file per screen |
| `src/i18n.ts` | All Greek and English text |
| `src/machines.ts` | Machine templates for reading sheets |
| `src/reader.ts` | Reads a sheet photo and fills in the numbers |
| `src/metrics.ts` | Every number the app knows (shared with the website) |
| `src/api.ts` | Talks to the website |
| `src/store.ts` | Settings, login and the copy of your scans, plan, meals and appointments on the phone |
| `src/ocr.ts` | Sends a photo to your server to read, or reads it on the phone |
| `src/planReader.ts` | Reads a photographed meal plan (7 days × 5 meals + notes) |
| `src/meals.tsx` | Pieces shared by the meal plan, meals and water screens |
| `.github/workflows/` | Build instructions for GitHub (Android and iPhone) |
